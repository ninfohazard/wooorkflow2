import { supabase } from '../supabase';
import { AnalyticsEvent, AnalyticsMetrics, UserEngagement } from './types';
import { logger } from '../logger';

export class AnalyticsManager {
  static async trackEvent(event: AnalyticsEvent): Promise<void> {
    try {
      const { error } = await supabase
        .from('analytics_events')
        .insert({
          event_type: event.eventType,
          user_id: event.userId,
          metadata: event.metadata,
          timestamp: event.timestamp
        });

      if (error) throw error;
    } catch (error) {
      logger.error('Failed to track analytics event:', error);
    }
  }

  static async calculateMetrics(userId: string): Promise<AnalyticsMetrics> {
    try {
      const { data: events } = await supabase
        .from('analytics_events')
        .select('*')
        .eq('user_id', userId)
        .order('timestamp', { ascending: false })
        .limit(100);

      if (!events) return this.getDefaultMetrics();

      const processingTimes = events
        .filter(e => e.event_type === 'media_processing')
        .map(e => e.metadata.duration);

      const fileSizes = events
        .filter(e => e.event_type === 'media_upload')
        .map(e => e.metadata.fileSize);

      const successfulPosts = events
        .filter(e => e.event_type === 'social_post' && e.metadata.success)
        .length;

      const totalPosts = events
        .filter(e => e.event_type === 'social_post')
        .length;

      const platformEngagement = events
        .filter(e => e.event_type === 'social_post')
        .reduce((acc, event) => {
          const platform = event.metadata.platform;
          acc[platform] = (acc[platform] || 0) + 1;
          return acc;
        }, {} as Record<string, number>);

      return {
        processingTime: this.calculateAverage(processingTimes),
        fileSize: this.calculateAverage(fileSizes),
        successRate: (successfulPosts / totalPosts) * 100,
        platformEngagement
      };
    } catch (error) {
      logger.error('Failed to calculate metrics:', error);
      return this.getDefaultMetrics();
    }
  }

  static async getUserEngagement(userId: string): Promise<UserEngagement> {
    try {
      const { data: events } = await supabase
        .from('analytics_events')
        .select('*')
        .eq('user_id', userId);

      if (!events) return this.getDefaultEngagement();

      const uploads = events.filter(e => e.event_type === 'media_upload').length;
      const posts = events.filter(e => e.event_type === 'social_post').length;
      
      const processingTimes = events
        .filter(e => e.event_type === 'media_processing')
        .map(e => e.metadata.duration);

      const platforms = events
        .filter(e => e.event_type === 'social_post')
        .map(e => e.metadata.platform);

      const platformCounts = platforms.reduce((acc, platform) => {
        acc[platform] = (acc[platform] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const mostUsed = Object.entries(platformCounts)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 3)
        .map(([platform]) => platform);

      return {
        totalUploads: uploads,
        totalPosts: posts,
        averageProcessingTime: this.calculateAverage(processingTimes),
        mostUsedPlatforms: mostUsed
      };
    } catch (error) {
      logger.error('Failed to get user engagement:', error);
      return this.getDefaultEngagement();
    }
  }

  private static calculateAverage(numbers: number[]): number {
    return numbers.length > 0
      ? numbers.reduce((a, b) => a + b, 0) / numbers.length
      : 0;
  }

  private static getDefaultMetrics(): AnalyticsMetrics {
    return {
      processingTime: 0,
      fileSize: 0,
      successRate: 0,
      platformEngagement: {}
    };
  }

  private static getDefaultEngagement(): UserEngagement {
    return {
      totalUploads: 0,
      totalPosts: 0,
      averageProcessingTime: 0,
      mostUsedPlatforms: []
    };
  }
}