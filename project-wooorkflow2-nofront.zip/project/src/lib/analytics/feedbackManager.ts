import { supabase } from '../supabase';
import { logger } from '../logger';

export interface FeedbackEntry {
  id: string;
  type: 'bug' | 'feature' | 'usability';
  description: string;
  metadata?: Record<string, any>;
  userId?: string;
  createdAt: string;
}

export interface UsageMetrics {
  activeUsers: number;
  averageProcessingTime: number;
  successRate: number;
  popularFeatures: Record<string, number>;
}

export class FeedbackManager {
  static async submitFeedback(
    feedback: Omit<FeedbackEntry, 'id' | 'createdAt'>
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('user_feedback')
        .insert({
          type: feedback.type,
          description: feedback.description,
          metadata: feedback.metadata,
          user_id: feedback.userId
        });

      if (error) throw error;
    } catch (error) {
      logger.error('Failed to submit feedback:', error);
      throw error;
    }
  }

  static async getUsageMetrics(timeframe: 'day' | 'week' | 'month'): Promise<UsageMetrics> {
    try {
      const { data: events } = await supabase
        .from('analytics_events')
        .select('*')
        .gte('created_at', this.getTimeframeDate(timeframe));

      if (!events) {
        return this.getDefaultMetrics();
      }

      const uniqueUsers = new Set(events.map(e => e.user_id)).size;
      const processingTimes = events
        .filter(e => e.event_type === 'media_processing')
        .map(e => e.metadata.duration);

      const successfulOperations = events.filter(e => e.metadata.success).length;
      const totalOperations = events.length;

      const featureUsage = events.reduce((acc, event) => {
        acc[event.event_type] = (acc[event.event_type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      return {
        activeUsers: uniqueUsers,
        averageProcessingTime: this.calculateAverage(processingTimes),
        successRate: (successfulOperations / totalOperations) * 100,
        popularFeatures: featureUsage
      };
    } catch (error) {
      logger.error('Failed to get usage metrics:', error);
      return this.getDefaultMetrics();
    }
  }

  private static getTimeframeDate(timeframe: 'day' | 'week' | 'month'): Date {
    const now = new Date();
    switch (timeframe) {
      case 'day':
        return new Date(now.setDate(now.getDate() - 1));
      case 'week':
        return new Date(now.setDate(now.getDate() - 7));
      case 'month':
        return new Date(now.setMonth(now.getMonth() - 1));
    }
  }

  private static calculateAverage(numbers: number[]): number {
    return numbers.length > 0
      ? numbers.reduce((a, b) => a + b, 0) / numbers.length
      : 0;
  }

  private static getDefaultMetrics(): UsageMetrics {
    return {
      activeUsers: 0,
      averageProcessingTime: 0,
      successRate: 0,
      popularFeatures: {}
    };
  }
}