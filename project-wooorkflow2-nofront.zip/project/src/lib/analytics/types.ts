export interface AnalyticsEvent {
  eventType: string;
  timestamp: string;
  userId?: string;
  metadata: Record<string, any>;
}

export interface AnalyticsMetrics {
  processingTime: number;
  fileSize: number;
  successRate: number;
  platformEngagement: Record<string, number>;
}

export interface UserEngagement {
  totalUploads: number;
  totalPosts: number;
  averageProcessingTime: number;
  mostUsedPlatforms: string[];
}