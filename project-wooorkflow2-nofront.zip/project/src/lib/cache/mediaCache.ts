import { logger } from '../logger';

export class MediaCache {
  private static readonly CACHE_NAME = 'media-cache-v1';
  private static readonly MAX_AGE = 24 * 60 * 60 * 1000; // 24 hours
  private static readonly MAX_SIZE = 500 * 1024 * 1024; // 500MB

  static async store(key: string, blob: Blob): Promise<void> {
    try {
      const cache = await caches.open(this.CACHE_NAME);
      const response = new Response(blob);
      await cache.put(key, response);
      await this.cleanup();
    } catch (error) {
      logger.error('Cache storage failed:', error);
    }
  }

  static async retrieve(key: string): Promise<Blob | null> {
    try {
      const cache = await caches.open(this.CACHE_NAME);
      const response = await cache.match(key);
      if (!response) return null;
      return await response.blob();
    } catch (error) {
      logger.error('Cache retrieval failed:', error);
      return null;
    }
  }

  private static async cleanup(): Promise<void> {
    try {
      const cache = await caches.open(this.CACHE_NAME);
      const keys = await cache.keys();
      const now = Date.now();

      let totalSize = 0;
      const entries = await Promise.all(
        keys.map(async (key) => {
          const response = await cache.match(key);
          const size = parseInt(response?.headers.get('content-length') || '0');
          return { key, size, timestamp: response?.headers.get('date') };
        })
      );

      // Sort by date, oldest first
      entries.sort((a, b) => {
        return new Date(a.timestamp || 0).getTime() - new Date(b.timestamp || 0).getTime();
      });

      // Remove old or excess entries
      for (const entry of entries) {
        if (
          totalSize + entry.size > this.MAX_SIZE ||
          now - new Date(entry.timestamp || 0).getTime() > this.MAX_AGE
        ) {
          await cache.delete(entry.key);
        } else {
          totalSize += entry.size;
        }
      }
    } catch (error) {
      logger.error('Cache cleanup failed:', error);
    }
  }
}