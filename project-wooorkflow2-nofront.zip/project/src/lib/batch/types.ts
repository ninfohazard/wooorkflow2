export interface BatchJob {
  id: string;
  files: File[];
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  results: BatchResult[];
  error?: string;
}

export interface BatchResult {
  fileId: string;
  status: 'success' | 'failed';
  mediaUrl?: string;
  error?: string;
}

export interface BatchProgress {
  jobId: string;
  currentFile: number;
  totalFiles: number;
  currentProgress: number;
  status: string;
}