import { BatchJob, BatchProgress, BatchResult } from './types';
import { MediaWorkflow } from '../workflow/mediaWorkflow';
import { WorkflowOptions } from '../workflow/types';
import { logger } from '../logger';

export class BatchProcessor {
  private activeJobs: Map<string, BatchJob> = new Map();
  private readonly MAX_CONCURRENT_JOBS = 3;
  private readonly MAX_FILES_PER_JOB = 50;

  async createJob(
    files: File[],
    options: WorkflowOptions
  ): Promise<string> {
    if (files.length > this.MAX_FILES_PER_JOB) {
      throw new Error(`Maximum ${this.MAX_FILES_PER_JOB} files allowed per job`);
    }

    const jobId = crypto.randomUUID();
    const job: BatchJob = {
      id: jobId,
      files,
      status: 'pending',
      progress: 0,
      results: []
    };

    this.activeJobs.set(jobId, job);
    this.processJob(jobId, options);

    return jobId;
  }

  private async processJob(
    jobId: string,
    options: WorkflowOptions
  ): Promise<void> {
    const job = this.activeJobs.get(jobId);
    if (!job) return;

    try {
      job.status = 'processing';
      const workflow = new MediaWorkflow(options);

      for (let i = 0; i < job.files.length; i++) {
        const file = job.files[i];
        
        try {
          const result = await workflow.processMedia(
            file,
            (progress) => this.updateProgress(jobId, i, job.files.length, progress)
          );

          job.results.push({
            fileId: file.name,
            status: 'success',
            mediaUrl: result.mediaUrl
          });
        } catch (error) {
          job.results.push({
            fileId: file.name,
            status: 'failed',
            error: error instanceof Error ? error.message : 'Processing failed'
          });
        }

        job.progress = ((i + 1) / job.files.length) * 100;
        this.activeJobs.set(jobId, job);
      }

      job.status = 'completed';
    } catch (error) {
      job.status = 'failed';
      job.error = error instanceof Error ? error.message : 'Job failed';
      logger.error('Batch job failed:', { jobId, error });
    } finally {
      this.activeJobs.set(jobId, job);
    }
  }

  private updateProgress(
    jobId: string,
    fileIndex: number,
    totalFiles: number,
    progress: number
  ): void {
    const progressUpdate: BatchProgress = {
      jobId,
      currentFile: fileIndex + 1,
      totalFiles,
      currentProgress: progress,
      status: `Processing file ${fileIndex + 1} of ${totalFiles}`
    };

    // Emit progress update (could be through WebSocket or event system)
    this.emitProgress(progressUpdate);
  }

  private emitProgress(progress: BatchProgress): void {
    // Implementation would depend on the chosen real-time update mechanism
    console.log('Batch progress:', progress);
  }

  getJobStatus(jobId: string): BatchJob | null {
    return this.activeJobs.get(jobId) || null;
  }

  cancelJob(jobId: string): boolean {
    const job = this.activeJobs.get(jobId);
    if (!job || job.status === 'completed') return false;

    job.status = 'failed';
    job.error = 'Job cancelled by user';
    this.activeJobs.set(jobId, job);
    return true;
  }
}