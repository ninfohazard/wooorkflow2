// Add timeout handling
private async processWithTimeout<T>(
  operation: () => Promise<T>,
  timeoutMs: number = 300000 // 5 minutes
): Promise<T> {
  const timeout = new Promise<never>((_, reject) => {
    setTimeout(() => reject(new Error('Operation timed out')), timeoutMs);
  });

  return Promise.race([operation(), timeout]);
}

// Add rate limit handling
private async handleRateLimit(error: any): Promise<void> {
  if (error?.response?.status === 429) {
    const retryAfter = parseInt(error.response.headers['retry-after'] || '60');
    await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
  } else {
    throw error;
  }
}