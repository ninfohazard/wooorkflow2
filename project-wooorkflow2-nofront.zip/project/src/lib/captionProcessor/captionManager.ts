import { AudioExtractor } from './audioExtractor';
import { CAPTION_PROCESSOR_CONFIG } from './config';
import { CaptionResult, ProcessingProgress, CaptionSegment } from './types';
import { logger } from '../logger';
import { AppError } from '../errors';
import { supabase } from '../supabase';
import { retry } from '../utils/retry';

export class CaptionManager {
  private audioExtractor: AudioExtractor;

  constructor() {
    this.audioExtractor = new AudioExtractor();
  }

  async generateCaptions(
    file: File,
    language: string = CAPTION_PROCESSOR_CONFIG.defaultLanguage,
    onProgress?: (progress: ProcessingProgress) => void
  ): Promise<CaptionResult> {
    try {
      // Initialize audio extractor
      await this.audioExtractor.initialize();

      onProgress?.({
        status: 'extracting',
        progress: 0,
        message: 'Extracting audio...'
      });

      // Extract audio from media file
      const audioBlob = await this.audioExtractor.extractAudio(file);

      onProgress?.({
        status: 'transcribing',
        progress: 30,
        message: 'Generating captions...'
      });

      // Process audio through OpenAI Whisper API
      const segments = await this.processAudioWithWhisper(audioBlob, language);

      onProgress?.({
        status: 'complete',
        progress: 100,
        message: 'Captions generated successfully'
      });

      return {
        segments,
        text: segments.map(s => s.text).join(' '),
        language
      };
    } catch (error) {
      logger.error('Caption generation failed:', error);
      throw new AppError(
        'CAPTION_GENERATION_ERROR',
        error instanceof Error ? error.message : 'Failed to generate captions'
      );
    }
  }

  private async processAudioWithWhisper(
    audioBlob: Blob,
    language: string
  ): Promise<CaptionSegment[]> {
    try {
      // Convert blob to base64
      const buffer = await audioBlob.arrayBuffer();
      const base64Audio = Buffer.from(buffer).toString('base64');

      // Call OpenAI Whisper API with retry logic
      const response = await retry(async () => {
        const result = await fetch('https://api.openai.com/v1/audio/transcriptions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: CAPTION_PROCESSOR_CONFIG.openAiModel,
            file: base64Audio,
            language,
            response_format: 'verbose_json',
            timestamp_granularities: ['segment']
          })
        });

        if (!response.ok) {
          throw new Error('Transcription service error');
        }

        return await response.json();
      });

      // Transform API response to our segment format
      return response.segments.map((segment: any) => ({
        start: segment.start,
        end: segment.end,
        text: segment.text.trim()
      }));
    } catch (error) {
      logger.error('Whisper API processing failed:', error);
      throw error;
    }
  }

  async saveCaptions(
    mediaId: string,
    captions: CaptionResult
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('captions')
        .insert({
          media_id: mediaId,
          segments: captions.segments,
          full_text: captions.text,
          language: captions.language
        });

      if (error) throw error;
    } catch (error) {
      logger.error('Failed to save captions:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to save generated captions'
      );
    }
  }

  async loadCaptions(mediaId: string): Promise<CaptionResult | null> {
    try {
      const { data, error } = await supabase
        .from('captions')
        .select('*')
        .eq('media_id', mediaId)
        .single();

      if (error) throw error;
      if (!data) return null;

      return {
        segments: data.segments,
        text: data.full_text,
        language: data.language
      };
    } catch (error) {
      logger.error('Failed to load captions:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to load captions'
      );
    }
  }

  async validateCaptions(captions: CaptionResult): Promise<boolean> {
    try {
      // Check for required fields
      if (!captions.segments || !captions.text || !captions.language) {
        return false;
      }

      // Validate segments
      for (const segment of captions.segments) {
        if (
          typeof segment.start !== 'number' ||
          typeof segment.end !== 'number' ||
          typeof segment.text !== 'string' ||
          segment.start >= segment.end ||
          segment.start < 0 ||
          !segment.text.trim()
        ) {
          return false;
        }
      }

      // Validate language
      if (!CAPTION_PROCESSOR_CONFIG.supportedLanguages.includes(captions.language)) {
        return false;
      }

      return true;
    } catch (error) {
      logger.error('Caption validation failed:', error);
      return false;
    }
  }
}