export const CAPTION_PROCESSOR_CONFIG = {
  maxDurationSeconds: 300, // 5 minutes
  supportedLanguages: ['en', 'es', 'fr', 'de', 'it', 'pt', 'nl', 'ja', 'ko', 'zh'],
  defaultLanguage: 'en',
  openAiModel: 'whisper-1',
  maxRetries: 3,
  retryDelay: 1000, // 1 second
};