export interface CaptionSegment {
  start: number;
  end: number;
  text: string;
}

export interface CaptionResult {
  segments: CaptionSegment[];
  text: string;
  language: string;
}

export interface ProcessingProgress {
  status: 'extracting' | 'transcribing' | 'complete' | 'error';
  progress: number;
  message?: string;
}

export interface CaptionProcessorConfig {
  maxDurationSeconds: number;
  supportedLanguages: string[];
  defaultLanguage: string;
}