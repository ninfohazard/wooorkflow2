import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL } from '@ffmpeg/util';
import { logger } from '../logger';

export class AudioExtractor {
  private ffmpeg: FFmpeg | null = null;

  async initialize(): Promise<void> {
    try {
      this.ffmpeg = new FFmpeg();
      const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.4/dist/umd';
      await this.ffmpeg.load({
        coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
        wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
      });
    } catch (error) {
      logger.error('Failed to initialize FFmpeg:', error);
      throw new Error('Failed to initialize audio extraction');
    }
  }

  async extractAudio(mediaFile: File): Promise<Blob> {
    if (!this.ffmpeg) {
      throw new Error('FFmpeg not initialized');
    }

    try {
      const inputFileName = 'input' + (mediaFile.type.includes('video') ? '.mp4' : '.mp3');
      const outputFileName = 'output.mp3';

      // Write the input file to FFmpeg's virtual filesystem
      this.ffmpeg.writeFile(inputFileName, await mediaFile.arrayBuffer());

      // Extract audio
      await this.ffmpeg.exec([
        '-i', inputFileName,
        '-vn', // Disable video
        '-acodec', 'libmp3lame',
        '-ar', '16000', // Sample rate required by Whisper
        '-ac', '1', // Mono audio
        '-b:a', '64k', // Bitrate
        outputFileName
      ]);

      // Read the output file
      const data = await this.ffmpeg.readFile(outputFileName);
      return new Blob([data], { type: 'audio/mp3' });
    } catch (error) {
      logger.error('Audio extraction failed:', error);
      throw new Error('Failed to extract audio from media file');
    } finally {
      // Cleanup
      try {
        await this.ffmpeg.terminate();
      } catch (error) {
        logger.error('FFmpeg cleanup failed:', error);
      }
    }
  }
}