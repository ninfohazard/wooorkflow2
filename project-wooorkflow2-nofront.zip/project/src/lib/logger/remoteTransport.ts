import { LogEntry } from './types';
import { supabase } from '../supabase';
import { retry } from '../utils';

export class RemoteTransport {
  async send(entry: LogEntry): Promise<void> {
    await retry(async () => {
      const { error } = await supabase
        .from('logs')
        .insert({
          level: entry.level,
          message: entry.message,
          context: entry.context,
          module: entry.module,
          user_id: entry.userId,
          timestamp: entry.timestamp
        });

      if (error) {
        throw error;
      }
    }, {
      maxAttempts: 3,
      initialDelay: 1000
    });
  }
}