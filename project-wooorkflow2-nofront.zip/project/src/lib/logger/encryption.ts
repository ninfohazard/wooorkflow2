import { Buffer } from 'buffer';

export class LogEncryption {
  private static readonly ALGORITHM = 'AES-GCM';
  private static readonly KEY_LENGTH = 256;
  private static readonly IV_LENGTH = 12;
  private key: CryptoKey | null = null;

  async initialize(): Promise<void> {
    const keyMaterial = await this.getOrGenerateKey();
    this.key = await crypto.subtle.importKey(
      'raw',
      keyMaterial,
      { name: this.ALGORITHM },
      false,
      ['encrypt', 'decrypt']
    );
  }

  async encrypt(data: string): Promise<string> {
    if (!this.key) {
      throw new Error('Encryption not initialized');
    }

    const iv = crypto.getRandomValues(new Uint8Array(this.IV_LENGTH));
    const encodedData = new TextEncoder().encode(data);

    const encryptedData = await crypto.subtle.encrypt(
      {
        name: this.ALGORITHM,
        iv
      },
      this.key,
      encodedData
    );

    // Combine IV and encrypted data
    const combined = new Uint8Array(iv.length + encryptedData.byteLength);
    combined.set(iv);
    combined.set(new Uint8Array(encryptedData), iv.length);

    return Buffer.from(combined).toString('base64');
  }

  async decrypt(encryptedData: string): Promise<string> {
    if (!this.key) {
      throw new Error('Encryption not initialized');
    }

    const combined = Buffer.from(encryptedData, 'base64');
    const iv = combined.slice(0, this.IV_LENGTH);
    const data = combined.slice(this.IV_LENGTH);

    const decryptedData = await crypto.subtle.decrypt(
      {
        name: this.ALGORITHM,
        iv
      },
      this.key,
      data
    );

    return new TextDecoder().decode(decryptedData);
  }

  private async getOrGenerateKey(): Promise<Uint8Array> {
    // In a real application, this would be stored securely
    // For demo purposes, we generate a new key each time
    return crypto.getRandomValues(new Uint8Array(this.KEY_LENGTH / 8));
  }
}