import { LogLevel, LogEntry, LoggerConfig } from './types';
import { FileTransport } from './fileTransport';
import { RemoteTransport } from './remoteTransport';
import { LogEncryption } from './encryption';

const DEFAULT_CONFIG: LoggerConfig = {
  minLevel: 'info',
  enableEncryption: true,
  remoteLogging: true,
  maxFileSize: 5 * 1024 * 1024, // 5MB
  maxFiles: 5,
  logDirectory: 'logs'
};

class Logger {
  private static instance: Logger;
  private config: LoggerConfig;
  private fileTransport: FileTransport;
  private remoteTransport: RemoteTransport;
  private encryption: LogEncryption;

  private readonly LOG_LEVELS: Record<LogLevel, number> = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3
  };

  private constructor(config: Partial<LoggerConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.encryption = new LogEncryption();
    this.fileTransport = new FileTransport(this.config, this.encryption);
    this.remoteTransport = new RemoteTransport();
  }

  static getInstance(config?: Partial<LoggerConfig>): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger(config);
    }
    return Logger.instance;
  }

  async initialize(): Promise<void> {
    await this.fileTransport.initialize();
  }

  async log(
    level: LogLevel,
    message: string,
    context?: Record<string, unknown>
  ): Promise<void> {
    if (this.LOG_LEVELS[level] < this.LOG_LEVELS[this.config.minLevel]) {
      return;
    }

    const entry: LogEntry = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      level,
      message,
      context,
      module: this.getCallerModule(),
      userId: await this.getCurrentUserId()
    };

    // Write to local storage
    await this.fileTransport.write(entry);

    // Send to remote if enabled
    if (this.config.remoteLogging) {
      await this.remoteTransport.send(entry).catch(error => {
        console.error('Failed to send log to remote:', error);
      });
    }
  }

  debug(message: string, context?: Record<string, unknown>): Promise<void> {
    return this.log('debug', message, context);
  }

  info(message: string, context?: Record<string, unknown>): Promise<void> {
    return this.log('info', message, context);
  }

  warn(message: string, context?: Record<string, unknown>): Promise<void> {
    return this.log('warn', message, context);
  }

  error(message: string, context?: Record<string, unknown>): Promise<void> {
    return this.log('error', message, context);
  }

  private getCallerModule(): string {
    const error = new Error();
    const stack = error.stack?.split('\n')[3];
    const match = stack?.match(/at\s+(\S+)\s+\(/);
    return match?.[1] || 'unknown';
  }

  private async getCurrentUserId(): Promise<string | undefined> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      return session?.user?.id;
    } catch {
      return undefined;
    }
  }
}