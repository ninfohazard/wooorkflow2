export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  id: string;
  timestamp: string;
  level: LogLevel;
  message: string;
  context?: Record<string, unknown>;
  module?: string;
  userId?: string;
}

export interface LoggerConfig {
  minLevel: LogLevel;
  enableEncryption?: boolean;
  remoteLogging?: boolean;
  maxFileSize?: number; // in bytes
  maxFiles?: number;
  logDirectory?: string;
}