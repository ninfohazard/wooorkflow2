import { LogEntry, LoggerConfig } from './types';
import { LogEncryption } from './encryption';

export class FileTransport {
  private encryption: LogEncryption | null = null;
  private currentFileSize = 0;
  private currentFileIndex = 0;

  constructor(
    private config: LoggerConfig,
    encryption?: LogEncryption
  ) {
    if (config.enableEncryption) {
      this.encryption = encryption || new LogEncryption();
    }
  }

  async initialize(): Promise<void> {
    if (this.encryption) {
      await this.encryption.initialize();
    }
  }

  async write(entry: LogEntry): Promise<void> {
    const logString = JSON.stringify(entry);
    const encodedLog = this.encryption
      ? await this.encryption.encrypt(logString)
      : logString;

    // In a browser environment, we'll use IndexedDB for storage
    await this.writeToIndexedDB(encodedLog);
  }

  private async writeToIndexedDB(logData: string): Promise<void> {
    const request = indexedDB.open('LogStorage', 1);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('logs')) {
        db.createObjectStore('logs', { keyPath: 'id', autoIncrement: true });
      }
    };

    return new Promise((resolve, reject) => {
      request.onsuccess = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        const transaction = db.transaction(['logs'], 'readwrite');
        const store = transaction.objectStore('logs');

        const logEntry = {
          data: logData,
          timestamp: new Date().toISOString()
        };

        const addRequest = store.add(logEntry);

        addRequest.onsuccess = () => {
          this.currentFileSize += logData.length;
          this.rotateLogsIfNeeded();
          resolve();
        };

        addRequest.onerror = () => {
          reject(new Error('Failed to write to IndexedDB'));
        };
      };

      request.onerror = () => {
        reject(new Error('Failed to open IndexedDB'));
      };
    });
  }

  private async rotateLogsIfNeeded(): Promise<void> {
    if (this.currentFileSize >= (this.config.maxFileSize || 5 * 1024 * 1024)) {
      this.currentFileSize = 0;
      this.currentFileIndex = (this.currentFileIndex + 1) % (this.config.maxFiles || 5);

      // Clear old logs if we've exceeded maxFiles
      if (this.currentFileIndex === 0) {
        await this.clearOldLogs();
      }
    }
  }

  private async clearOldLogs(): Promise<void> {
    const request = indexedDB.open('LogStorage', 1);

    return new Promise((resolve, reject) => {
      request.onsuccess = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        const transaction = db.transaction(['logs'], 'readwrite');
        const store = transaction.objectStore('logs');

        // Keep only the most recent logs
        const countRequest = store.count();
        
        countRequest.onsuccess = () => {
          const totalLogs = countRequest.result;
          const logsToKeep = this.config.maxFiles || 5;
          
          if (totalLogs > logsToKeep) {
            const cursorRequest = store.openCursor();
            let deletedCount = 0;
            
            cursorRequest.onsuccess = (e) => {
              const cursor = (e.target as IDBRequest).result;
              if (cursor && deletedCount < (totalLogs - logsToKeep)) {
                cursor.delete();
                deletedCount++;
                cursor.continue();
              }
            };
          }
        };

        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(new Error('Failed to clear old logs'));
      };
    });
  }
}