import { Logger } from './logger';
export * from './types';

// Export a singleton instance
export const logger = Logger.getInstance();