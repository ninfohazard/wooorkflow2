import { Buffer } from 'buffer';

export class Encryption {
  private static readonly ALGORITHM = 'AES-GCM';
  private static readonly KEY_LENGTH = 256;
  private static readonly IV_LENGTH = 12;

  static async encrypt(data: string, key: string): Promise<string> {
    try {
      const iv = crypto.getRandomValues(new Uint8Array(this.IV_LENGTH));
      const cryptoKey = await this.deriveKey(key);

      const encryptedData = await crypto.subtle.encrypt(
        {
          name: this.ALGORITHM,
          iv
        },
        cryptoKey,
        new TextEncoder().encode(data)
      );

      const combined = new Uint8Array(iv.length + encryptedData.byteLength);
      combined.set(iv);
      combined.set(new Uint8Array(encryptedData), iv.length);

      return Buffer.from(combined).toString('base64');
    } catch (error) {
      throw new Error('Encryption failed');
    }
  }

  static async decrypt(encryptedData: string, key: string): Promise<string> {
    try {
      const data = Buffer.from(encryptedData, 'base64');
      const iv = data.slice(0, this.IV_LENGTH);
      const ciphertext = data.slice(this.IV_LENGTH);

      const cryptoKey = await this.deriveKey(key);

      const decrypted = await crypto.subtle.decrypt(
        {
          name: this.ALGORITHM,
          iv
        },
        cryptoKey,
        ciphertext
      );

      return new TextDecoder().decode(decrypted);
    } catch (error) {
      throw new Error('Decryption failed');
    }
  }

  private static async deriveKey(password: string): Promise<CryptoKey> {
    const encoder = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      encoder.encode(password),
      'PBKDF2',
      false,
      ['deriveBits', 'deriveKey']
    );

    return await crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: encoder.encode('fixed-salt'),
        iterations: 100000,
        hash: 'SHA-256'
      },
      keyMaterial,
      { name: this.ALGORITHM, length: this.KEY_LENGTH },
      false,
      ['encrypt', 'decrypt']
    );
  }
}