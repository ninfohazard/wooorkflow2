import { ExportConfig, ExportData } from './types';
import { Encryption } from '../security/encryption';
import { logger } from '../logger';
import { supabase } from '../supabase';

export class ExportManager {
  static readonly VERSION = '1.0.0';

  static async exportData(
    userId: string,
    config: ExportConfig
  ): Promise<string> {
    try {
      const exportData: ExportData = {
        version: this.VERSION,
        timestamp: new Date().toISOString()
      };

      if (config.includeAnalytics) {
        exportData.analytics = await this.exportAnalytics(userId);
      }

      if (config.includeWorkflowConfigs) {
        exportData.workflowConfigs = await this.exportWorkflowConfigs(userId);
      }

      if (config.includeCaptions) {
        exportData.captions = await this.exportCaptions(userId);
      }

      const exportString = config.format === 'json'
        ? JSON.stringify(exportData, null, 2)
        : this.convertToCSV(exportData);

      // Encrypt the export data
      const encryptionKey = await this.generateExportKey();
      const encryptedData = await Encryption.encrypt(exportString, encryptionKey);

      return encryptedData;
    } catch (error) {
      logger.error('Export failed:', error);
      throw error;
    }
  }

  static async importData(
    userId: string,
    encryptedData: string,
    encryptionKey: string
  ): Promise<void> {
    try {
      const decryptedData = await Encryption.decrypt(encryptedData, encryptionKey);
      const importData: ExportData = JSON.parse(decryptedData);

      // Validate version compatibility
      if (!this.isVersionCompatible(importData.version)) {
        throw new Error('Incompatible export version');
      }

      if (importData.workflowConfigs) {
        await this.importWorkflowConfigs(userId, importData.workflowConfigs);
      }

      if (importData.captions) {
        await this.importCaptions(userId, importData.captions);
      }
    } catch (error) {
      logger.error('Import failed:', error);
      throw error;
    }
  }

  private static async exportAnalytics(userId: string): Promise<any> {
    const { data, error } = await supabase
      .from('analytics_events')
      .select('*')
      .eq('user_id', userId);

    if (error) throw error;
    return data;
  }

  private static async exportWorkflowConfigs(userId: string): Promise<any> {
    const { data, error } = await supabase
      .from('workflow_configs')
      .select('*')
      .eq('user_id', userId);

    if (error) throw error;
    return data;
  }

  private static async exportCaptions(userId: string): Promise<any> {
    const { data, error } = await supabase
      .from('captions')
      .select('*')
      .eq('user_id', userId);

    if (error) throw error;
    return data;
  }

  private static async importWorkflowConfigs(
    userId: string,
    configs: any[]
  ): Promise<void> {
    const { error } = await supabase
      .from('workflow_configs')
      .upsert(
        configs.map(config => ({
          ...config,
          user_id: userId
        }))
      );

    if (error) throw error;
  }

  private static async importCaptions(
    userId: string,
    captions: any[]
  ): Promise<void> {
    const { error } = await supabase
      .from('captions')
      .upsert(
        captions.map(caption => ({
          ...caption,
          user_id: userId
        }))
      );

    if (error) throw error;
  }

  private static async generateExportKey(): Promise<string> {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array)
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }

  private static isVersionCompatible(version: string): boolean {
    const [major] = version.split('.');
    const [currentMajor] = this.VERSION.split('.');
    return major === currentMajor;
  }

  private static convertToCSV(data: any): string {
    // Implementation of JSON to CSV conversion
    // This would be a more complex implementation based on the data structure
    return '';
  }
}