export interface ExportConfig {
  includeAnalytics: boolean;
  includeWorkflowConfigs: boolean;
  includeCaptions: boolean;
  format: 'json' | 'csv';
}

export interface ExportData {
  version: string;
  timestamp: string;
  analytics?: any;
  workflowConfigs?: any;
  captions?: any;
}