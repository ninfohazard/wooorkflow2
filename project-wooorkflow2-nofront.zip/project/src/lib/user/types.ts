import { z } from 'zod';

export const UserPreferencesSchema = z.object({
  theme: z.enum(['light', 'dark', 'system']),
  language: z.string(),
  notifications: z.object({
    email: z.boolean(),
    push: z.boolean(),
    workflow: z.boolean()
  }),
  accessibility: z.object({
    reducedMotion: z.boolean(),
    highContrast: z.boolean(),
    fontSize: z.enum(['small', 'medium', 'large'])
  }),
  workflow: z.object({
    autoSave: z.boolean(),
    defaultPlatforms: z.array(z.string()),
    captionLanguage: z.string()
  })
});

export const UserProfileSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  fullName: z.string().optional(),
  avatar: z.string().url().optional(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime()
});

export type UserPreferences = z.infer<typeof UserPreferencesSchema>;
export type UserProfile = z.infer<typeof UserProfileSchema>;

export interface UserUpdateData {
  profile?: Partial<Omit<UserProfile, 'id' | 'createdAt' | 'updatedAt'>>;
  preferences?: Partial<UserPreferences>;
}

export interface UserRepository {
  getCurrentUser(): Promise<UserProfile | null>;
  getUserPreferences(): Promise<UserPreferences>;
  updateUser(data: UserUpdateData): Promise<void>;
  deleteUser(): Promise<void>;
}