import { supabase } from '../supabase';
import { logger } from '../logger';
import { AppError } from '../errors';
import { retry } from '../utils';
import {
  UserProfile,
  UserPreferences,
  UserUpdateData,
  UserPreferencesSchema,
  UserProfileSchema
} from './types';

export class UserRepository {
  private static instance: UserRepository;
  private cachedPreferences: UserPreferences | null = null;
  private cachedProfile: UserProfile | null = null;

  private constructor() {}

  static getInstance(): UserRepository {
    if (!UserRepository.instance) {
      UserRepository.instance = new UserRepository();
    }
    return UserRepository.instance;
  }

  async getCurrentUser(): Promise<UserProfile | null> {
    try {
      if (this.cachedProfile) {
        return this.cachedProfile;
      }

      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;
      if (!session) return null;

      const { data: profile, error: profileError } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', session.user.id)
        .single();

      if (profileError) throw profileError;
      if (!profile) return null;

      // Validate profile data
      const validatedProfile = UserProfileSchema.parse(profile);
      this.cachedProfile = validatedProfile;
      return validatedProfile;
    } catch (error) {
      logger.error('Failed to get current user:', error);
      throw new AppError(
        'AUTHENTICATION_ERROR',
        'Failed to retrieve user profile'
      );
    }
  }

  async getUserPreferences(): Promise<UserPreferences> {
    try {
      if (this.cachedPreferences) {
        return this.cachedPreferences;
      }

      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;
      if (!session) {
        throw new AppError(
          'AUTHENTICATION_ERROR',
          'No active session'
        );
      }

      const { data: preferences, error: preferencesError } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', session.user.id)
        .single();

      if (preferencesError) throw preferencesError;

      // If no preferences exist, create default ones
      if (!preferences) {
        const defaultPreferences = this.getDefaultPreferences();
        await this.updateUser({ preferences: defaultPreferences });
        return defaultPreferences;
      }

      // Validate preferences data
      const validatedPreferences = UserPreferencesSchema.parse(preferences.data);
      this.cachedPreferences = validatedPreferences;
      return validatedPreferences;
    } catch (error) {
      logger.error('Failed to get user preferences:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to retrieve user preferences'
      );
    }
  }

  async updateUser(data: UserUpdateData): Promise<void> {
    try {
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;
      if (!session) {
        throw new AppError(
          'AUTHENTICATION_ERROR',
          'No active session'
        );
      }

      await retry(async () => {
        // Update profile if provided
        if (data.profile) {
          const { error: profileError } = await supabase
            .from('user_profiles')
            .update(data.profile)
            .eq('id', session.user.id);

          if (profileError) throw profileError;
          this.cachedProfile = null; // Invalidate cache
        }

        // Update preferences if provided
        if (data.preferences) {
          const { error: preferencesError } = await supabase
            .from('user_preferences')
            .upsert({
              user_id: session.user.id,
              data: data.preferences,
              updated_at: new Date().toISOString()
            });

          if (preferencesError) throw preferencesError;
          this.cachedPreferences = null; // Invalidate cache
        }
      });

      // Log the update
      logger.info('User data updated successfully', {
        userId: session.user.id,
        updatedFields: {
          profile: data.profile ? Object.keys(data.profile) : [],
          preferences: data.preferences ? Object.keys(data.preferences) : []
        }
      });
    } catch (error) {
      logger.error('Failed to update user:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to update user data'
      );
    }
  }

  async deleteUser(): Promise<void> {
    try {
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) throw sessionError;
      if (!session) {
        throw new AppError(
          'AUTHENTICATION_ERROR',
          'No active session'
        );
      }

      // Delete user data in a transaction
      const { error: deleteError } = await supabase.rpc('delete_user_data', {
        user_id: session.user.id
      });

      if (deleteError) throw deleteError;

      // Delete auth user
      const { error: authError } = await supabase.auth.admin.deleteUser(
        session.user.id
      );

      if (authError) throw authError;

      // Clear caches
      this.cachedProfile = null;
      this.cachedPreferences = null;

      logger.info('User deleted successfully', {
        userId: session.user.id
      });
    } catch (error) {
      logger.error('Failed to delete user:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to delete user account'
      );
    }
  }

  private getDefaultPreferences(): UserPreferences {
    return {
      theme: 'system',
      language: 'en',
      notifications: {
        email: true,
        push: true,
        workflow: true
      },
      accessibility: {
        reducedMotion: false,
        highContrast: false,
        fontSize: 'medium'
      },
      workflow: {
        autoSave: true,
        defaultPlatforms: [],
        captionLanguage: 'en'
      }
    };
  }
}