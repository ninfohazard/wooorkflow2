import { create } from 'zustand';
import { UserProfile, UserPreferences } from './types';
import { UserRepository } from './userRepository';

interface UserState {
  profile: UserProfile | null;
  preferences: UserPreferences | null;
  isLoading: boolean;
  error: string | null;
  loadUser: () => Promise<void>;
  updateProfile: (data: Partial<UserProfile>) => Promise<void>;
  updatePreferences: (data: Partial<UserPreferences>) => Promise<void>;
  logout: () => Promise<void>;
}

export const useUserStore = create<UserState>((set, get) => ({
  profile: null,
  preferences: null,
  isLoading: false,
  error: null,

  loadUser: async () => {
    try {
      set({ isLoading: true, error: null });
      const userRepo = UserRepository.getInstance();
      
      const [profile, preferences] = await Promise.all([
        userRepo.getCurrentUser(),
        userRepo.getUserPreferences()
      ]);

      set({ profile, preferences, isLoading: false });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to load user data',
        isLoading: false
      });
    }
  },

  updateProfile: async (data) => {
    try {
      set({ isLoading: true, error: null });
      const userRepo = UserRepository.getInstance();
      
      await userRepo.updateUser({ profile: data });
      const newProfile = await userRepo.getCurrentUser();
      
      set({ profile: newProfile, isLoading: false });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to update profile',
        isLoading: false
      });
    }
  },

  updatePreferences: async (data) => {
    try {
      set({ isLoading: true, error: null });
      const userRepo = UserRepository.getInstance();
      
      await userRepo.updateUser({ preferences: data });
      const newPreferences = await userRepo.getUserPreferences();
      
      set({ preferences: newPreferences, isLoading: false });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to update preferences',
        isLoading: false
      });
    }
  },

  logout: async () => {
    try {
      set({ isLoading: true, error: null });
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      set({
        profile: null,
        preferences: null,
        isLoading: false
      });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to logout',
        isLoading: false
      });
    }
  }
}));