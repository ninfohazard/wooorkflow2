import { logger } from '../logger';
import { AppError, ErrorHandler } from '../errors';

export interface RetryOptions {
  maxAttempts?: number;
  initialDelay?: number;
  maxDelay?: number;
  backoffFactor?: number;
  retryableErrors?: (error: unknown) => boolean;
}

export interface RetryContext {
  attempt: number;
  startTime: number;
  lastError?: unknown;
}

const DEFAULT_OPTIONS: Required<RetryOptions> = {
  maxAttempts: 3,
  initialDelay: 1000,
  maxDelay: 10000,
  backoffFactor: 2,
  retryableErrors: (error: unknown) => 
    ErrorHandler.isNetworkError(error) || 
    (error instanceof AppError && error.severity !== 'critical')
};

export async function retry<T>(
  operation: (context: RetryContext) => Promise<T>,
  options: RetryOptions = {}
): Promise<T> {
  const config = { ...DEFAULT_OPTIONS, ...options };
  let attempt = 1;
  let delay = config.initialDelay;
  const startTime = Date.now();

  while (true) {
    try {
      const context: RetryContext = {
        attempt,
        startTime,
      };

      logger.info('Attempting operation', {
        attempt,
        operationName: operation.name || 'anonymous'
      });

      const result = await operation(context);

      logger.info('Operation succeeded', {
        attempt,
        operationName: operation.name || 'anonymous',
        duration: Date.now() - startTime
      });

      return result;
    } catch (error) {
      context.lastError = error;

      const shouldRetry = attempt < config.maxAttempts && config.retryableErrors(error);

      await ErrorHandler.handleError(error);

      if (!shouldRetry) {
        logger.error('Operation failed permanently', {
          attempt,
          operationName: operation.name || 'anonymous',
          duration: Date.now() - startTime
        });

        throw error;
      }

      logger.warn('Operation failed, retrying', {
        attempt,
        nextDelay: delay,
        operationName: operation.name || 'anonymous'
      });

      await new Promise(resolve => setTimeout(resolve, delay));
      
      delay = Math.min(delay * config.backoffFactor, config.maxDelay);
      attempt++;
    }
  }
}