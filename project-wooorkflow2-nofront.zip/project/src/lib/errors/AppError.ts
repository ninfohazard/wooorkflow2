import { ErrorCode, ErrorSeverity } from './types';
import { ERROR_DEFINITIONS } from './errorDefinitions';

export class AppError extends Error {
  readonly code: ErrorCode;
  readonly severity: ErrorSeverity;
  readonly context?: Record<string, unknown>;
  readonly timestamp: string;
  readonly solution?: string;

  constructor(
    code: ErrorCode,
    message?: string,
    context?: Record<string, unknown>
  ) {
    const errorDef = ERROR_DEFINITIONS[code];
    super(message || errorDef.userMessage);

    this.name = 'AppError';
    this.code = code;
    this.severity = errorDef.severity;
    this.context = context;
    this.timestamp = new Date().toISOString();
    this.solution = errorDef.solution;

    // Ensure proper stack trace
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, AppError);
    }
  }

  toJSON() {
    return {
      code: this.code,
      message: this.message,
      severity: this.severity,
      timestamp: this.timestamp,
      stack: this.stack,
      context: this.context,
      solution: this.solution
    };
  }

  getUserMessage(): string {
    return ERROR_DEFINITIONS[this.code].userMessage;
  }
}