import { ErrorCode, ErrorSeverity } from './types';

interface ErrorDefinition {
  code: ErrorCode;
  severity: ErrorSeverity;
  userMessage: string;
  solution?: string;
}

export const ERROR_DEFINITIONS: Record<ErrorCode, ErrorDefinition> = {
  MEDIA_UPLOAD_ERROR: {
    code: 'MEDIA_UPLOAD_ERROR',
    severity: 'high',
    userMessage: 'Failed to upload media. Please try again.',
    solution: 'Check file size and format, ensure stable internet connection'
  },
  MEDIA_PROCESSING_ERROR: {
    code: 'MEDIA_PROCESSING_ERROR',
    severity: 'high',
    userMessage: 'Unable to process media file.',
    solution: 'Verify file format is supported and not corrupted'
  },
  CAPTION_GENERATION_ERROR: {
    code: 'CAPTION_GENERATION_ERROR',
    severity: 'medium',
    userMessage: 'Failed to generate captions.',
    solution: 'Check audio quality and try processing again'
  },
  SOCIAL_MEDIA_ERROR: {
    code: 'SOCIAL_MEDIA_ERROR',
    severity: 'medium',
    userMessage: 'Unable to post to social media.',
    solution: 'Verify platform credentials and try again'
  },
  AUTHENTICATION_ERROR: {
    code: 'AUTHENTICATION_ERROR',
    severity: 'high',
    userMessage: 'Authentication failed.',
    solution: 'Re-authenticate with the platform'
  },
  STORAGE_ERROR: {
    code: 'STORAGE_ERROR',
    severity: 'high',
    userMessage: 'Storage operation failed.',
    solution: 'Check storage permissions and available space'
  },
  VALIDATION_ERROR: {
    code: 'VALIDATION_ERROR',
    severity: 'low',
    userMessage: 'Invalid input provided.',
    solution: 'Review input requirements and try again'
  },
  NETWORK_ERROR: {
    code: 'NETWORK_ERROR',
    severity: 'medium',
    userMessage: 'Network connection issue.',
    solution: 'Check internet connection and try again'
  },
  UNKNOWN_ERROR: {
    code: 'UNKNOWN_ERROR',
    severity: 'critical',
    userMessage: 'An unexpected error occurred.',
    solution: 'Contact support if the issue persists'
  }
};