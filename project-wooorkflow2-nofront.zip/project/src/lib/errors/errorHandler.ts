import { AppError } from './AppError';
import { ErrorDetails, ErrorLogEntry } from './types';
import { logger } from '../logger';
import { supabase } from '../supabase';

export class ErrorHandler {
  static async handleError(error: unknown): Promise<ErrorLogEntry> {
    const appError = this.normalizeError(error);
    const errorDetails = appError.toJSON();
    
    // Log error
    await this.logError(errorDetails);

    return {
      id: crypto.randomUUID(),
      ...errorDetails,
      userMessage: appError.getUserMessage()
    };
  }

  private static normalizeError(error: unknown): AppError {
    if (error instanceof AppError) {
      return error;
    }

    if (error instanceof Error) {
      return new AppError(
        'UNKNOWN_ERROR',
        error.message,
        { originalError: error.name }
      );
    }

    return new AppError(
      'UNKNOWN_ERROR',
      'An unexpected error occurred',
      { originalError: error }
    );
  }

  private static async logError(details: ErrorDetails): Promise<void> {
    // Log to Winston
    logger.error('Application error:', {
      ...details,
      timestamp: new Date(details.timestamp)
    });

    try {
      // Store in Supabase for persistence
      const { error } = await supabase
        .from('error_logs')
        .insert({
          error_code: details.code,
          message: details.message,
          severity: details.severity,
          context: details.context,
          stack: details.stack,
          timestamp: details.timestamp
        });

      if (error) {
        logger.error('Failed to store error log:', error);
      }
    } catch (error) {
      logger.error('Error logging failed:', error);
    }
  }

  static isNetworkError(error: unknown): boolean {
    if (error instanceof Error) {
      return (
        error.message.includes('network') ||
        error.message.includes('connection') ||
        error.message.includes('offline') ||
        error instanceof TypeError && error.message.includes('fetch')
      );
    }
    return false;
  }

  static isAuthenticationError(error: unknown): boolean {
    if (error instanceof Error) {
      return (
        error.message.includes('authentication') ||
        error.message.includes('unauthorized') ||
        error.message.includes('forbidden') ||
        error.message.includes('token')
      );
    }
    return false;
  }
}