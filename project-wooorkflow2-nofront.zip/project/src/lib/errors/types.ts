export type ErrorCode = 
  | 'MEDIA_UPLOAD_ERROR'
  | 'MEDIA_PROCESSING_ERROR'
  | 'CAPTION_GENERATION_ERROR'
  | 'SOCIAL_MEDIA_ERROR'
  | 'AUTHENTICATION_ERROR'
  | 'STORAGE_ERROR'
  | 'VALIDATION_ERROR'
  | 'NETWORK_ERROR'
  | 'UNKNOWN_ERROR';

export type ErrorSeverity = 'low' | 'medium' | 'high' | 'critical';

export interface ErrorDetails {
  code: ErrorCode;
  message: string;
  severity: ErrorSeverity;
  timestamp: string;
  stack?: string;
  context?: Record<string, unknown>;
  solution?: string;
}

export interface ErrorLogEntry extends ErrorDetails {
  id: string;
  userMessage: string;
}