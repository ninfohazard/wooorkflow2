import { TranscriptionOptions } from './config';
import { AI_CONFIG } from './config';
import { logger } from '../logger';
import { AppError } from '../errors';
import { retry } from '../utils';
import { supabase } from '../supabase';

export interface CaptionSegment {
  start: number;
  end: number;
  text: string;
  speaker?: string;
  sentiment?: 'positive' | 'neutral' | 'negative';
}

export interface TranscriptionResult {
  segments: CaptionSegment[];
  fullText: string;
  language: string;
  metadata?: {
    duration: number;
    wordCount: number;
    confidence: number;
  };
}

export class AICaptionService {
  private openaiKey: string;
  private assemblyaiKey: string;

  constructor() {
    this.openaiKey = import.meta.env.VITE_OPENAI_API_KEY;
    this.assemblyaiKey = import.meta.env.VITE_ASSEMBLYAI_API_KEY;
  }

  async generateCaptions(
    audioBlob: Blob,
    options: TranscriptionOptions,
    onProgress?: (progress: number) => void
  ): Promise<TranscriptionResult> {
    try {
      onProgress?.(0);

      // Use OpenAI Whisper for base transcription
      const whisperResult = await this.transcribeWithWhisper(audioBlob, options.language);
      onProgress?.(50);

      // If advanced features are requested, use AssemblyAI
      if (options.diarization || options.sentiment) {
        const assemblyResult = await this.processWithAssemblyAI(audioBlob, options);
        onProgress?.(100);

        // Merge results for best accuracy
        return this.mergeResults(whisperResult, assemblyResult);
      }

      onProgress?.(100);
      return whisperResult;
    } catch (error) {
      logger.error('Caption generation failed:', error);
      throw new AppError(
        'CAPTION_GENERATION_ERROR',
        error instanceof Error ? error.message : 'Failed to generate captions'
      );
    }
  }

  private async transcribeWithWhisper(
    audioBlob: Blob,
    language: string
  ): Promise<TranscriptionResult> {
    const formData = new FormData();
    formData.append('file', audioBlob);
    formData.append('model', AI_CONFIG.openai.model);
    formData.append('language', language);
    formData.append('response_format', 'verbose_json');
    formData.append('timestamp_granularities', '["segment"]');

    const response = await retry(async () => {
      const result = await fetch(AI_CONFIG.openai.endpoints.transcription, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.openaiKey}`
        },
        body: formData
      });

      if (!result.ok) {
        throw new Error('Transcription failed');
      }

      return await result.json();
    });

    return {
      segments: response.segments.map((segment: any) => ({
        start: segment.start,
        end: segment.end,
        text: segment.text.trim()
      })),
      fullText: response.text,
      language,
      metadata: {
        duration: response.duration,
        wordCount: response.text.split(/\s+/).length,
        confidence: response.segments.reduce((acc: number, s: any) => acc + s.confidence, 0) / response.segments.length
      }
    };
  }

  private async processWithAssemblyAI(
    audioBlob: Blob,
    options: TranscriptionOptions
  ): Promise<TranscriptionResult> {
    // Upload audio to AssemblyAI
    const uploadUrl = await this.uploadToAssemblyAI(audioBlob);

    // Create transcription request
    const response = await fetch('https://api.assemblyai.com/v2/transcript', {
      method: 'POST',
      headers: {
        'Authorization': this.assemblyaiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        audio_url: uploadUrl,
        speaker_labels: options.diarization,
        sentiment_analysis: options.sentiment,
        language_code: options.language
      })
    });

    if (!response.ok) {
      throw new Error('Failed to initiate transcription');
    }

    const { id } = await response.json();

    // Poll for completion
    const result = await this.pollTranscriptionStatus(id);

    return {
      segments: result.words.map(word => ({
        start: word.start,
        end: word.end,
        text: word.text,
        speaker: word.speaker,
        sentiment: word.sentiment
      })),
      fullText: result.text,
      language: options.language,
      metadata: {
        duration: result.audio_duration,
        wordCount: result.words.length,
        confidence: result.confidence
      }
    };
  }

  private async uploadToAssemblyAI(blob: Blob): Promise<string> {
    const response = await fetch('https://api.assemblyai.com/v2/upload', {
      method: 'POST',
      headers: {
        'Authorization': this.assemblyaiKey
      },
      body: blob
    });

    if (!response.ok) {
      throw new Error('Failed to upload audio');
    }

    const { upload_url } = await response.json();
    return upload_url;
  }

  private async pollTranscriptionStatus(id: string): Promise<any> {
    const maxAttempts = 30;
    const interval = 2000;

    for (let i = 0; i < maxAttempts; i++) {
      const response = await fetch(`https://api.assemblyai.com/v2/transcript/${id}`, {
        headers: {
          'Authorization': this.assemblyaiKey
        }
      });

      if (!response.ok) {
        throw new Error('Failed to check transcription status');
      }

      const result = await response.json();

      if (result.status === 'completed') {
        return result;
      }

      if (result.status === 'error') {
        throw new Error(result.error);
      }

      await new Promise(resolve => setTimeout(resolve, interval));
    }

    throw new Error('Transcription timed out');
  }

  private mergeResults(
    whisper: TranscriptionResult,
    assembly: TranscriptionResult
  ): TranscriptionResult {
    // Combine segments using word-level alignment
    const mergedSegments = whisper.segments.map(segment => {
      const assemblySegment = assembly.segments.find(s =>
        Math.abs(s.start - segment.start) < 0.5 &&
        Math.abs(s.end - segment.end) < 0.5
      );

      return {
        ...segment,
        speaker: assemblySegment?.speaker,
        sentiment: assemblySegment?.sentiment
      };
    });

    return {
      segments: mergedSegments,
      fullText: whisper.fullText,
      language: whisper.language,
      metadata: {
        ...whisper.metadata,
        confidence: (whisper.metadata?.confidence || 0 + assembly.metadata?.confidence || 0) / 2
      }
    };
  }

  async saveCaptions(
    mediaId: string,
    captions: TranscriptionResult
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('captions')
        .insert({
          media_id: mediaId,
          segments: captions.segments,
          full_text: captions.fullText,
          language: captions.language
        });

      if (error) throw error;
    } catch (error) {
      logger.error('Failed to save captions:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to save generated captions'
      );
    }
  }
}