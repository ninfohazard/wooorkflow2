import { z } from 'zod';

export const AI_CONFIG = {
  openai: {
    model: 'whisper-1',
    apiVersion: '2024-02',
    maxDuration: 300, // 5 minutes
    supportedLanguages: ['en', 'es', 'fr', 'de', 'it', 'pt', 'nl', 'ja', 'ko', 'zh'],
    defaultLanguage: 'en',
    endpoints: {
      transcription: 'https://api.openai.com/v1/audio/transcriptions',
      translation: 'https://api.openai.com/v1/audio/translations'
    }
  },
  assemblyai: {
    maxDuration: 600, // 10 minutes
    features: {
      punctuation: true,
      speakerDiarization: true,
      sentimentAnalysis: true
    }
  },
  retry: {
    maxAttempts: 3,
    initialDelay: 1000,
    maxDelay: 10000
  }
};

export const TranscriptionOptionsSchema = z.object({
  language: z.string(),
  diarization: z.boolean().default(false),
  sentiment: z.boolean().default(false),
  format: z.enum(['srt', 'vtt', 'json']).default('json'),
  timestamps: z.boolean().default(true)
});

export type TranscriptionOptions = z.infer<typeof TranscriptionOptionsSchema>;