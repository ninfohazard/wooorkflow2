import { supabase } from '../supabase';
import { logger } from '../logger';
import { SocialPlatform } from '../socialMedia/types';

export interface OAuthState {
  platform: SocialPlatform;
  redirectUri: string;
  timestamp: number;
}

export interface OAuthConfig {
  clientId: string;
  clientSecret: string;
  scopes: string[];
  authUrl: string;
  tokenUrl: string;
}

export class OAuthManager {
  private static readonly STATE_KEY = 'oauth_state';
  private static readonly TOKEN_EXPIRY_BUFFER = 300; // 5 minutes in seconds

  private static readonly PLATFORM_CONFIGS: Record<SocialPlatform, OAuthConfig> = {
    twitter: {
      clientId: import.meta.env.VITE_TWITTER_CLIENT_ID,
      clientSecret: import.meta.env.VITE_TWITTER_CLIENT_SECRET,
      scopes: ['tweet.read', 'tweet.write', 'users.read'],
      authUrl: 'https://twitter.com/i/oauth2/authorize',
      tokenUrl: 'https://api.twitter.com/2/oauth2/token'
    },
    instagram: {
      clientId: import.meta.env.VITE_INSTAGRAM_CLIENT_ID,
      clientSecret: import.meta.env.VITE_INSTAGRAM_CLIENT_SECRET,
      scopes: ['basic', 'publish_media', 'pages_show_list'],
      authUrl: 'https://api.instagram.com/oauth/authorize',
      tokenUrl: 'https://api.instagram.com/oauth/access_token'
    },
    tiktok: {
      clientId: import.meta.env.VITE_TIKTOK_CLIENT_ID,
      clientSecret: import.meta.env.VITE_TIKTOK_CLIENT_SECRET,
      scopes: ['user.info.basic', 'video.publish'],
      authUrl: 'https://www.tiktok.com/auth/authorize/',
      tokenUrl: 'https://open-api.tiktok.com/oauth/access_token/'
    }
  };

  static async initiateOAuth(platform: SocialPlatform): Promise<string> {
    try {
      const config = this.PLATFORM_CONFIGS[platform];
      if (!config) throw new Error(`Unsupported platform: ${platform}`);

      // Generate and store state
      const state = crypto.randomUUID();
      const stateData: OAuthState = {
        platform,
        redirectUri: window.location.origin + '/auth/callback',
        timestamp: Date.now()
      };
      sessionStorage.setItem(this.STATE_KEY, JSON.stringify(stateData));

      // Build authorization URL
      const params = new URLSearchParams({
        client_id: config.clientId,
        redirect_uri: stateData.redirectUri,
        response_type: 'code',
        scope: config.scopes.join(' '),
        state
      });

      return `${config.authUrl}?${params.toString()}`;
    } catch (error) {
      logger.error('OAuth initiation failed:', error);
      throw error;
    }
  }

  static async handleCallback(code: string, state: string): Promise<void> {
    try {
      // Validate state
      const storedState = sessionStorage.getItem(this.STATE_KEY);
      if (!storedState) throw new Error('Invalid OAuth state');

      const stateData: OAuthState = JSON.parse(storedState);
      if (Date.now() - stateData.timestamp > 300000) { // 5 minutes
        throw new Error('OAuth state expired');
      }

      sessionStorage.removeItem(this.STATE_KEY);

      // Exchange code for tokens
      const config = this.PLATFORM_CONFIGS[stateData.platform];
      const response = await fetch(config.tokenUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: config.clientId,
          client_secret: config.clientSecret,
          grant_type: 'authorization_code',
          code,
          redirect_uri: stateData.redirectUri
        })
      });

      if (!response.ok) {
        throw new Error('Token exchange failed');
      }

      const tokens = await response.json();

      // Store tokens in Supabase
      const { error } = await supabase
        .from('social_tokens')
        .upsert({
          platform: stateData.platform,
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token,
          expires_at: new Date(Date.now() + tokens.expires_in * 1000).toISOString()
        });

      if (error) throw error;
    } catch (error) {
      logger.error('OAuth callback handling failed:', error);
      throw error;
    }
  }

  static async refreshToken(platform: SocialPlatform): Promise<boolean> {
    try {
      // Get stored tokens
      const { data: tokens } = await supabase
        .from('social_tokens')
        .select('refresh_token')
        .eq('platform', platform)
        .single();

      if (!tokens?.refresh_token) {
        return false;
      }

      const config = this.PLATFORM_CONFIGS[platform];
      const response = await fetch(config.tokenUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: config.clientId,
          client_secret: config.clientSecret,
          grant_type: 'refresh_token',
          refresh_token: tokens.refresh_token
        })
      });

      if (!response.ok) {
        return false;
      }

      const newTokens = await response.json();

      // Update stored tokens
      const { error } = await supabase
        .from('social_tokens')
        .update({
          access_token: newTokens.access_token,
          refresh_token: newTokens.refresh_token,
          expires_at: new Date(Date.now() + newTokens.expires_in * 1000).toISOString()
        })
        .eq('platform', platform);

      if (error) throw error;
      return true;
    } catch (error) {
      logger.error('Token refresh failed:', error);
      return false;
    }
  }

  static async checkTokenStatus(platform: SocialPlatform): Promise<{
    isValid: boolean;
    needsRefresh: boolean;
  }> {
    try {
      const { data: tokens } = await supabase
        .from('social_tokens')
        .select('expires_at')
        .eq('platform', platform)
        .single();

      if (!tokens) {
        return { isValid: false, needsRefresh: false };
      }

      const expiresAt = new Date(tokens.expires_at).getTime();
      const now = Date.now();

      return {
        isValid: expiresAt > now,
        needsRefresh: expiresAt - now < this.TOKEN_EXPIRY_BUFFER * 1000
      };
    } catch (error) {
      logger.error('Token status check failed:', error);
      return { isValid: false, needsRefresh: false };
    }
  }
}