import { supabase } from '../supabase';
import { logger } from '../logger';
import { AppError } from '../errors';
import { retry } from '../utils';
import { SocialMediaManager } from '../socialMedia/socialMediaManager';
import { AUTO_POSTER_CONFIG } from './config';
import {
  PostSchedule,
  PostQueueItem,
  PostingService,
  RateLimit,
  PostResult,
  PostProgress
} from './types';

export class AutoPosterManager {
  private socialManager: SocialMediaManager;
  private queueCheckInterval: number | null = null;
  private processingPosts = new Set<string>();

  constructor() {
    this.socialManager = new SocialMediaManager();
  }

  async schedulePost(
    mediaId: string,
    caption: string,
    platforms: string[],
    scheduledFor: Date,
    metadata?: Record<string, unknown>
  ): Promise<string> {
    try {
      // Validate platforms
      await this.validatePlatforms(platforms);

      // Create schedule
      const { data: schedule, error: scheduleError } = await supabase
        .from('post_schedules')
        .insert({
          media_id: mediaId,
          caption,
          platforms,
          scheduled_for: scheduledFor.toISOString(),
          metadata
        })
        .select()
        .single();

      if (scheduleError) throw scheduleError;

      // Add to queue
      const { error: queueError } = await supabase
        .from('post_queue')
        .insert({
          schedule_id: schedule.id,
          priority: AUTO_POSTER_CONFIG.defaultPriority
        });

      if (queueError) throw queueError;

      return schedule.id;
    } catch (error) {
      logger.error('Failed to schedule post:', error);
      throw new AppError(
        'SOCIAL_MEDIA_ERROR',
        'Failed to schedule post'
      );
    }
  }

  async startQueueProcessor(): Promise<void> {
    if (this.queueCheckInterval) return;

    this.queueCheckInterval = window.setInterval(
      () => this.processQueue(),
      5000 // Check every 5 seconds
    );

    logger.info('Queue processor started');
  }

  async stopQueueProcessor(): Promise<void> {
    if (this.queueCheckInterval) {
      clearInterval(this.queueCheckInterval);
      this.queueCheckInterval = null;
      logger.info('Queue processor stopped');
    }
  }

  private async processQueue(): Promise<void> {
    if (this.processingPosts.size >= AUTO_POSTER_CONFIG.maxConcurrentPosts) {
      return;
    }

    try {
      // Get next items from queue
      const { data: queueItems } = await supabase
        .from('post_queue')
        .select(`
          id,
          schedule_id,
          priority,
          post_schedules (
            id,
            media_id,
            caption,
            platforms,
            scheduled_for,
            status,
            attempts
          )
        `)
        .eq('post_schedules.status', 'pending')
        .lte('post_schedules.scheduled_for', new Date().toISOString())
        .order('priority', { ascending: false })
        .limit(AUTO_POSTER_CONFIG.maxConcurrentPosts - this.processingPosts.size);

      if (!queueItems?.length) return;

      // Process each item
      for (const item of queueItems) {
        const schedule = item.post_schedules;
        if (this.processingPosts.has(schedule.id)) continue;

        this.processingPosts.add(schedule.id);
        this.processPost(schedule as PostSchedule, item as PostQueueItem)
          .finally(() => {
            this.processingPosts.delete(schedule.id);
          });
      }
    } catch (error) {
      logger.error('Queue processing error:', error);
    }
  }

  private async processPost(
    schedule: PostSchedule,
    queueItem: PostQueueItem
  ): Promise<void> {
    try {
      // Lock queue item
      const { error: lockError } = await supabase
        .from('post_queue')
        .update({
          locked_at: new Date().toISOString(),
          locked_by: 'processor'
        })
        .eq('id', queueItem.id)
        .eq('locked_at', null);

      if (lockError) return;

      // Update schedule status
      await supabase
        .from('post_schedules')
        .update({
          status: 'processing',
          attempts: schedule.attempts + 1,
          last_attempt: new Date().toISOString()
        })
        .eq('id', schedule.id);

      // Check rate limits
      await this.checkRateLimits(schedule.platforms);

      // Get media URL
      const { data: mediaData } = await supabase
        .storage
        .from('media')
        .createSignedUrl(`${schedule.mediaId}`, 3600); // 1 hour expiry

      if (!mediaData?.signedUrl) {
        throw new Error('Failed to get media URL');
      }

      // Post to each platform
      const results = await Promise.all(
        schedule.platforms.map(platform =>
          this.postToPlatform(platform, mediaData.signedUrl!, schedule)
        )
      );

      // Update schedule with results
      const success = results.every(r => r.success);
      await supabase
        .from('post_schedules')
        .update({
          status: success ? 'completed' : 'failed',
          error_message: success ? null : results
            .filter(r => !r.success)
            .map(r => r.error)
            .join('; '),
          metadata: {
            ...schedule.metadata,
            results
          }
        })
        .eq('id', schedule.id);

      // Remove from queue if successful
      if (success) {
        await supabase
          .from('post_queue')
          .delete()
          .eq('id', queueItem.id);
      } else if (schedule.attempts < AUTO_POSTER_CONFIG.maxRetries) {
        // Unlock for retry
        await supabase
          .from('post_queue')
          .update({
            locked_at: null,
            locked_by: null,
            priority: queueItem.priority - 1 // Lower priority for retries
          })
          .eq('id', queueItem.id);
      } else {
        // Max retries reached, remove from queue
        await supabase
          .from('post_queue')
          .delete()
          .eq('id', queueItem.id);
      }
    } catch (error) {
      logger.error('Post processing failed:', error);

      // Update schedule status
      await supabase
        .from('post_schedules')
        .update({
          status: 'failed',
          error_message: error instanceof Error ? error.message : 'Unknown error'
        })
        .eq('id', schedule.id);

      // Unlock queue item for retry
      if (schedule.attempts < AUTO_POSTER_CONFIG.maxRetries) {
        await supabase
          .from('post_queue')
          .update({
            locked_at: null,
            locked_by: null
          })
          .eq('id', queueItem.id);
      } else {
        await supabase
          .from('post_queue')
          .delete()
          .eq('id', queueItem.id);
      }
    }
  }

  private async postToPlatform(
    platform: string,
    mediaUrl: string,
    schedule: PostSchedule
  ): Promise<PostResult> {
    try {
      // Check if using third-party service
      const service = await this.getPostingService(platform);
      if (service) {
        return await this.postWithService(service, mediaUrl, schedule);
      }

      // Post directly using social media manager
      return await retry(async () => {
        const result = await this.socialManager.post(
          mediaUrl,
          {
            caption: schedule.caption || '',
            tags: [],
            platforms: [platform]
          }
        );
        return result[0];
      });
    } catch (error) {
      logger.error(`Failed to post to ${platform}:`, error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Post failed'
      };
    }
  }

  private async postWithService(
    service: PostingService,
    mediaUrl: string,
    schedule: PostSchedule
  ): Promise<PostResult> {
    // Implementation would integrate with third-party posting services
    throw new Error('Third-party service posting not implemented');
  }

  private async validatePlatforms(platforms: string[]): Promise<void> {
    const invalidPlatforms = platforms.filter(
      platform => !AUTO_POSTER_CONFIG.platforms[platform as keyof typeof AUTO_POSTER_CONFIG.platforms]
    );

    if (invalidPlatforms.length > 0) {
      throw new Error(`Invalid platforms: ${invalidPlatforms.join(', ')}`);
    }

    // Check authentication for each platform
    const authResults = await Promise.all(
      platforms.map(platform => this.socialManager.authenticate(platform))
    );

    const unauthenticatedPlatforms = platforms.filter((_, i) => !authResults[i]);
    if (unauthenticatedPlatforms.length > 0) {
      throw new Error(`Not authenticated for platforms: ${unauthenticatedPlatforms.join(', ')}`);
    }
  }

  private async checkRateLimits(platforms: string[]): Promise<void> {
    const { data: limits } = await supabase
      .from('platform_rate_limits')
      .select('*')
      .in('platform', platforms);

    if (!limits) return;

    const now = new Date();
    for (const limit of limits) {
      if (
        limit.requests_remaining <= AUTO_POSTER_CONFIG.rateLimitBuffer ||
        new Date(limit.reset_at) <= now
      ) {
        throw new Error(`Rate limit reached for ${limit.platform}`);
      }
    }
  }

  private async getPostingService(platform: string): Promise<PostingService | null> {
    const { data: service } = await supabase
      .from('posting_services')
      .select('*')
      .eq('platform', platform)
      .eq('enabled', true)
      .single();

    return service;
  }
}