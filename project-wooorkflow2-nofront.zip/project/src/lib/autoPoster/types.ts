export type PostStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';

export interface PostSchedule {
  id: string;
  mediaId: string;
  caption?: string;
  platforms: string[];
  scheduledFor: Date;
  status: PostStatus;
  attempts: number;
  lastAttempt?: Date;
  errorMessage?: string;
  metadata?: Record<string, unknown>;
}

export interface PostQueueItem {
  id: string;
  scheduleId: string;
  priority: number;
  lockedAt?: Date;
  lockedBy?: string;
}

export interface PostingService {
  id: string;
  name: string;
  credentials: Record<string, unknown>;
  enabled: boolean;
  lastUsedAt?: Date;
}

export interface RateLimit {
  platform: string;
  requestsRemaining: number;
  resetAt: Date;
}

export interface AutoPosterConfig {
  maxRetries: number;
  retryDelay: number;
  maxConcurrentPosts: number;
  defaultPriority: number;
  rateLimitBuffer: number;
}

export interface PostResult {
  success: boolean;
  postUrl?: string;
  error?: string;
  platformResponse?: unknown;
}

export interface PostProgress {
  scheduleId: string;
  platform: string;
  status: 'uploading' | 'processing' | 'complete' | 'error';
  progress: number;
  message?: string;
}