export const AUTO_POSTER_CONFIG = {
  maxRetries: 3,
  retryDelay: 5000, // 5 seconds
  maxConcurrentPosts: 5,
  defaultPriority: 0,
  rateLimitBuffer: 10, // Keep 10% of rate limit as buffer
  platforms: {
    twitter: {
      maxFileSize: 512 * 1024 * 1024, // 512MB
      supportedFormats: ['mp4', 'mov'],
      maxDuration: 140, // seconds
      rateLimit: {
        postsPerDay: 200,
        resetInterval: 24 * 60 * 60 * 1000 // 24 hours
      }
    },
    instagram: {
      maxFileSize: 100 * 1024 * 1024, // 100MB
      supportedFormats: ['mp4', 'mov'],
      maxDuration: 60,
      rateLimit: {
        postsPerHour: 25,
        resetInterval: 60 * 60 * 1000 // 1 hour
      }
    },
    tiktok: {
      maxFileSize: 2048 * 1024 * 1024, // 2GB
      supportedFormats: ['mp4', 'mov'],
      maxDuration: 180,
      rateLimit: {
        postsPerDay: 50,
        resetInterval: 24 * 60 * 60 * 1000
      }
    }
  },
  thirdPartyServices: {
    buffer: {
      apiEndpoint: 'https://api.buffer.com/v1',
      scopes: ['write', 'read']
    },
    hootsuite: {
      apiEndpoint: 'https://platform.hootsuite.com/v1',
      scopes: ['offline', 'social']
    }
  }
};