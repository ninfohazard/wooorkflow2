import { MediaValidationResult, MediaConfig } from './types';

export class MediaValidator {
  private config: MediaConfig;
  private readonly FORBIDDEN_EXTENSIONS = [
    '.exe', '.dll', '.bat', '.cmd', '.sh', '.js',
    '.msi', '.dmg', '.app', '.vbs', '.wsf'
  ];

  constructor(config: MediaConfig) {
    this.config = config;
  }

  async validateFile(file: File): Promise<MediaValidationResult> {
    // Check file size
    if (file.size > this.config.maxSizeInBytes) {
      return {
        isValid: false,
        error: `File size exceeds maximum limit of ${this.config.maxSizeInBytes / (1024 * 1024)}MB`
      };
    }

    // Check file type
    if (!this.config.allowedTypes.includes(file.type)) {
      return {
        isValid: false,
        error: 'File type not supported'
      };
    }

    // Check for forbidden extensions
    const fileName = file.name.toLowerCase();
    if (this.FORBIDDEN_EXTENSIONS.some(ext => fileName.endsWith(ext))) {
      return {
        isValid: false,
        error: 'File type not allowed for security reasons'
      };
    }

    // Check file integrity
    try {
      const isIntact = await this.checkFileIntegrity(file);
      if (!isIntact) {
        return {
          isValid: false,
          error: 'File appears to be corrupted'
        };
      }
    } catch (error) {
      return {
        isValid: false,
        error: 'Failed to validate file integrity'
      };
    }

    // Validate media header
    try {
      const isValidMedia = await this.validateMediaHeader(file);
      if (!isValidMedia) {
        return {
          isValid: false,
          error: 'Invalid media file format'
        };
      }
    } catch (error) {
      return {
        isValid: false,
        error: 'Failed to validate media format'
      };
    }

    return { isValid: true };
  }

  private async checkFileIntegrity(file: File): Promise<boolean> {
    return new Promise((resolve) => {
      const reader = new FileReader();
      
      reader.onload = () => resolve(true);
      reader.onerror = () => resolve(false);
      
      // Read the first few bytes to check if the file is readable
      reader.readAsArrayBuffer(file.slice(0, 8192));
    });
  }

  private async validateMediaHeader(file: File): Promise<boolean> {
    try {
      const buffer = await file.slice(0, 12).arrayBuffer();
      const header = new Uint8Array(buffer);
      
      // Check for common media file signatures
      const signatures = {
        // MP4 signatures
        mp4: [[0x66, 0x74, 0x79, 0x70], [0x6D, 0x6D, 0x70, 0x34]],
        // WebM signature
        webm: [[0x1A, 0x45, 0xDF, 0xA3]],
        // WAV signature
        wav: [[0x52, 0x49, 0x46, 0x46]],
        // MP3 signatures
        mp3: [[0x49, 0x44, 0x33], [0xFF, 0xFB], [0xFF, 0xF3]],
        // OGG signature
        ogg: [[0x4F, 0x67, 0x67, 0x53]]
      };

      // Check if the file header matches any known signatures
      return Object.values(signatures).some(formatSignatures =>
        formatSignatures.some(signature =>
          signature.every((byte, i) => header[i] === byte)
        )
      );
    } catch (error) {
      console.error('Media header validation error:', error);
      return false;
    }
  }

  async validateMediaStream(stream: MediaStream): Promise<MediaValidationResult> {
    const tracks = stream.getTracks();
    
    if (tracks.length === 0) {
      return {
        isValid: false,
        error: 'No media tracks found in stream'
      };
    }

    // Check if any track is muted or ended
    const invalidTrack = tracks.find(track => track.muted || track.readyState === 'ended');
    if (invalidTrack) {
      return {
        isValid: false,
        error: 'Media stream contains invalid tracks'
      };
    }

    // Validate track constraints
    for (const track of tracks) {
      const settings = track.getSettings();
      
      if (track.kind === 'video') {
        // Ensure video track meets minimum quality requirements
        if (settings.width && settings.width < 640 || settings.height && settings.height < 480) {
          return {
            isValid: false,
            error: 'Video quality too low (minimum 640x480 required)'
          };
        }
      } else if (track.kind === 'audio') {
        // Ensure audio track meets minimum quality requirements
        if (settings.sampleRate && settings.sampleRate < 44100) {
          return {
            isValid: false,
            error: 'Audio quality too low (minimum 44.1kHz required)'
          };
        }
      }
    }

    return { isValid: true };
  }
}