export type StorageDevice = {
  id: string;
  name: string;
  type: 'local' | 'external' | 'cloud';
  available: boolean;
  capacity?: number;
  freeSpace?: number;
};

export type MediaSource = {
  id: string;
  label: string;
  type: 'videoinput' | 'audioinput';
};

export type MediaValidationResult = {
  isValid: boolean;
  error?: string;
};

export type MediaConfig = {
  maxSizeInBytes: number;
  allowedTypes: string[];
  maxDurationInSeconds: number;
};