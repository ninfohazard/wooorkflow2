import { MediaSource } from './types';

export class MediaCapture {
  private stream: MediaStream | null = null;

  async getAvailableDevices(): Promise<MediaSource[]> {
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true, video: true })
        .catch(() => null); // This triggers permission prompt

      const devices = await navigator.mediaDevices.enumerateDevices();
      
      return devices
        .filter(device => device.kind === 'videoinput' || device.kind === 'audioinput')
        .map(device => ({
          id: device.deviceId,
          label: device.label || `${device.kind} device`,
          type: device.kind as 'videoinput' | 'audioinput'
        }));
    } catch (error) {
      console.error('Error getting media devices:', error);
      return [];
    }
  }

  async startCapture(deviceId: string, type: 'video' | 'audio'): Promise<MediaStream | null> {
    try {
      const constraints = type === 'video'
        ? {
            video: { deviceId: { exact: deviceId } },
            audio: true
          }
        : {
            audio: { deviceId: { exact: deviceId } }
          };

      this.stream = await navigator.mediaDevices.getUserMedia(constraints);
      return this.stream;
    } catch (error) {
      console.error('Error starting media capture:', error);
      return null;
    }
  }

  stopCapture() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
  }
}