// Add cleanup method
static async cleanupTemporaryMedia(tempId: string): Promise<void> {
  try {
    const existingData = localStorage.getItem(this.TEMP_STORAGE_KEY);
    if (!existingData) return;

    const tempStorage = JSON.parse(existingData);
    delete tempStorage[tempId];
    localStorage.setItem(this.TEMP_STORAGE_KEY, JSON.stringify(tempStorage));
  } catch (error) {
    console.error('Cleanup error:', error);
  }
}