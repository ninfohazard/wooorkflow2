import { StorageDetector } from './storageDetector';
import { MediaValidator } from './mediaValidator';
import { MediaCapture } from './mediaCapture';
import { StorageDevice, MediaValidationResult } from './types';
import { MEDIA_CONFIG } from './config';
import { logger } from '../logger';
import { AppError } from '../errors';
import { StorageManager } from '../storage/storageManager';

export class MediaUploadManager {
  private storageDetector: StorageDetector;
  private mediaValidator: MediaValidator;
  private mediaCapture: MediaCapture;
  private storageManager: StorageManager;

  constructor() {
    this.storageDetector = new StorageDetector();
    this.mediaValidator = new MediaValidator(MEDIA_CONFIG);
    this.mediaCapture = new MediaCapture();
    this.storageManager = new StorageManager();
  }

  async getAvailableStorageDevices(): Promise<StorageDevice[]> {
    try {
      return await this.storageDetector.detectAvailableStorage();
    } catch (error) {
      logger.error('Failed to detect storage devices:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to detect available storage devices'
      );
    }
  }

  async requestStorageAccess(deviceId: string): Promise<boolean> {
    try {
      return await this.storageDetector.requestStorageAccess(deviceId);
    } catch (error) {
      logger.error('Failed to request storage access:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to get storage access permission'
      );
    }
  }

  async validateFile(file: File): Promise<MediaValidationResult> {
    try {
      return await this.mediaValidator.validateFile(file);
    } catch (error) {
      logger.error('File validation failed:', error);
      throw new AppError(
        'VALIDATION_ERROR',
        'Failed to validate media file'
      );
    }
  }

  async uploadFile(
    file: File,
    userId: string,
    onProgress?: (progress: number) => void
  ): Promise<string> {
    try {
      // Validate file first
      const validationResult = await this.validateFile(file);
      if (!validationResult.isValid) {
        throw new AppError(
          'VALIDATION_ERROR',
          validationResult.error || 'Invalid file'
        );
      }

      // Store file in temporary storage
      const fileId = await this.storageManager.storeFile(file, userId, true);
      
      onProgress?.(100);
      return fileId;
    } catch (error) {
      logger.error('File upload failed:', error);
      throw new AppError(
        'MEDIA_UPLOAD_ERROR',
        'Failed to upload media file'
      );
    }
  }

  async startMediaCapture(
    deviceId: string,
    type: 'video' | 'audio'
  ): Promise<MediaStream> {
    try {
      const stream = await this.mediaCapture.startCapture(deviceId, type);
      if (!stream) {
        throw new Error('Failed to start media capture');
      }
      return stream;
    } catch (error) {
      logger.error('Media capture failed:', error);
      throw new AppError(
        'MEDIA_UPLOAD_ERROR',
        'Failed to start media capture'
      );
    }
  }

  async saveMediaStream(
    stream: MediaStream,
    userId: string,
    onProgress?: (progress: number) => void
  ): Promise<string> {
    try {
      // Validate the stream
      const validationResult = await this.mediaValidator.validateMediaStream(stream);
      if (!validationResult.isValid) {
        throw new AppError(
          'VALIDATION_ERROR',
          validationResult.error || 'Invalid media stream'
        );
      }

      // Create a MediaRecorder and record the stream
      const chunks: Blob[] = [];
      const mediaRecorder = new MediaRecorder(stream);

      return new Promise((resolve, reject) => {
        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            chunks.push(event.data);
          }
        };

        mediaRecorder.onstop = async () => {
          try {
            const blob = new Blob(chunks, { 
              type: mediaRecorder.mimeType 
            });
            const file = new File([blob], 'recorded-media', { 
              type: mediaRecorder.mimeType 
            });

            const fileId = await this.uploadFile(file, userId, onProgress);
            resolve(fileId);
          } catch (error) {
            reject(error);
          }
        };

        mediaRecorder.onerror = (event) => {
          reject(new Error('MediaRecorder error: ' + event.error));
        };

        mediaRecorder.start();
        
        // Stop recording after configured duration
        setTimeout(() => {
          mediaRecorder.stop();
          stream.getTracks().forEach(track => track.stop());
        }, MEDIA_CONFIG.maxDurationInSeconds * 1000);
      });
    } catch (error) {
      logger.error('Media stream save failed:', error);
      throw new AppError(
        'MEDIA_UPLOAD_ERROR',
        'Failed to save media stream'
      );
    }
  }

  stopMediaCapture(stream: MediaStream): void {
    this.mediaCapture.stopCapture();
    stream.getTracks().forEach(track => track.stop());
  }

  async cleanup(fileId: string, userId: string): Promise<void> {
    try {
      await this.storageManager.deleteFile(fileId, userId);
    } catch (error) {
      logger.error('Media cleanup failed:', error);
    }
  }
}