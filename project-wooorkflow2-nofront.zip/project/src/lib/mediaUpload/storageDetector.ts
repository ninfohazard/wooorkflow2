import { StorageDevice } from './types';

export class StorageDetector {
  private devices: StorageDevice[] = [];

  async detectAvailableStorage(): Promise<StorageDevice[]> {
    try {
      // Check if browser supports storage estimation
      if ('storage' in navigator && 'estimate' in navigator.storage) {
        const { quota, usage } = await navigator.storage.estimate();
        this.devices.push({
          id: 'browser-storage',
          name: 'Browser Storage',
          type: 'local',
          available: true,
          capacity: quota,
          freeSpace: quota ? quota - (usage || 0) : undefined
        });
      }

      // Check for File System Access API support
      if ('showDirectoryPicker' in window) {
        this.devices.push({
          id: 'file-system',
          name: 'File System',
          type: 'local',
          available: true
        });
      }

      // Check for connected USB devices
      if ('usb' in navigator) {
        try {
          const devices = await navigator.usb.getDevices();
          devices.forEach(device => {
            this.devices.push({
              id: `usb-${device.serialNumber}`,
              name: `USB Device (${device.productName || 'Unknown'})`,
              type: 'external',
              available: true
            });
          });
        } catch (error) {
          console.warn('USB detection error:', error);
        }
      }

      return this.devices;
    } catch (error) {
      console.error('Error detecting storage devices:', error);
      return [];
    }
  }

  async requestStorageAccess(deviceId: string): Promise<boolean> {
    try {
      const device = this.devices.find(d => d.id === deviceId);
      if (!device) throw new Error('Device not found');

      switch (device.type) {
        case 'local':
          // Request permission to access local file system
          await window.showDirectoryPicker();
          return true;

        case 'external':
          // Request USB device access
          if ('usb' in navigator) {
            await navigator.usb.requestDevice({ filters: [] });
            return true;
          }
          return false;

        default:
          return false;
      }
    } catch (error) {
      console.error('Error requesting storage access:', error);
      return false;
    }
  }
}