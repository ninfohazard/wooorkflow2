export const MEDIA_CONFIG = {
  maxSizeInBytes: 100 * 1024 * 1024, // 100MB
  allowedTypes: [
    'video/mp4',
    'video/webm',
    'video/quicktime',
    'audio/mpeg',
    'audio/wav',
    'audio/ogg'
  ],
  maxDurationInSeconds: 300 // 5 minutes
};