// Add auto-save functionality
private autoSaveInterval: number | null = null;
private lastChangeTimestamp: number = 0;
private readonly AUTO_SAVE_DELAY = 30000; // 30 seconds

private startAutoSave(): void {
  if (this.autoSaveInterval) return;
  
  this.autoSaveInterval = window.setInterval(async () => {
    if (Date.now() - this.lastChangeTimestamp >= this.AUTO_SAVE_DELAY) {
      try {
        await this.saveEdits(this.currentMediaId);
      } catch (error) {
        logger.error('Auto-save failed:', error);
      }
    }
  }, this.AUTO_SAVE_DELAY);
}

private stopAutoSave(): void {
  if (this.autoSaveInterval) {
    clearInterval(this.autoSaveInterval);
    this.autoSaveInterval = null;
  }
}