export interface TimeRange {
  start: number;
  end: number;
}

export interface EditOperation {
  type: 'trim' | 'cut' | 'merge';
  ranges: TimeRange[];
}

export interface EditableCaption {
  id: string;
  start: number;
  end: number;
  text: string;
}

export interface EditResult {
  url: string;
  duration: number;
  captions: EditableCaption[];
}

export interface EditorProgress {
  status: 'processing' | 'saving' | 'complete' | 'error';
  progress: number;
  message?: string;
}