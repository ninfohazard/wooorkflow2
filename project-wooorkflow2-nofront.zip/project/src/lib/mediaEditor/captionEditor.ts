import { EditableCaption } from './types';
import { logger } from '../logger';

export class CaptionEditor {
  private captions: EditableCaption[];

  constructor(captions: EditableCaption[]) {
    this.captions = [...captions];
  }

  editCaption(id: string, text: string): void {
    const caption = this.captions.find(c => c.id === id);
    if (!caption) {
      throw new Error('Caption not found');
    }
    caption.text = text;
  }

  adjustTiming(id: string, start: number, end: number): void {
    const caption = this.captions.find(c => c.id === id);
    if (!caption) {
      throw new Error('Caption not found');
    }

    // Validate timing
    if (start < 0 || end <= start) {
      throw new Error('Invalid timing values');
    }

    // Check for overlaps
    const overlap = this.captions.find(c => 
      c.id !== id && 
      ((start >= c.start && start < c.end) || 
       (end > c.start && end <= c.end))
    );

    if (overlap) {
      throw new Error('Timing overlaps with another caption');
    }

    caption.start = start;
    caption.end = end;
  }

  splitCaption(id: string, splitPoint: number): void {
    const index = this.captions.findIndex(c => c.id === id);
    if (index === -1) {
      throw new Error('Caption not found');
    }

    const caption = this.captions[index];
    if (splitPoint <= caption.start || splitPoint >= caption.end) {
      throw new Error('Invalid split point');
    }

    const words = caption.text.split(' ');
    const splitIndex = Math.floor(words.length * ((splitPoint - caption.start) / (caption.end - caption.start)));

    const firstPart = words.slice(0, splitIndex).join(' ');
    const secondPart = words.slice(splitIndex).join(' ');

    this.captions.splice(index, 1, 
      {
        id: crypto.randomUUID(),
        start: caption.start,
        end: splitPoint,
        text: firstPart
      },
      {
        id: crypto.randomUUID(),
        start: splitPoint,
        end: caption.end,
        text: secondPart
      }
    );
  }

  mergeCaptions(ids: string[]): void {
    if (ids.length < 2) {
      throw new Error('At least two captions are required for merging');
    }

    const captionsToMerge = ids
      .map(id => this.captions.find(c => c.id === id))
      .filter((c): c is EditableCaption => c !== undefined)
      .sort((a, b) => a.start - b.start);

    if (captionsToMerge.length !== ids.length) {
      throw new Error('One or more captions not found');
    }

    // Ensure captions are consecutive
    for (let i = 1; i < captionsToMerge.length; i++) {
      if (captionsToMerge[i].start !== captionsToMerge[i - 1].end) {
        throw new Error('Captions must be consecutive to merge');
      }
    }

    const mergedCaption: EditableCaption = {
      id: crypto.randomUUID(),
      start: captionsToMerge[0].start,
      end: captionsToMerge[captionsToMerge.length - 1].end,
      text: captionsToMerge.map(c => c.text).join(' ')
    };

    // Remove original captions and add merged one
    this.captions = this.captions
      .filter(c => !ids.includes(c.id))
      .concat(mergedCaption)
      .sort((a, b) => a.start - b.start);
  }

  getCaptions(): EditableCaption[] {
    return [...this.captions];
  }

  validateCaptions(): boolean {
    try {
      // Check for gaps and overlaps
      const sorted = [...this.captions].sort((a, b) => a.start - b.start);
      
      for (let i = 1; i < sorted.length; i++) {
        if (sorted[i].start < sorted[i - 1].end) {
          logger.error('Caption validation failed: Overlapping timestamps detected');
          return false;
        }
      }

      // Check for empty captions
      const emptyCaption = sorted.find(c => !c.text.trim());
      if (emptyCaption) {
        logger.error('Caption validation failed: Empty caption detected');
        return false;
      }

      return true;
    } catch (error) {
      logger.error('Caption validation failed:', error);
      return false;
    }
  }
}