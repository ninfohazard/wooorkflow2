export const EDITOR_CONFIG = {
  maxClipDuration: 300, // 5 minutes
  minClipDuration: 1, // 1 second
  maxMergeClips: 5,
  supportedVideoFormats: ['mp4', 'webm'],
  supportedAudioFormats: ['mp3', 'wav'],
  outputFormat: {
    video: 'mp4',
    audio: 'mp3'
  },
  ffmpegOptions: {
    video: ['-c:v', 'libx264', '-preset', 'fast', '-crf', '22'],
    audio: ['-c:a', 'aac', '-b:a', '128k']
  }
};