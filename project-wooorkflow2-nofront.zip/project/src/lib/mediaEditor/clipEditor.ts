import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL } from '@ffmpeg/util';
import { EditOperation, TimeRange, EditorProgress } from './types';
import { EDITOR_CONFIG } from './config';
import { logger } from '../logger';

export class ClipEditor {
  private ffmpeg: FFmpeg | null = null;

  async initialize(): Promise<void> {
    try {
      this.ffmpeg = new FFmpeg();
      const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.4/dist/umd';
      await this.ffmpeg.load({
        coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
        wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
      });
    } catch (error) {
      logger.error('Failed to initialize FFmpeg:', error);
      throw new Error('Failed to initialize media editor');
    }
  }

  async editClip(
    file: File,
    operation: EditOperation,
    onProgress?: (progress: EditorProgress) => void
  ): Promise<Blob> {
    if (!this.ffmpeg) {
      throw new Error('FFmpeg not initialized');
    }

    try {
      const isVideo = file.type.startsWith('video/');
      const inputFileName = `input.${isVideo ? 'mp4' : 'mp3'}`;
      const outputFileName = `output.${isVideo ? 'mp4' : 'mp3'}`;

      // Write input file
      await this.ffmpeg.writeFile(inputFileName, await file.arrayBuffer());

      onProgress?.({
        status: 'processing',
        progress: 20,
        message: 'Processing media...'
      });

      // Apply edit operation
      switch (operation.type) {
        case 'trim':
          await this.trimClip(inputFileName, outputFileName, operation.ranges[0]);
          break;
        case 'cut':
          await this.cutClip(inputFileName, outputFileName, operation.ranges);
          break;
        case 'merge':
          // For merge, we expect multiple input files to be provided
          throw new Error('Merge operation requires multiple input files');
      }

      onProgress?.({
        status: 'saving',
        progress: 80,
        message: 'Finalizing...'
      });

      // Read output file
      const data = await this.ffmpeg.readFile(outputFileName);
      const outputBlob = new Blob([data], { type: isVideo ? 'video/mp4' : 'audio/mp3' });

      onProgress?.({
        status: 'complete',
        progress: 100,
        message: 'Edit completed successfully'
      });

      return outputBlob;
    } catch (error) {
      logger.error('Media editing failed:', error);
      
      onProgress?.({
        status: 'error',
        progress: 0,
        message: error instanceof Error ? error.message : 'Failed to edit media'
      });

      throw error;
    } finally {
      await this.cleanup();
    }
  }

  async mergeClips(
    files: File[],
    onProgress?: (progress: EditorProgress) => void
  ): Promise<Blob> {
    if (!this.ffmpeg) {
      throw new Error('FFmpeg not initialized');
    }

    if (files.length > EDITOR_CONFIG.maxMergeClips) {
      throw new Error(`Cannot merge more than ${EDITOR_CONFIG.maxMergeClips} clips`);
    }

    try {
      const isVideo = files[0].type.startsWith('video/');
      const concatFile = 'concat.txt';
      const outputFileName = `output.${isVideo ? 'mp4' : 'mp3'}`;

      // Write all input files and create concat file
      let concatContent = '';
      for (let i = 0; i < files.length; i++) {
        const inputFileName = `input${i}.${isVideo ? 'mp4' : 'mp3'}`;
        await this.ffmpeg.writeFile(inputFileName, await files[i].arrayBuffer());
        concatContent += `file '${inputFileName}'\n`;

        onProgress?.({
          status: 'processing',
          progress: (i / files.length) * 50,
          message: `Processing file ${i + 1} of ${files.length}...`
        });
      }

      await this.ffmpeg.writeFile(concatFile, concatContent);

      // Merge files
      await this.ffmpeg.exec([
        '-f', 'concat',
        '-safe', '0',
        '-i', concatFile,
        '-c', 'copy',
        outputFileName
      ]);

      onProgress?.({
        status: 'saving',
        progress: 80,
        message: 'Finalizing merge...'
      });

      // Read output file
      const data = await this.ffmpeg.readFile(outputFileName);
      const outputBlob = new Blob([data], { type: isVideo ? 'video/mp4' : 'audio/mp3' });

      onProgress?.({
        status: 'complete',
        progress: 100,
        message: 'Merge completed successfully'
      });

      return outputBlob;
    } catch (error) {
      logger.error('Media merge failed:', error);
      
      onProgress?.({
        status: 'error',
        progress: 0,
        message: error instanceof Error ? error.message : 'Failed to merge media'
      });

      throw error;
    } finally {
      await this.cleanup();
    }
  }

  private async trimClip(
    inputFile: string,
    outputFile: string,
    range: TimeRange
  ): Promise<void> {
    await this.ffmpeg!.exec([
      '-i', inputFile,
      '-ss', range.start.toString(),
      '-t', (range.end - range.start).toString(),
      ...EDITOR_CONFIG.ffmpegOptions.video,
      outputFile
    ]);
  }

  private async cutClip(
    inputFile: string,
    outputFile: string,
    ranges: TimeRange[]
  ): Promise<void> {
    // Create a complex filter to concatenate the desired segments
    const filterComplex = ranges
      .map((_, i) => `[0:v]trim=${ranges[i].start}:${ranges[i].end},setpts=PTS-STARTPTS[v${i}];`)
      .join('');

    const concat = `${ranges.map((_, i) => `[v${i}]`).join('')}concat=n=${ranges.length}:v=1[outv]`;

    await this.ffmpeg!.exec([
      '-i', inputFile,
      '-filter_complex', `${filterComplex}${concat}`,
      '-map', '[outv]',
      ...EDITOR_CONFIG.ffmpegOptions.video,
      outputFile
    ]);
  }

  private async cleanup(): Promise<void> {
    try {
      await this.ffmpeg?.terminate();
    } catch (error) {
      logger.error('FFmpeg cleanup failed:', error);
    }
  }
}