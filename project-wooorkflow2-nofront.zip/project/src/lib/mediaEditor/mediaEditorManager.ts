import { ClipEditor } from './clipEditor';
import { CaptionEditor } from './captionEditor';
import { EditOperation, EditableCaption, EditResult, EditorProgress } from './types';
import { EDITOR_CONFIG } from './config';
import { logger } from '../logger';
import { AppError } from '../errors';
import { supabase } from '../supabase';

export class MediaEditorManager {
  private clipEditor: ClipEditor;
  private captionEditor: CaptionEditor | null = null;
  private currentMediaId: string | null = null;
  private editHistory: EditOperation[] = [];
  private historyIndex = -1;

  constructor() {
    this.clipEditor = new ClipEditor();
  }

  async initialize(mediaId: string, captions?: EditableCaption[]): Promise<void> {
    try {
      await this.clipEditor.initialize();
      if (captions) {
        this.captionEditor = new CaptionEditor(captions);
      }
      this.currentMediaId = mediaId;
      this.editHistory = [];
      this.historyIndex = -1;
    } catch (error) {
      logger.error('Media editor initialization failed:', error);
      throw new AppError(
        'MEDIA_PROCESSING_ERROR',
        'Failed to initialize media editor'
      );
    }
  }

  async editClip(
    file: File,
    operation: EditOperation,
    onProgress?: (progress: EditorProgress) => void
  ): Promise<Blob> {
    try {
      const result = await this.clipEditor.editClip(file, operation, onProgress);
      this.addToHistory(operation);
      return result;
    } catch (error) {
      logger.error('Clip editing failed:', error);
      throw new AppError(
        'MEDIA_PROCESSING_ERROR',
        'Failed to edit media clip'
      );
    }
  }

  async mergeClips(
    files: File[],
    onProgress?: (progress: EditorProgress) => void
  ): Promise<Blob> {
    try {
      return await this.clipEditor.mergeClips(files, onProgress);
    } catch (error) {
      logger.error('Clip merge failed:', error);
      throw new AppError(
        'MEDIA_PROCESSING_ERROR',
        'Failed to merge media clips'
      );
    }
  }

  editCaption(id: string, text: string): void {
    if (!this.captionEditor) {
      throw new AppError(
        'VALIDATION_ERROR',
        'No captions loaded for editing'
      );
    }

    try {
      this.captionEditor.editCaption(id, text);
    } catch (error) {
      logger.error('Caption edit failed:', error);
      throw new AppError(
        'VALIDATION_ERROR',
        'Failed to edit caption'
      );
    }
  }

  adjustCaptionTiming(id: string, start: number, end: number): void {
    if (!this.captionEditor) {
      throw new AppError(
        'VALIDATION_ERROR',
        'No captions loaded for editing'
      );
    }

    try {
      this.captionEditor.adjustTiming(id, start, end);
    } catch (error) {
      logger.error('Caption timing adjustment failed:', error);
      throw new AppError(
        'VALIDATION_ERROR',
        'Failed to adjust caption timing'
      );
    }
  }

  splitCaption(id: string, splitPoint: number): void {
    if (!this.captionEditor) {
      throw new AppError(
        'VALIDATION_ERROR',
        'No captions loaded for editing'
      );
    }

    try {
      this.captionEditor.splitCaption(id, splitPoint);
    } catch (error) {
      logger.error('Caption split failed:', error);
      throw new AppError(
        'VALIDATION_ERROR',
        'Failed to split caption'
      );
    }
  }

  mergeCaptions(ids: string[]): void {
    if (!this.captionEditor) {
      throw new AppError(
        'VALIDATION_ERROR',
        'No captions loaded for editing'
      );
    }

    try {
      this.captionEditor.mergeCaptions(ids);
    } catch (error) {
      logger.error('Caption merge failed:', error);
      throw new AppError(
        'VALIDATION_ERROR',
        'Failed to merge captions'
      );
    }
  }

  getCaptions(): EditableCaption[] {
    if (!this.captionEditor) {
      throw new AppError(
        'VALIDATION_ERROR',
        'No captions loaded for editing'
      );
    }
    return this.captionEditor.getCaptions();
  }

  async save(): Promise<EditResult> {
    if (!this.currentMediaId) {
      throw new AppError(
        'VALIDATION_ERROR',
        'No media loaded for saving'
      );
    }

    try {
      // Validate captions if they exist
      if (this.captionEditor && !this.captionEditor.validateCaptions()) {
        throw new Error('Caption validation failed');
      }

      // Save edited media file
      const { data: mediaData, error: mediaError } = await supabase
        .from('media_files')
        .select('url, duration')
        .eq('id', this.currentMediaId)
        .single();

      if (mediaError) throw mediaError;

      // Save captions if they exist
      if (this.captionEditor) {
        const captions = this.captionEditor.getCaptions();
        const { error: captionError } = await supabase
          .from('captions')
          .upsert({
            media_id: this.currentMediaId,
            segments: captions
          });

        if (captionError) throw captionError;
      }

      return {
        url: mediaData.url,
        duration: mediaData.duration,
        captions: this.captionEditor?.getCaptions() || []
      };
    } catch (error) {
      logger.error('Save failed:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to save edited media'
      );
    }
  }

  canUndo(): boolean {
    return this.historyIndex > -1;
  }

  canRedo(): boolean {
    return this.historyIndex < this.editHistory.length - 1;
  }

  undo(): void {
    if (!this.canUndo()) return;
    this.historyIndex--;
    // Reapply operations up to current index
    this.reapplyOperations();
  }

  redo(): void {
    if (!this.canRedo()) return;
    this.historyIndex++;
    // Reapply operations up to current index
    this.reapplyOperations();
  }

  private addToHistory(operation: EditOperation): void {
    // Remove any future operations if we're not at the end
    if (this.historyIndex < this.editHistory.length - 1) {
      this.editHistory = this.editHistory.slice(0, this.historyIndex + 1);
    }
    this.editHistory.push(operation);
    this.historyIndex++;
  }

  private async reapplyOperations(): Promise<void> {
    // Implementation would reapply all operations up to historyIndex
    // This is a placeholder for the actual implementation
    logger.info('Reapplying operations up to index:', this.historyIndex);
  }

  cleanup(): void {
    this.clipEditor.cleanup();
    this.currentMediaId = null;
    this.captionEditor = null;
    this.editHistory = [];
    this.historyIndex = -1;
  }
}