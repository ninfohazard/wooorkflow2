import { supabase } from '../supabase';
import { logger } from '../logger';
import { retry } from '../utils/retry';

export interface WebhookConfig {
  url: string;
  events: string[];
  secret?: string;
  enabled: boolean;
}

export class WebhookManager {
  private static readonly SIGNATURE_HEADER = 'X-Webhook-Signature';

  static async registerWebhook(
    userId: string,
    config: WebhookConfig
  ): Promise<string> {
    try {
      const { data, error } = await supabase
        .from('webhooks')
        .insert({
          user_id: userId,
          url: config.url,
          events: config.events,
          secret: config.secret,
          enabled: config.enabled
        })
        .select('id')
        .single();

      if (error) throw error;
      return data.id;
    } catch (error) {
      logger.error('Webhook registration failed:', error);
      throw error;
    }
  }

  static async triggerWebhooks(
    event: string,
    payload: any
  ): Promise<void> {
    try {
      const { data: webhooks, error } = await supabase
        .from('webhooks')
        .select('*')
        .filter('enabled', 'eq', true)
        .filter('events', 'cs', `{${event}}`);

      if (error) throw error;

      await Promise.all(webhooks.map(webhook =>
        this.sendWebhook(webhook, event, payload)
      ));
    } catch (error) {
      logger.error('Webhook trigger failed:', error);
    }
  }

  private static async sendWebhook(
    webhook: any,
    event: string,
    payload: any
  ): Promise<void> {
    const body = JSON.stringify({
      event,
      timestamp: new Date().toISOString(),
      payload
    });

    const signature = webhook.secret
      ? await this.generateSignature(body, webhook.secret)
      : undefined;

    await retry(async () => {
      const response = await fetch(webhook.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(signature && {
            [this.SIGNATURE_HEADER]: signature
          })
        },
        body
      });

      if (!response.ok) {
        throw new Error(`Webhook delivery failed: ${response.statusText}`);
      }
    });
  }

  private static async generateSignature(
    payload: string,
    secret: string
  ): Promise<string> {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );

    const signature = await crypto.subtle.sign(
      'HMAC',
      key,
      encoder.encode(payload)
    );

    return Array.from(new Uint8Array(signature))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }
}