import { ExternalServiceConfig } from '../workflow/types';
import { logger } from '../logger';

export class HealthCheck {
  private static readonly TIMEOUT = 5000; // 5 seconds
  private static readonly RETRY_ATTEMPTS = 3;

  static async checkService(service: ExternalServiceConfig): Promise<boolean> {
    for (let attempt = 1; attempt <= this.RETRY_ATTEMPTS; attempt++) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.TIMEOUT);

        const response = await fetch(`${service.url}/health`, {
          method: 'GET',
          headers: service.apiKey ? {
            'Authorization': `Bearer ${service.apiKey}`
          } : {},
          signal: controller.signal
        });

        clearTimeout(timeoutId);
        return response.ok;
      } catch (error) {
        logger.warn(`Health check attempt ${attempt} failed:`, error);
        if (attempt === this.RETRY_ATTEMPTS) {
          return false;
        }
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
      }
    }
    return false;
  }

  static async checkAllServices(services: Record<string, ExternalServiceConfig>): Promise<Record<string, boolean>> {
    const results: Record<string, boolean> = {};
    
    await Promise.all(
      Object.entries(services).map(async ([name, config]) => {
        results[name] = await this.checkService(config);
      })
    );

    return results;
  }
}