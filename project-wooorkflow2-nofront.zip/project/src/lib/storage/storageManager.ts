import { supabase } from '../supabase';
import { Encryption } from '../security/encryption';
import { logger } from '../logger';
import { StorageQuota, StorageStats, StorageConfig } from './types';

export class StorageManager {
  private static readonly TEMP_STORAGE_KEY = 'temp_media';
  private static readonly CLEANUP_INTERVAL = 24 * 60 * 60 * 1000; // 24 hours
  private static readonly DEFAULT_QUOTA: StorageQuota = {
    maxStorageBytes: 10 * 1024 * 1024 * 1024, // 10GB
    maxFileSize: 500 * 1024 * 1024, // 500MB
    tempStorageLimit: 1 * 1024 * 1024 * 1024, // 1GB
    retentionPeriod: 24 * 60 * 60 * 1000 // 24 hours
  };

  private encryption: Encryption;
  private config: StorageConfig;

  constructor(config: Partial<StorageConfig> = {}) {
    this.encryption = new Encryption();
    this.config = {
      enableEncryption: true,
      autoCleanup: true,
      alertThreshold: 0.9, // 90%
      ...config
    };

    if (this.config.autoCleanup) {
      this.startCleanupScheduler();
    }
  }

  async storeFile(
    file: File,
    userId: string,
    isTemporary: boolean = false
  ): Promise<string> {
    try {
      // Check quota
      const stats = await this.getStorageStats(userId);
      if (stats.totalSize + file.size > this.DEFAULT_QUOTA.maxStorageBytes) {
        throw new Error('Storage quota exceeded');
      }

      // Encrypt file if enabled
      const fileData = this.config.enableEncryption
        ? await this.encryption.encrypt(await file.arrayBuffer(), await this.getEncryptionKey())
        : await file.arrayBuffer();

      const fileBlob = new Blob([fileData]);
      const fileId = crypto.randomUUID();
      const path = `${userId}/${isTemporary ? 'temp/' : ''}${fileId}`;

      // Upload to Supabase Storage
      const { error } = await supabase.storage
        .from('media')
        .upload(path, fileBlob, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) throw error;

      // Store metadata
      await supabase
        .from('media_files')
        .insert({
          id: fileId,
          user_id: userId,
          size: file.size,
          type: file.type,
          is_temporary: isTemporary,
          encrypted: this.config.enableEncryption,
          created_at: new Date().toISOString(),
          expires_at: isTemporary
            ? new Date(Date.now() + this.DEFAULT_QUOTA.retentionPeriod).toISOString()
            : null
        });

      return fileId;
    } catch (error) {
      logger.error('File storage failed:', error);
      throw error;
    }
  }

  async retrieveFile(fileId: string, userId: string): Promise<Blob> {
    try {
      // Get file metadata
      const { data: metadata } = await supabase
        .from('media_files')
        .select('*')
        .eq('id', fileId)
        .eq('user_id', userId)
        .single();

      if (!metadata) {
        throw new Error('File not found');
      }

      // Download from Supabase Storage
      const { data, error } = await supabase.storage
        .from('media')
        .download(`${userId}/${metadata.is_temporary ? 'temp/' : ''}${fileId}`);

      if (error || !data) throw error || new Error('Failed to download file');

      // Decrypt if encrypted
      if (metadata.encrypted) {
        const decrypted = await this.encryption.decrypt(
          await data.arrayBuffer(),
          await this.getEncryptionKey()
        );
        return new Blob([decrypted], { type: metadata.type });
      }

      return data;
    } catch (error) {
      logger.error('File retrieval failed:', error);
      throw error;
    }
  }

  async deleteFile(fileId: string, userId: string): Promise<void> {
    try {
      const { data: metadata } = await supabase
        .from('media_files')
        .select('is_temporary')
        .eq('id', fileId)
        .eq('user_id', userId)
        .single();

      if (!metadata) return;

      // Delete from storage
      await supabase.storage
        .from('media')
        .remove([`${userId}/${metadata.is_temporary ? 'temp/' : ''}${fileId}`]);

      // Delete metadata
      await supabase
        .from('media_files')
        .delete()
        .eq('id', fileId)
        .eq('user_id', userId);
    } catch (error) {
      logger.error('File deletion failed:', error);
      throw error;
    }
  }

  async getStorageStats(userId: string): Promise<StorageStats> {
    try {
      const { data: files } = await supabase
        .from('media_files')
        .select('size, is_temporary')
        .eq('user_id', userId);

      if (!files) return { totalSize: 0, tempSize: 0, fileCount: 0 };

      const stats = files.reduce(
        (acc, file) => ({
          totalSize: acc.totalSize + file.size,
          tempSize: acc.tempSize + (file.is_temporary ? file.size : 0),
          fileCount: acc.fileCount + 1
        }),
        { totalSize: 0, tempSize: 0, fileCount: 0 }
      );

      // Check if we need to send alerts
      if (stats.totalSize > this.DEFAULT_QUOTA.maxStorageBytes * this.config.alertThreshold) {
        await this.sendStorageAlert(userId, {
          type: 'quota',
          current: stats.totalSize,
          limit: this.DEFAULT_QUOTA.maxStorageBytes
        });
      }

      return stats;
    } catch (error) {
      logger.error('Failed to get storage stats:', error);
      throw error;
    }
  }

  private async cleanupExpiredFiles(): Promise<void> {
    try {
      const { data: expiredFiles } = await supabase
        .from('media_files')
        .select('id, user_id, is_temporary')
        .eq('is_temporary', true)
        .lt('expires_at', new Date().toISOString());

      if (!expiredFiles) return;

      for (const file of expiredFiles) {
        await this.deleteFile(file.id, file.user_id);
      }
    } catch (error) {
      logger.error('Cleanup failed:', error);
    }
  }

  private startCleanupScheduler(): void {
    setInterval(() => {
      this.cleanupExpiredFiles();
    }, this.CLEANUP_INTERVAL);
  }

  private async getEncryptionKey(): Promise<string> {
    // In a real application, this would be securely stored/managed
    // For demo purposes, we generate a new key each time
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array)
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }

  private async sendStorageAlert(
    userId: string,
    alert: { type: string; current: number; limit: number }
  ): Promise<void> {
    try {
      await supabase
        .from('storage_alerts')
        .insert({
          user_id: userId,
          type: alert.type,
          message: `Storage usage (${Math.round(alert.current / 1024 / 1024)}MB) is approaching limit (${Math.round(alert.limit / 1024 / 1024)}MB)`,
          created_at: new Date().toISOString()
        });
    } catch (error) {
      logger.error('Failed to send storage alert:', error);
    }
  }
}