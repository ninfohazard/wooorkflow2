export interface StorageQuota {
  maxStorageBytes: number;
  maxFileSize: number;
  tempStorageLimit: number;
  retentionPeriod: number;
}

export interface StorageStats {
  totalSize: number;
  tempSize: number;
  fileCount: number;
}

export interface StorageConfig {
  enableEncryption: boolean;
  autoCleanup: boolean;
  alertThreshold: number;
}

export interface StorageAlert {
  id: string;
  userId: string;
  type: string;
  message: string;
  createdAt: string;
  read: boolean;
}