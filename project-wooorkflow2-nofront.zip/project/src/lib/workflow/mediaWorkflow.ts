import { MediaUploadManager } from '../mediaUpload/mediaUploadManager';
import { CaptionManager } from '../captionProcessor/captionManager';
import { MediaEditorManager } from '../mediaEditor/mediaEditorManager';
import { SocialMediaManager } from '../socialMedia/socialMediaManager';
import { WorkflowState, WorkflowResult, WorkflowOptions } from './types';
import { logger } from '../logger';
import { AppError } from '../errors';
import { retry } from '../utils/retry';

export class MediaWorkflow {
  private uploadManager: MediaUploadManager;
  private captionManager: CaptionManager;
  private editorManager: MediaEditorManager;
  private socialManager: SocialMediaManager;
  private state: WorkflowState = {
    status: 'idle',
    progress: 0,
    message: ''
  };

  constructor(private options: WorkflowOptions) {
    this.uploadManager = new MediaUploadManager();
    this.captionManager = new CaptionManager();
    this.editorManager = new MediaEditorManager();
    this.socialManager = new SocialMediaManager();
  }

  async processMedia(
    file: File,
    onProgress?: (state: WorkflowState) => void
  ): Promise<WorkflowResult> {
    try {
      // Step 1: Upload and validate media
      this.updateState({
        status: 'loading',
        progress: 0,
        message: 'Uploading media...'
      }, onProgress);

      const fileId = await retry(async () => {
        const validationResult = await this.uploadManager.validateFile(file);
        if (!validationResult.isValid) {
          throw new AppError('VALIDATION_ERROR', validationResult.error);
        }

        return await this.uploadManager.uploadFile(file, this.options.userId, 
          (progress) => this.updateState({
            status: 'loading',
            progress,
            message: 'Uploading media...'
          }, onProgress)
        );
      });

      // Step 2: Generate captions
      this.updateState({
        status: 'processing',
        progress: 30,
        message: 'Generating captions...'
      }, onProgress);

      const captions = await retry(async () => {
        return await this.captionManager.generateCaptions(
          file,
          this.options.language,
          (progress) => this.updateState({
            status: 'processing',
            progress: 30 + (progress.progress * 0.3),
            message: progress.message
          }, onProgress)
        );
      });

      // Step 3: Initialize editor
      this.updateState({
        status: 'editing',
        progress: 60,
        message: 'Preparing editor...'
      }, onProgress);

      await this.editorManager.initialize(fileId, captions.segments);

      // Step 4: Post to social media
      this.updateState({
        status: 'posting',
        progress: 80,
        message: 'Posting to social media...'
      }, onProgress);

      const postResults = await retry(async () => {
        return await this.socialManager.post(
          URL.createObjectURL(file),
          {
            caption: captions.text,
            tags: [],
            platforms: this.options.platforms
          },
          (progress) => this.updateState({
            status: 'posting',
            progress: 80 + (progress.progress * 0.2),
            message: progress.message
          }, onProgress)
        );
      });

      // Log post attempts
      await this.logPostAttempts(fileId, postResults);

      this.updateState({
        status: 'complete',
        progress: 100,
        message: 'Workflow completed successfully'
      }, onProgress);

      return {
        mediaUrl: URL.createObjectURL(file),
        captions: captions.text,
        postUrls: postResults
          .filter(r => r.success && r.postUrl)
          .map(r => r.postUrl!)
      };
    } catch (error) {
      logger.error('Workflow failed:', error);
      
      const appError = error instanceof AppError ? error : new AppError(
        'UNKNOWN_ERROR',
        'Workflow failed unexpectedly'
      );

      this.updateState({
        status: 'error',
        progress: 0,
        message: appError.message,
        error: appError.code
      }, onProgress);

      throw appError;
    }
  }

  private updateState(
    update: Partial<WorkflowState>,
    onProgress?: (state: WorkflowState) => void
  ): void {
    this.state = { ...this.state, ...update };
    onProgress?.(this.state);
  }

  private async logPostAttempts(
    mediaId: string,
    results: { platform: string; success: boolean; error?: string; postUrl?: string; }[]
  ): Promise<void> {
    try {
      await Promise.all(results.map(result =>
        this.socialManager.logPostAttempt(
          mediaId,
          result.platform,
          result.success,
          result.error
        )
      ));
    } catch (error) {
      logger.error('Failed to log post attempts:', error);
    }
  }
}