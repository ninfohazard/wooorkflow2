export interface WorkflowState {
  status: 'idle' | 'loading' | 'processing' | 'editing' | 'posting' | 'complete' | 'error';
  progress: number;
  message: string;
  error?: string;
}

export interface WorkflowResult {
  mediaUrl: string;
  captions: string;
  postUrls: string[];
}

export interface ExternalServiceConfig {
  name: string;
  url: string;
  apiKey?: string;
}

export interface WorkflowOptions {
  platforms: string[];
  language?: string;
  retryOptions?: {
    maxAttempts: number;
    initialDelay: number;
  };
  externalServices?: {
    mediaProcessing?: ExternalServiceConfig;
    captionGeneration?: ExternalServiceConfig;
    mediaEditing?: ExternalServiceConfig;
    socialPosting?: ExternalServiceConfig;
  };
}