import { supabase } from '../supabase';
import { WorkflowState, WorkflowOptions } from './types';
import { logger } from '../logger';

export class WorkflowStateManager {
  constructor(private userId: string, private workflowId: string) {}

  async saveState(
    step: string,
    state: WorkflowState,
    mediaId?: string
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('workflow_states')
        .upsert({
          id: this.workflowId,
          user_id: this.userId,
          media_id: mediaId,
          current_step: step,
          state: state,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
    } catch (error) {
      logger.error('Failed to save workflow state:', error);
      throw error;
    }
  }

  async logStep(
    step: string,
    status: string,
    details?: Record<string, unknown>
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('workflow_logs')
        .insert({
          workflow_id: this.workflowId,
          step,
          status,
          details
        });

      if (error) throw error;
    } catch (error) {
      logger.error('Failed to log workflow step:', error);
      throw error;
    }
  }

  async getLastState(): Promise<{
    state: WorkflowState;
    mediaId?: string;
    step: string;
  } | null> {
    try {
      const { data, error } = await supabase
        .from('workflow_states')
        .select('state, media_id, current_step')
        .eq('id', this.workflowId)
        .single();

      if (error) throw error;
      if (!data) return null;

      return {
        state: data.state as WorkflowState,
        mediaId: data.media_id,
        step: data.current_step
      };
    } catch (error) {
      logger.error('Failed to get workflow state:', error);
      return null;
    }
  }

  async cleanup(): Promise<void> {
    try {
      // Remove workflow state
      await supabase
        .from('workflow_states')
        .delete()
        .eq('id', this.workflowId);

      // Cleanup any orphaned media files
      const { data: mediaFiles } = await supabase
        .from('media')
        .select('id')
        .eq('workflow_id', this.workflowId);

      if (mediaFiles) {
        for (const file of mediaFiles) {
          await supabase.storage.from('media').remove([`${file.id}`]);
        }
      }
    } catch (error) {
      logger.error('Failed to cleanup workflow:', error);
    }
  }
}