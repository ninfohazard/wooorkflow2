import { supabase } from '../supabase';
import { logger } from '../logger';
import { AppError } from '../errors';
import { retry } from '../utils';
import {
  Wallet,
  Transaction,
  CreditUsage,
  CreditCheckResult,
  WalletSchema
} from './types';
import { PAYMENT_CONFIG } from './config';

export class WalletManager {
  async getWallet(userId: string): Promise<Wallet> {
    try {
      const { data, error } = await supabase
        .from('user_wallets')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error) throw error;
      if (!data) {
        return await this.createWallet(userId);
      }

      return WalletSchema.parse(data);
    } catch (error) {
      logger.error('Failed to get wallet:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to retrieve wallet'
      );
    }
  }

  private async createWallet(userId: string): Promise<Wallet> {
    try {
      const { data, error } = await supabase
        .from('user_wallets')
        .insert({
          user_id: userId,
          credits: 0,
          lifetime_credits: 0
        })
        .select()
        .single();

      if (error) throw error;
      return WalletSchema.parse(data);
    } catch (error) {
      logger.error('Failed to create wallet:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to create wallet'
      );
    }
  }

  async checkCredits(
    userId: string,
    mediaType: 'video' | 'audio',
    durationMinutes: number,
    useAI: boolean = false
  ): Promise<CreditCheckResult> {
    try {
      const wallet = await this.getWallet(userId);
      const requiredCredits = this.calculateRequiredCredits(
        mediaType,
        durationMinutes,
        useAI
      );

      return {
        hasCredits: wallet.credits >= requiredCredits,
        currentBalance: wallet.credits,
        requiredCredits,
        canProceed: wallet.credits >= requiredCredits
      };
    } catch (error) {
      logger.error('Failed to check credits:', error);
      throw new AppError(
        'VALIDATION_ERROR',
        'Failed to check credit balance'
      );
    }
  }

  async deductCredits(
    userId: string,
    mediaId: string,
    creditsToDeduct: number,
    usageType: string
  ): Promise<void> {
    try {
      await retry(async () => {
        const wallet = await this.getWallet(userId);
        
        if (wallet.credits < creditsToDeduct) {
          throw new AppError(
            'VALIDATION_ERROR',
            'Insufficient credits'
          );
        }

        const { error: updateError } = await supabase
          .from('user_wallets')
          .update({
            credits: wallet.credits - creditsToDeduct,
            updated_at: new Date().toISOString()
          })
          .eq('id', wallet.id);

        if (updateError) throw updateError;

        const { error: usageError } = await supabase
          .from('credit_usage')
          .insert({
            user_id: userId,
            wallet_id: wallet.id,
            media_id: mediaId,
            credits_used: creditsToDeduct,
            usage_type: usageType
          });

        if (usageError) throw usageError;
      });
    } catch (error) {
      logger.error('Failed to deduct credits:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to deduct credits'
      );
    }
  }

  async getTransactionHistory(userId: string): Promise<Transaction[]> {
    try {
      const { data, error } = await supabase
        .from('payment_transactions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Failed to get transaction history:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to retrieve transaction history'
      );
    }
  }

  async getCreditUsage(userId: string): Promise<CreditUsage[]> {
    try {
      const { data, error } = await supabase
        .from('credit_usage')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Failed to get credit usage:', error);
      throw new AppError(
        'STORAGE_ERROR',
        'Failed to retrieve credit usage'
      );
    }
  }

  private calculateRequiredCredits(
    mediaType: 'video' | 'audio',
    durationMinutes: number,
    useAI: boolean
  ): number {
    const baseRate = PAYMENT_CONFIG.credits.processingRates[mediaType];
    const aiRate = useAI ? PAYMENT_CONFIG.credits.processingRates.ai : 0;
    return Math.ceil((baseRate + aiRate) * durationMinutes);
  }
}