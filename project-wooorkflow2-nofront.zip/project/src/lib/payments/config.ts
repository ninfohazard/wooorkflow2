export const PAYMENT_CONFIG = {
  stripe: {
    publicKey: import.meta.env.VITE_STRIPE_PUBLIC_KEY,
    apiVersion: '2024-02-15',
    currency: 'usd',
    paymentMethods: ['card'],
    webhookSecret: import.meta.env.VITE_STRIPE_WEBHOOK_SECRET
  },
  lightning: {
    nodeUrl: import.meta.env.VITE_LIGHTNING_NODE_URL,
    macaroon: import.meta.env.VITE_LIGHTNING_MACAROON,
    expirySeconds: 3600, // 1 hour
    minSats: 1000,
    maxSats: 1000000
  },
  credits: {
    minPurchase: 100,
    maxPurchase: 10000,
    processingRates: {
      video: 1, // 1 credit per minute
      audio: 0.5, // 0.5 credits per minute
      ai: 2 // 2 credits per minute for AI processing
    },
    expiryDays: 365 // Credits expire after 1 year
  },
  retry: {
    maxAttempts: 3,
    initialDelay: 1000,
    maxDelay: 10000
  }
};