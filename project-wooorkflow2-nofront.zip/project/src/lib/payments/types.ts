import { z } from 'zod';

export const PaymentPlanSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  credits: z.number().int().positive(),
  priceUsd: z.number().positive(),
  priceSats: z.number().int().positive(),
  active: z.boolean(),
  features: z.record(z.unknown())
});

export const PaymentMethodSchema = z.enum(['stripe', 'lightning']);

export const PaymentStatusSchema = z.enum([
  'pending',
  'processing',
  'completed',
  'failed',
  'expired'
]);

export const WalletSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  credits: z.number().int(),
  lifetimeCredits: z.number().int(),
  lastToppedUp: z.string().datetime().nullable()
});

export const TransactionSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  walletId: z.string().uuid(),
  planId: z.string().uuid().optional(),
  amountUsd: z.number().optional(),
  amountSats: z.number().int().optional(),
  credits: z.number().int().positive(),
  paymentMethod: PaymentMethodSchema,
  status: PaymentStatusSchema,
  stripePaymentId: z.string().optional(),
  lightningInvoiceId: z.string().uuid().optional(),
  metadata: z.record(z.unknown()).optional()
});

export const CreditUsageSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  walletId: z.string().uuid(),
  mediaId: z.string().uuid(),
  creditsUsed: z.number().int().positive(),
  usageType: z.string(),
  metadata: z.record(z.unknown()).optional()
});

export const LightningInvoiceSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  paymentHash: z.string(),
  paymentRequest: z.string(),
  amountSats: z.number().int().positive(),
  status: PaymentStatusSchema,
  expiresAt: z.string().datetime(),
  settledAt: z.string().datetime().optional()
});

export type PaymentPlan = z.infer<typeof PaymentPlanSchema>;
export type PaymentMethod = z.infer<typeof PaymentMethodSchema>;
export type PaymentStatus = z.infer<typeof PaymentStatusSchema>;
export type Wallet = z.infer<typeof WalletSchema>;
export type Transaction = z.infer<typeof TransactionSchema>;
export type CreditUsage = z.infer<typeof CreditUsageSchema>;
export type LightningInvoice = z.infer<typeof LightningInvoiceSchema>;

export interface CreditCheckResult {
  hasCredits: boolean;
  currentBalance: number;
  requiredCredits: number;
  canProceed: boolean;
}

export interface PaymentResult {
  success: boolean;
  transactionId?: string;
  error?: string;
  redirectUrl?: string;
}