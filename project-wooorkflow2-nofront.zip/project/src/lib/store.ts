import { create } from 'zustand';

interface MediaState {
  currentMedia: {
    url: string;
    type: 'video' | 'audio';
    captions: string;
  } | null;
  setCurrentMedia: (media: MediaState['currentMedia']) => void;
  clearCurrentMedia: () => void;
}

export const useMediaStore = create<MediaState>((set) => ({
  currentMedia: null,
  setCurrentMedia: (media) => set({ currentMedia: media }),
  clearCurrentMedia: () => set({ currentMedia: null }),
}));