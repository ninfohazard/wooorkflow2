import { PostMetadata, PostProgress, PostResult, ExternalPostingService } from './types';
import { logger } from '../logger';
import { retry } from '../utils/retry';

export class ExternalPostingService {
  constructor(private config: ExternalPostingService) {}

  async post(
    mediaUrl: string,
    metadata: PostMetadata,
    onProgress?: (progress: PostProgress) => void
  ): Promise<PostResult[]> {
    try {
      // Prepare the payload for the external service
      const payload = {
        media: mediaUrl,
        caption: metadata.caption,
        tags: metadata.tags,
        platforms: metadata.platforms,
        apiKey: this.config.apiKey
      };

      // Send to external service
      const response = await retry(async () => {
        const result = await fetch(`${this.config.url}/api/post`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.config.apiKey}`
          },
          body: JSON.stringify(payload)
        });

        if (!result.ok) {
          throw new Error(`External service error: ${result.statusText}`);
        }

        return await result.json();
      });

      // Map external service response to our format
      return metadata.platforms.map(platform => ({
        platform,
        success: response.success,
        postUrl: response.urls?.[platform],
        error: response.errors?.[platform]
      }));
    } catch (error) {
      logger.error('External posting service error:', error);
      return metadata.platforms.map(platform => ({
        platform,
        success: false,
        error: 'Failed to post using external service'
      }));
    }
  }
}