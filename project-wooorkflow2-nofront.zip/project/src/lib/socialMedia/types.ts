// Update the SocialPlatform type to be more flexible
export type SocialPlatform = string;

export interface PostMetadata {
  caption: string;
  tags: string[];
  platforms: SocialPlatform[];
}

export interface PostProgress {
  platform: SocialPlatform;
  status: 'pending' | 'uploading' | 'processing' | 'complete' | 'error';
  progress: number;
  message?: string;
}

export interface PostResult {
  platform: SocialPlatform;
  success: boolean;
  postUrl?: string;
  error?: string;
}

export interface PlatformConfig {
  enabled: boolean;
  maxCaptionLength: number;
  maxTags: number;
  maxVideoLength: number;
  supportedFormats: string[];
  apiEndpoint?: string;
  apiVersion?: string;
  features?: string[];
}

export interface RetryConfig {
  maxAttempts: number;
  initialDelay: number;
  maxDelay: number;
  backoffFactor: number;
}

export interface ExternalPostingService {
  name: string;
  url: string;
  apiKey?: string;
}

export interface PostingServiceConfig {
  useExternalService: boolean;
  service?: ExternalPostingService;
}

// New interfaces for platform registration
export interface PlatformHandler {
  authenticate(): Promise<boolean>;
  post(
    mediaUrl: string,
    caption: string,
    tags: string[],
    onProgress?: (progress: PostProgress) => void
  ): Promise<PostResult>;
}

export interface PlatformRegistration {
  name: string;
  handler: PlatformHandler;
  config: PlatformConfig;
}