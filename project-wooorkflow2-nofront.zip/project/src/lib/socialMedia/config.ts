import { PlatformConfig, RetryConfig, PostingServiceConfig } from './types';

// Make platform config a dynamic registry
export const PLATFORM_CONFIG: Record<string, PlatformConfig> = {
  twitter: {
    enabled: true,
    maxCaptionLength: 280,
    maxTags: 5,
    maxVideoLength: 140,
    supportedFormats: ['mp4', 'mov'],
    apiVersion: '2.0',
    features: ['polls', 'media', 'scheduling']
  },
  instagram: {
    enabled: true,
    maxCaptionLength: 2200,
    maxTags: 30,
    maxVideoLength: 60,
    supportedFormats: ['mp4', 'mov'],
    apiVersion: '1.0',
    features: ['stories', 'reels', 'carousel']
  },
  tiktok: {
    enabled: true,
    maxCaptionLength: 2200,
    maxTags: 30,
    maxVideoLength: 180,
    supportedFormats: ['mp4', 'mov'],
    apiVersion: '1.0',
    features: ['duets', 'stitches', 'effects']
  }
};

export const RETRY_CONFIG: RetryConfig = {
  maxAttempts: 3,
  initialDelay: 1000,
  maxDelay: 10000,
  backoffFactor: 2
};

export const POSTING_SERVICE_CONFIG: PostingServiceConfig = {
  useExternalService: false,
  service: {
    name: 'External Social Media Manager',
    url: 'https://api.external-service.com',
    apiKey: process.env.EXTERNAL_SERVICE_API_KEY
  }
};