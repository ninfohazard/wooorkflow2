import { ExternalPostingService } from './externalPostingService';
import { 
  PostMetadata, 
  PostProgress, 
  PostResult, 
  SocialPlatform,
  PlatformHandler,
  PlatformRegistration,
  PlatformConfig
} from './types';
import { PLATFORM_CONFIG, POSTING_SERVICE_CONFIG } from './config';
import { logger } from '../logger';
import { AppError } from '../errors';
import { supabase } from '../supabase';
import { retry } from '../utils';

export class SocialMediaManager {
  private handlers: Map<string, PlatformHandler> = new Map();
  private configs: Map<string, PlatformConfig> = new Map();
  private externalService: ExternalPostingService | null = null;

  constructor() {
    // Initialize with default platforms
    Object.entries(PLATFORM_CONFIG).forEach(([platform, config]) => {
      this.configs.set(platform, config);
    });

    if (POSTING_SERVICE_CONFIG.useExternalService && POSTING_SERVICE_CONFIG.service) {
      this.externalService = new ExternalPostingService(POSTING_SERVICE_CONFIG.service);
    }
  }

  registerPlatform(registration: PlatformRegistration): void {
    if (this.handlers.has(registration.name)) {
      throw new Error(`Platform ${registration.name} is already registered`);
    }

    this.handlers.set(registration.name, registration.handler);
    this.configs.set(registration.name, registration.config);

    logger.info(`Registered new platform: ${registration.name}`);
  }

  unregisterPlatform(platform: string): void {
    this.handlers.delete(platform);
    this.configs.delete(platform);
    logger.info(`Unregistered platform: ${platform}`);
  }

  getPlatformConfig(platform: string): PlatformConfig | undefined {
    return this.configs.get(platform);
  }

  getRegisteredPlatforms(): string[] {
    return Array.from(this.handlers.keys());
  }

  async authenticate(platform: SocialPlatform): Promise<boolean> {
    try {
      const handler = this.handlers.get(platform);
      if (!handler) {
        throw new Error(`Platform ${platform} not registered`);
      }
      return await handler.authenticate();
    } catch (error) {
      logger.error(`Authentication failed for ${platform}:`, error);
      return false;
    }
  }

  async post(
    mediaUrl: string,
    metadata: PostMetadata,
    onProgress?: (progress: PostProgress) => void
  ): Promise<PostResult[]> {
    try {
      // Validate metadata
      this.validateMetadata(metadata);

      // Use external service if configured
      if (this.externalService) {
        return await this.externalService.post(mediaUrl, metadata, onProgress);
      }

      // Post to each platform
      const results = await Promise.all(
        metadata.platforms.map(platform =>
          this.postToPlatform(platform, mediaUrl, metadata, onProgress)
        )
      );

      return results;
    } catch (error) {
      logger.error('Social media posting failed:', error);
      throw new AppError(
        'SOCIAL_MEDIA_ERROR',
        error instanceof Error ? error.message : 'Failed to post to social media'
      );
    }
  }

  private async postToPlatform(
    platform: SocialPlatform,
    mediaUrl: string,
    metadata: PostMetadata,
    onProgress?: (progress: PostProgress) => void
  ): Promise<PostResult> {
    try {
      const handler = this.handlers.get(platform);
      if (!handler) {
        throw new Error(`Platform ${platform} not registered`);
      }

      const config = this.configs.get(platform);
      if (!config?.enabled) {
        throw new Error(`Platform ${platform} is not enabled`);
      }

      // Check authentication
      const isAuthenticated = await this.authenticate(platform);
      if (!isAuthenticated) {
        throw new Error(`Not authenticated for ${platform}`);
      }

      // Post with retry logic
      return await retry(async () => {
        await this.checkRateLimit(platform);
        return await handler.post(
          mediaUrl,
          metadata.caption,
          metadata.tags,
          onProgress
        );
      });
    } catch (error) {
      logger.error(`Posting to ${platform} failed:`, error);
      return {
        platform,
        success: false,
        error: error instanceof Error ? error.message : 'Post failed'
      };
    }
  }

  private validateMetadata(metadata: PostMetadata): void {
    const { caption, tags, platforms } = metadata;

    // Validate platforms
    if (!platforms.length) {
      throw new Error('No platforms selected');
    }

    platforms.forEach(platform => {
      const config = this.configs.get(platform);
      if (!config) {
        throw new Error(`Invalid platform: ${platform}`);
      }

      // Check caption length
      if (caption.length > config.maxCaptionLength) {
        throw new Error(
          `Caption exceeds maximum length for ${platform} (${config.maxCaptionLength} characters)`
        );
      }

      // Check tags count
      if (tags.length > config.maxTags) {
        throw new Error(
          `Too many tags for ${platform} (maximum ${config.maxTags})`
        );
      }
    });
  }

  // ... rest of the class implementation remains the same ...
}