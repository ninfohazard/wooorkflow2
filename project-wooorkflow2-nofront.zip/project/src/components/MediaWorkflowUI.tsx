import React, { useState } from 'react';
import { MediaUploadInterface } from './MediaUploadInterface';
import { CaptionProcessor } from './CaptionProcessor';
import { MediaEditorInterface } from './MediaEditorInterface';
import { SocialMediaPost } from './SocialMediaPost';
import { MediaWorkflow } from '../lib/workflow/mediaWorkflow';
import { WorkflowState } from '../lib/workflow/types';
import { useMediaStore } from '../lib/store';
import { supabase } from '../supabase';
import {
  Upload,
  MessageSquare,
  Edit,
  Share2,
  AlertCircle,
  CheckCircle,
  Loader2
} from 'lucide-react';

const STEPS = [
  { id: 'upload', label: 'Upload', icon: Upload },
  { id: 'caption', label: 'Caption', icon: MessageSquare },
  { id: 'edit', label: 'Edit', icon: Edit },
  { id: 'share', label: 'Share', icon: Share2 }
] as const;

export function MediaWorkflowUI() {
  const [currentStep, setCurrentStep] = useState<typeof STEPS[number]['id']>('upload');
  const [workflowState, setWorkflowState] = useState<WorkflowState>({
    status: 'idle',
    progress: 0,
    message: ''
  });

  const currentMedia = useMediaStore((state) => state.currentMedia);
  const setCurrentMedia = useMediaStore((state) => state.setCurrentMedia);

  const handleUploadComplete = async (file: File) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('Not authenticated');

      const workflow = new MediaWorkflow({
        userId: session.user.id,
        platforms: ['twitter', 'instagram'],
        language: 'en'
      });

      const result = await workflow.processMedia(file, setWorkflowState);

      setCurrentMedia({
        url: result.mediaUrl,
        type: file.type.startsWith('video/') ? 'video' : 'audio',
        captions: result.captions
      });

      setCurrentStep('caption');
    } catch (error) {
      console.error('Workflow failed:', error);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 'upload':
        return <MediaUploadInterface onUploadComplete={handleUploadComplete} />;
      case 'caption':
        return (
          <CaptionProcessor
            onComplete={() => setCurrentStep('edit')}
          />
        );
      case 'edit':
        return (
          <MediaEditorInterface
            onEditComplete={() => setCurrentStep('share')}
          />
        );
      case 'share':
        return (
          <SocialMediaPost
            mediaUrl={currentMedia!.url}
            mediaId="temp-id" // This would be the actual media ID in production
          />
        );
    }
  };

  const currentStepIndex = STEPS.findIndex(step => step.id === currentStep);

  return (
    <div className="space-y-8">
      {/* Progress Steps */}
      <div className="relative">
        <div className="absolute top-1/2 left-0 w-full h-0.5 bg-gray-200 -translate-y-1/2" />
        <div 
          className="absolute top-1/2 left-0 h-0.5 bg-primary-500 -translate-y-1/2 transition-all duration-500"
          style={{ width: `${(currentStepIndex / (STEPS.length - 1)) * 100}%` }}
        />

        <div className="relative flex justify-between">
          {STEPS.map((step, index) => {
            const isActive = index === currentStepIndex;
            const isCompleted = index < currentStepIndex;
            const Icon = step.icon;

            return (
              <div
                key={step.id}
                className={`flex flex-col items-center ${
                  isActive ? 'scale-110' : ''
                } transition-transform duration-300`}
              >
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors duration-300 ${
                    isActive
                      ? 'bg-primary-500 text-white shadow-lg shadow-primary-500/30'
                      : isCompleted
                        ? 'bg-green-500 text-white'
                        : 'bg-white text-gray-400 border-2 border-gray-200'
                  }`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <span
                  className={`mt-2 font-medium transition-colors duration-300 ${
                    isActive
                      ? 'text-primary-600'
                      : isCompleted
                        ? 'text-green-600'
                        : 'text-gray-400'
                  }`}
                >
                  {step.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Workflow State */}
      {workflowState.status !== 'idle' && (
        <div className={`p-4 rounded-lg ${
          workflowState.status === 'error'
            ? 'bg-red-50 border border-red-200'
            : 'bg-white border'
        }`}>
          <div className="flex items-center space-x-3">
            {workflowState.status === 'error' ? (
              <AlertCircle className="w-5 h-5 text-red-500" />
            ) : workflowState.status === 'complete' ? (
              <CheckCircle className="w-5 h-5 text-green-500" />
            ) : (
              <Loader2 className="w-5 h-5 text-primary-500 animate-spin" />
            )}
            <div>
              <p className={`font-medium ${
                workflowState.status === 'error' ? 'text-red-800' : 'text-gray-900'
              }`}>
                {workflowState.message}
              </p>
              {workflowState.status !== 'error' && workflowState.progress > 0 && (
                <div className="mt-2 h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary-500 transition-all duration-300"
                    style={{ width: `${workflowState.progress}%` }}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Current Step Content */}
      <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-6">
        {renderStep()}
      </div>
    </div>
  );
}