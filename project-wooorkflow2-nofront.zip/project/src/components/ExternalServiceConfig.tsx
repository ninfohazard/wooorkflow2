import React, { useState } from 'react';
import { ExternalPostingService } from '../lib/socialMedia/types';
import { POSTING_SERVICE_CONFIG } from '../lib/socialMedia/config';

interface Props {
  onConfigChange: (config: ExternalPostingService) => void;
}

export function ExternalServiceConfig({ onConfigChange }: Props) {
  const [serviceConfig, setServiceConfig] = useState<ExternalPostingService>(
    POSTING_SERVICE_CONFIG.service || {
      name: '',
      url: '',
      apiKey: ''
    }
  );

  const handleChange = (field: keyof ExternalPostingService, value: string) => {
    const newConfig = { ...serviceConfig, [field]: value };
    setServiceConfig(newConfig);
    onConfigChange(newConfig);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="text-lg font-semibold mb-4">External Posting Service Configuration</h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Service Name
          </label>
          <input
            type="text"
            value={serviceConfig.name}
            onChange={(e) => handleChange('name', e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            API URL
          </label>
          <input
            type="url"
            value={serviceConfig.url}
            onChange={(e) => handleChange('url', e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            API Key
          </label>
          <input
            type="password"
            value={serviceConfig.apiKey}
            onChange={(e) => handleChange('apiKey', e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
      </div>
    </div>
  );
}