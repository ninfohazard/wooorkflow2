import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

interface Props {
  services: Record<string, {
    name: string;
    url: string;
  }>;
}

export function ServiceHealthIndicator({ services }: Props) {
  const [statuses, setStatuses] = useState<Record<string, boolean>>({});

  useEffect(() => {
    checkServices();
    const interval = setInterval(checkServices, 60000); // Check every minute
    return () => clearInterval(interval);
  }, []);

  const checkServices = async () => {
    const results: Record<string, boolean> = {};
    
    for (const [id, service] of Object.entries(services)) {
      try {
        const response = await fetch(service.url + '/health');
        results[id] = response.ok;
      } catch {
        results[id] = false;
      }
    }

    setStatuses(results);
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Service Status</h3>
      <div className="grid gap-4">
        {Object.entries(services).map(([id, service]) => (
          <div
            key={id}
            className="flex items-center justify-between p-3 bg-white rounded-lg shadow-sm"
          >
            <span className="font-medium">{service.name}</span>
            <span className={`px-2 py-1 rounded-full text-sm flex items-center space-x-1 ${
              statuses[id]
                ? 'bg-green-100 text-green-800'
                : 'bg-red-100 text-red-800'
            }`}>
              {statuses[id] ? (
                <CheckCircle className="w-4 h-4" />
              ) : (
                <XCircle className="w-4 h-4" />
              )}
              <span>{statuses[id] ? 'Healthy' : 'Unhealthy'}</span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}