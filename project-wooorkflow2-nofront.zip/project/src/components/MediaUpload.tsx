import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { useMediaStore } from '../lib/store';
import { Upload, AlertCircle, FileVideo, FileAudio, Image, Camera } from 'lucide-react';

interface CameraRollFile {
  file: File;
  preview: string;
}

export function MediaUpload() {
  const setCurrentMedia = useMediaStore((state) => state.setCurrentMedia);
  const [error, setError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<CameraRollFile[]>([]);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setError(null);
    setIsProcessing(true);
    
    try {
      // Create preview URL
      const previewUrl = URL.createObjectURL(file);

      setCurrentMedia({
        url: previewUrl,
        type: file.type.startsWith('video/') ? 'video' : 'audio',
        captions: ''
      });
    } catch (error) {
      setError('Error processing file');
      console.error('File processing error:', error);
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.webm', '.mov'],
      'audio/*': ['.mp3', '.wav', '.ogg'],
    },
    maxFiles: 1,
    disabled: isProcessing
  });

  const requestCameraRollPermission = async () => {
    try {
      // Check if the browser supports the File System Access API
      if ('showDirectoryPicker' in window) {
        const dirHandle = await window.showDirectoryPicker({
          mode: 'read',
          startIn: 'pictures'
        });
        setHasPermission(true);
        return true;
      } else {
        // Fallback to traditional file input
        return true;
      }
    } catch (error) {
      console.error('Permission request failed:', error);
      setHasPermission(false);
      return false;
    }
  };

  const openCameraRoll = async () => {
    try {
      if (hasPermission === null) {
        const granted = await requestCameraRollPermission();
        if (!granted) {
          setError('Camera roll access denied');
          return;
        }
      }

      // Create a file input element
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'video/*,audio/*';
      input.multiple = false;

      // Handle file selection
      input.onchange = async (e) => {
        const file = (e.target as HTMLInputElement).files?.[0];
        if (!file) return;

        setError(null);
        setIsProcessing(true);

        try {
          const previewUrl = URL.createObjectURL(file);
          setCurrentMedia({
            url: previewUrl,
            type: file.type.startsWith('video/') ? 'video' : 'audio',
            captions: ''
          });
        } catch (error) {
          setError('Error processing file from camera roll');
          console.error('Camera roll file processing error:', error);
        } finally {
          setIsProcessing(false);
        }
      };

      // Trigger file selection
      input.click();
    } catch (error) {
      setError('Failed to access camera roll');
      console.error('Camera roll access error:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Drop Zone */}
      <div
        {...getRootProps()}
        className={`relative border-2 border-dashed rounded-lg transition-all duration-300 ${
          isDragActive 
            ? 'border-primary-500 bg-primary-50' 
            : 'border-gray-300 hover:border-primary-400 hover:bg-gray-50'
        } ${isProcessing ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
      >
        <input {...getInputProps()} />
        
        <div className="p-12">
          {isProcessing ? (
            <div className="text-center">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-primary-500 border-t-transparent"></div>
              <p className="mt-4 text-primary-600 font-medium">Processing media...</p>
            </div>
          ) : isDragActive ? (
            <div className="text-center">
              <Upload className="w-16 h-16 text-primary-500 mx-auto mb-4 animate-bounce" />
              <p className="text-center text-primary-600 text-lg font-medium">
                Drop your file here...
              </p>
            </div>
          ) : (
            <div className="text-center">
              <div className="mb-6">
                <Upload className="w-16 h-16 text-gray-400 mx-auto" />
              </div>
              <p className="text-lg font-medium mb-2">
                Drag & drop your media file here
              </p>
              <p className="text-gray-500">or click to browse</p>
              
              <div className="mt-6 flex justify-center space-x-8">
                <div className="text-center">
                  <FileVideo className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600 font-medium">Video</p>
                  <p className="text-xs text-gray-400">MP4, WebM, MOV</p>
                </div>
                <div className="text-center">
                  <FileAudio className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600 font-medium">Audio</p>
                  <p className="text-xs text-gray-400">MP3, WAV, OGG</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Camera Roll Button */}
      <button
        onClick={openCameraRoll}
        disabled={isProcessing}
        className="w-full py-4 px-6 bg-white border-2 border-gray-200 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <Image className="w-5 h-5 text-gray-500" />
        <span className="font-medium text-gray-700">Choose from Camera Roll</span>
      </button>

      {/* Error Display */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg animate-fade-in">
          <div className="flex items-center space-x-2 text-red-600">
            <AlertCircle className="w-5 h-5" />
            <span className="font-medium">{error}</span>
          </div>
        </div>
      )}
    </div>
  );
}