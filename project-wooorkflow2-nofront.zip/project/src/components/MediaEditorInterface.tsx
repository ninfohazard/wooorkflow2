{/* Add timeline component */}
<div className="relative h-16 bg-gray-100 rounded-lg overflow-hidden">
  {/* Timeline markers */}
  <div className="absolute top-0 left-0 w-full h-full">
    {Array.from({ length: Math.ceil(duration) }).map((_, i) => (
      <div
        key={i}
        className="absolute h-full w-px bg-gray-300"
        style={{ left: `${(i / duration) * 100}%` }}
      >
        <span className="absolute -top-6 left-1 text-xs text-gray-500">
          {Math.floor(i / 60)}:{(i % 60).toString().padStart(2, '0')}
        </span>
      </div>
    ))}
  </div>

  {/* Playhead */}
  <div
    className="absolute top-0 h-full w-0.5 bg-primary-500 transform -translate-x-1/2"
    style={{ left: `${(currentTime / duration) * 100}%` }}
  >
    <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-3 h-3 bg-primary-500 rounded-full" />
  </div>

  {/* Video thumbnails (for video files) */}
  {currentMedia.type === 'video' && (
    <div className="absolute top-0 left-0 w-full h-full">
      {/* Thumbnails would be generated and displayed here */}
    </div>
  )}
</div>

{/* Add keyboard shortcuts help */}
<div className="fixed bottom-4 right-4">
  <button
    onClick={() => setShowShortcuts(true)}
    className="p-2 bg-gray-800 text-white rounded-full shadow-lg hover:bg-gray-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
    aria-label="Show keyboard shortcuts"
  >
    <Keyboard className="w-5 h-5" aria-hidden="true" />
  </button>
</div>

{/* Improve caption editor accessibility */}
<div
  role="region"
  aria-label="Caption editor"
  className="space-y-4"
>
  {editor.getCaptions().map(caption => (
    <div
      key={caption.id}
      role="group"
      aria-label={`Caption from ${caption.start.toFixed(2)} to ${caption.end.toFixed(2)} seconds`}
      onClick={() => setSelectedSegment(caption.id)}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          setSelectedSegment(caption.id);
        }
      }}
      tabIndex={0}
      className={`p-4 rounded-lg border transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary-500 ${
        selectedSegment === caption.id
          ? 'border-primary-500 bg-primary-50'
          : 'border-gray-200 hover:border-primary-300'
      }`}
    >
      {/* ... rest of caption editor ... */}
    </div>
  ))}
</div>