import React, { useState, useEffect } from 'react';
import { useMediaStore } from '../lib/store';
import { AlertCircle, CheckCircle, Loader2, RefreshCw } from 'lucide-react';

interface Props {
  onComplete: () => void;
}

export function MediaProcessor({ onComplete }: Props) {
  const currentMedia = useMediaStore((state) => state.currentMedia);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<'idle' | 'processing' | 'complete' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (currentMedia) {
      startProcessing();
    }
  }, [currentMedia]);

  const startProcessing = async () => {
    if (!currentMedia) return;

    try {
      setStatus('processing');
      setError(null);

      // Simulate processing steps
      for (let i = 0; i <= 100; i += 10) {
        setProgress(i);
        await new Promise(resolve => setTimeout(resolve, 200));
      }

      setStatus('complete');
      setTimeout(onComplete, 1000);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Processing failed');
      setStatus('error');
    }
  };

  if (!currentMedia) return null;

  return (
    <div className="space-y-6">
      {/* Progress Indicator */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="space-y-4">
          {status === 'processing' && (
            <>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center space-x-2">
                  <Loader2 className="w-4 h-4 text-primary-500 animate-spin" />
                  <span className="font-medium">Processing media...</span>
                </div>
                <span className="text-gray-500">{progress}%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary-500 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </>
          )}

          {status === 'complete' && (
            <div className="flex items-center space-x-2 text-green-600">
              <CheckCircle className="w-5 h-5" />
              <span>Processing complete!</span>
            </div>
          )}

          {status === 'error' && (
            <div className="p-4 bg-red-50 rounded-lg">
              <div className="flex items-center space-x-2 text-red-600">
                <AlertCircle className="w-5 h-5" />
                <div>
                  <p className="font-medium">Processing failed</p>
                  {error && <p className="text-sm mt-1">{error}</p>}
                </div>
              </div>
              <button
                onClick={startProcessing}
                className="mt-4 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors flex items-center space-x-2"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Retry</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}