import React, { useEffect, useState } from 'react';
import { MediaCapture } from '../lib/mediaUpload/mediaCapture';
import { MediaSource } from '../lib/mediaUpload/types';

interface Props {
  onDeviceSelect: (deviceId: string, type: 'video' | 'audio') => void;
}

export function MediaDeviceSelector({ onDeviceSelect }: Props) {
  const [devices, setDevices] = useState<MediaSource[]>([]);
  const [loading, setLoading] = useState(true);
  const mediaCapture = new MediaCapture();

  useEffect(() => {
    const loadDevices = async () => {
      const availableDevices = await mediaCapture.getAvailableDevices();
      setDevices(availableDevices);
      setLoading(false);
    };

    loadDevices();
  }, []);

  if (loading) {
    return <div>Loading available devices...</div>;
  }

  if (devices.length === 0) {
    return <div>No media devices found</div>;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Available Devices</h3>
      <div className="grid gap-2">
        {devices.map(device => (
          <button
            key={device.id}
            onClick={() => onDeviceSelect(device.id, device.type === 'videoinput' ? 'video' : 'audio')}
            className="flex items-center p-3 border rounded-lg hover:bg-gray-50"
          >
            <span className="mr-2">
              {device.type === 'videoinput' ? '📹' : '🎤'}
            </span>
            <span>{device.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}