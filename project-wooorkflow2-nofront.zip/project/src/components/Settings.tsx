{/* Add to the existing Settings component, right after the useState declarations */}
const [reducedMotion, setReducedMotion] = useState(false);

{/* Add this section in the Accessibility Settings section */}
<div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
  <div>
    <p className="font-medium">Reduce Motion</p>
    <p className="text-sm text-gray-500">Minimize animations throughout the app</p>
  </div>
  <label className="relative inline-flex items-center cursor-pointer">
    <input
      type="checkbox"
      checked={reducedMotion}
      onChange={(e) => {
        setReducedMotion(e.target.checked);
        document.documentElement.classList.toggle('reduce-motion', e.target.checked);
      }}
      className="sr-only peer"
    />
    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
  </label>
</div>