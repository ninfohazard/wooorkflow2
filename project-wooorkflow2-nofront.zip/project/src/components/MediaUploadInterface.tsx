{/* Update progress indicator */}
<div className="text-center">
  <Loader2 className="w-12 h-12 text-primary-500 animate-spin mx-auto" />
  <p className="mt-4 text-primary-600 font-medium">
    Processing media... {uploadProgress.toFixed(1)}%
  </p>
  <div className="mt-2 h-2 bg-gray-100 rounded-full overflow-hidden">
    <div 
      className="h-full bg-primary-500 transition-all duration-300 ease-out"
      style={{ width: `${uploadProgress}%` }}
    />
  </div>
</div>