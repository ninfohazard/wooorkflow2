import React, { useState, useEffect } from 'react';
import { OAuthManager } from '../lib/auth/oauthManager';
import { SocialPlatform } from '../lib/socialMedia/types';
import { PLATFORM_CONFIG } from '../lib/socialMedia/config';
import {
  Twitter,
  Instagram,
  Video,
  AlertCircle,
  CheckCircle,
  Loader2,
  RefreshCw
} from 'lucide-react';

interface PlatformStatus {
  isConnected: boolean;
  isRefreshing: boolean;
  error?: string;
}

export function SocialMediaConnect() {
  const [platformStatus, setPlatformStatus] = useState<Record<SocialPlatform, PlatformStatus>>({
    twitter: { isConnected: false, isRefreshing: false },
    instagram: { isConnected: false, isRefreshing: false },
    tiktok: { isConnected: false, isRefreshing: false }
  });

  const platformIcons: Record<SocialPlatform, React.ReactNode> = {
    twitter: <Twitter className="w-6 h-6" />,
    instagram: <Instagram className="w-6 h-6" />,
    tiktok: <Video className="w-6 h-6" />
  };

  useEffect(() => {
    checkAllPlatforms();
  }, []);

  const checkAllPlatforms = async () => {
    for (const platform of Object.keys(PLATFORM_CONFIG) as SocialPlatform[]) {
      if (PLATFORM_CONFIG[platform].enabled) {
        await checkPlatformStatus(platform);
      }
    }
  };

  const checkPlatformStatus = async (platform: SocialPlatform) => {
    try {
      const status = await OAuthManager.checkTokenStatus(platform);
      
      if (status.needsRefresh && status.isValid) {
        await refreshToken(platform);
      } else {
        setPlatformStatus(prev => ({
          ...prev,
          [platform]: {
            isConnected: status.isValid,
            isRefreshing: false
          }
        }));
      }
    } catch (error) {
      setPlatformStatus(prev => ({
        ...prev,
        [platform]: {
          isConnected: false,
          isRefreshing: false,
          error: 'Failed to check connection status'
        }
      }));
    }
  };

  const connectPlatform = async (platform: SocialPlatform) => {
    try {
      const authUrl = await OAuthManager.initiateOAuth(platform);
      window.location.href = authUrl;
    } catch (error) {
      setPlatformStatus(prev => ({
        ...prev,
        [platform]: {
          ...prev[platform],
          error: 'Failed to initiate connection'
        }
      }));
    }
  };

  const refreshToken = async (platform: SocialPlatform) => {
    setPlatformStatus(prev => ({
      ...prev,
      [platform]: { ...prev[platform], isRefreshing: true }
    }));

    try {
      const success = await OAuthManager.refreshToken(platform);
      setPlatformStatus(prev => ({
        ...prev,
        [platform]: {
          isConnected: success,
          isRefreshing: false,
          error: success ? undefined : 'Token refresh failed'
        }
      }));
    } catch (error) {
      setPlatformStatus(prev => ({
        ...prev,
        [platform]: {
          isConnected: false,
          isRefreshing: false,
          error: 'Failed to refresh token'
        }
      }));
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Connected Accounts</h2>
      
      <div className="grid gap-4">
        {Object.entries(PLATFORM_CONFIG)
          .filter(([_, config]) => config.enabled)
          .map(([platform]) => {
            const status = platformStatus[platform as SocialPlatform];
            
            return (
              <div
                key={platform}
                className="p-4 bg-white rounded-lg border shadow-sm"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`${
                      status.isConnected ? 'text-primary-600' : 'text-gray-400'
                    }`}>
                      {platformIcons[platform as SocialPlatform]}
                    </div>
                    <div>
                      <h3 className="font-medium capitalize">{platform}</h3>
                      <p className="text-sm text-gray-500">
                        {status.isConnected
                          ? 'Connected'
                          : 'Not connected'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {status.isRefreshing ? (
                      <Loader2 className="w-5 h-5 text-primary-500 animate-spin" />
                    ) : status.error ? (
                      <AlertCircle className="w-5 h-5 text-red-500" />
                    ) : status.isConnected ? (
                      <>
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <button
                          onClick={() => refreshToken(platform as SocialPlatform)}
                          className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors"
                          aria-label="Refresh Connection"
                        >
                          <RefreshCw className="w-4 h-4" />
                        </button>
                      </>
                    ) : null}

                    <button
                      onClick={() => connectPlatform(platform as SocialPlatform)}
                      className={`px-4 py-2 rounded-lg transition-colors ${
                        status.isConnected
                          ? 'text-red-600 hover:bg-red-50'
                          : 'bg-primary-600 text-white hover:bg-primary-700'
                      }`}
                    >
                      {status.isConnected ? 'Disconnect' : 'Connect'}
                    </button>
                  </div>
                </div>

                {status.error && (
                  <div className="mt-2 text-sm text-red-600 flex items-center space-x-1">
                    <AlertCircle className="w-4 h-4" />
                    <span>{status.error}</span>
                  </div>
                )}
              </div>
            );
          })}
      </div>
    </div>
  );
}