{/* Add loading state for language switch */}
const [isLanguageLoading, setIsLanguageLoading] = useState(false);

const handleLanguageChange = async (lang: string) => {
  setIsLanguageLoading(true);
  setSelectedLanguage(lang);
  setIsLanguageOpen(false);
  
  if (progress?.status === 'complete') {
    await processMedia(); // Reprocess with new language
  }
  
  setIsLanguageLoading(false);
};

{/* Update language selector */}
<button
  onClick={() => setIsLanguageOpen(!isLanguageOpen)}
  disabled={isLanguageLoading}
  className="flex items-center space-x-2 px-4 py-2 bg-white border rounded-lg shadow-sm hover:bg-gray-50 focus:ring-2 focus:ring-primary-500 focus:outline-none"
  aria-label="Select language"
  aria-expanded={isLanguageOpen}
  aria-haspopup="listbox"
>
  <Globe className="w-4 h-4" aria-hidden="true" />
  <span>
    {new Intl.DisplayNames([selectedLanguage], { type: 'language' })
      .of(selectedLanguage)}
  </span>
  {isLanguageLoading ? (
    <Loader2 className="w-4 h-4 animate-spin" />
  ) : (
    <ChevronDown className="w-4 h-4" aria-hidden="true" />
  )}
</button>