import React, { useState, useEffect } from 'react';
import { useMediaStore } from '../lib/store';
import { AudioExtractor } from '../lib/captionProcessor/audioExtractor';
import { CAPTION_PROCESSOR_CONFIG } from '../lib/captionProcessor/config';
import { CaptionSegment, ProcessingProgress } from '../lib/captionProcessor/types';
import { 
  AlertCircle, 
  CheckCircle, 
  RotateCcw, 
  Flag,
  ChevronDown,
  Loader2
} from 'lucide-react';

export function CaptionExtractor() {
  const currentMedia = useMediaStore((state) => state.currentMedia);
  const setCurrentMedia = useMediaStore((state) => state.setCurrentMedia);
  
  const [selectedLanguage, setSelectedLanguage] = useState(CAPTION_PROCESSOR_CONFIG.defaultLanguage);
  const [progress, setProgress] = useState<ProcessingProgress | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [captions, setCaptions] = useState<CaptionSegment[]>([]);
  const [highlightedErrors, setHighlightedErrors] = useState<Set<string>>(new Set());
  const [isLanguageOpen, setIsLanguageOpen] = useState(false);

  const audioExtractor = new AudioExtractor();

  useEffect(() => {
    if (currentMedia) {
      setCaptions([]);
      setError(null);
      setProgress(null);
    }
  }, [currentMedia]);

  const processCaptions = async () => {
    if (!currentMedia) return;

    setError(null);
    setProgress({ status: 'extracting', progress: 0, message: 'Extracting audio...' });

    try {
      // Initialize audio extractor
      await audioExtractor.initialize();

      // Extract audio from media
      const mediaResponse = await fetch(currentMedia.url);
      const mediaBlob = await mediaResponse.blob();
      const audioBlob = await audioExtractor.extractAudio(new File([mediaBlob], 'media'));

      setProgress({ status: 'transcribing', progress: 30, message: 'Generating captions...' });

      // Simulate caption generation (replace with actual OpenAI Whisper API call)
      await new Promise(resolve => setTimeout(resolve, 2000));
      const segments: CaptionSegment[] = [
        { start: 0, end: 2.5, text: 'Hello, this is a sample caption.' },
        { start: 2.5, end: 5, text: 'It demonstrates how the captions will appear.' }
      ];

      setCaptions(segments);
      setProgress({ status: 'complete', progress: 100, message: 'Captions generated successfully!' });

      // Update media store with captions
      if (currentMedia) {
        setCurrentMedia({
          ...currentMedia,
          captions: segments.map(s => s.text).join('\n')
        });
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to generate captions');
      setProgress({ status: 'error', progress: 0, message: 'Error generating captions' });
    }
  };

  const handleRetry = () => {
    processCaptions();
  };

  const toggleErrorHighlight = (id: string) => {
    const newHighlighted = new Set(highlightedErrors);
    if (highlightedErrors.has(id)) {
      newHighlighted.delete(id);
    } else {
      newHighlighted.add(id);
    }
    setHighlightedErrors(newHighlighted);
  };

  if (!currentMedia) {
    return null;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Caption Generation</h2>
        
        {/* Language Selection Dropdown */}
        <div className="relative">
          <button
            onClick={() => setIsLanguageOpen(!isLanguageOpen)}
            className="flex items-center space-x-2 px-4 py-2 bg-white border rounded-lg shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            <span>
              {new Intl.DisplayNames([selectedLanguage], { type: 'language' }).of(selectedLanguage)}
            </span>
            <ChevronDown className="w-4 h-4" />
          </button>

          {isLanguageOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border animate-fade-in z-10">
              <div className="py-1">
                {CAPTION_PROCESSOR_CONFIG.supportedLanguages.map(lang => (
                  <button
                    key={lang}
                    onClick={() => {
                      setSelectedLanguage(lang);
                      setIsLanguageOpen(false);
                    }}
                    className={`w-full px-4 py-2 text-left hover:bg-gray-100 ${
                      lang === selectedLanguage ? 'bg-primary-50 text-primary-600' : ''
                    }`}
                  >
                    {new Intl.DisplayNames([lang], { type: 'language' }).of(lang)}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Progress Indicator */}
      {progress && (
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <div className="flex items-center space-x-2">
              {progress.status === 'complete' ? (
                <CheckCircle className="w-4 h-4 text-green-500" />
              ) : progress.status === 'error' ? (
                <AlertCircle className="w-4 h-4 text-red-500" />
              ) : (
                <Loader2 className="w-4 h-4 text-primary-500 animate-spin" />
              )}
              <span className="font-medium">{progress.message}</span>
            </div>
            <span className="text-gray-500">{progress.progress}%</span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                progress.status === 'error' 
                  ? 'bg-red-500' 
                  : progress.status === 'complete'
                    ? 'bg-green-500'
                    : 'bg-primary-500'
              }`}
              style={{ width: `${progress.progress}%` }}
            />
          </div>
        </div>
      )}

      {/* Error Display */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start animate-fade-in">
          <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 mr-3" />
          <div className="flex-1">
            <p className="text-red-800 font-medium">Caption Generation Failed</p>
            <p className="text-red-600 text-sm mt-1">{error}</p>
          </div>
          <button
            onClick={handleRetry}
            className="ml-4 flex items-center px-3 py-1.5 bg-red-100 text-red-700 rounded-md hover:bg-red-200 transition-colors"
          >
            <RotateCcw className="w-4 h-4 mr-1.5" />
            Retry
          </button>
        </div>
      )}

      {/* Captions Preview */}
      {captions.length > 0 && !error && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">Generated Captions</h3>
            <button
              className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
              onClick={() => {/* Handle save/continue */}}
            >
              Continue
            </button>
          </div>
          
          <div className="space-y-2">
            {captions.map((caption, index) => (
              <div
                key={index}
                className={`p-3 rounded-lg border ${
                  highlightedErrors.has(index.toString())
                    ? 'border-red-300 bg-red-50'
                    : 'border-gray-200 hover:border-primary-300'
                } transition-colors cursor-pointer group`}
                onClick={() => toggleErrorHighlight(index.toString())}
              >
                <div className="flex items-center justify-between text-sm text-gray-500 mb-1">
                  <span>{caption.start.toFixed(2)}s - {caption.end.toFixed(2)}s</span>
                  <button 
                    className={`opacity-0 group-hover:opacity-100 transition-opacity ${
                      highlightedErrors.has(index.toString())
                        ? 'text-red-600'
                        : 'text-gray-400 hover:text-gray-600'
                    }`}
                  >
                    <Flag className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-gray-800">{caption.text}</p>
              </div>
            ))}
          </div>

          {progress?.status === 'complete' && (
            <div className="flex items-center text-green-700 bg-green-50 p-4 rounded-lg animate-fade-in">
              <CheckCircle className="w-5 h-5 mr-2" />
              <span>Captions generated successfully! Click Continue to proceed.</span>
            </div>
          )}
        </div>
      )}

      {/* Initial State */}
      {!progress && !error && !captions.length && (
        <div className="text-center py-12">
          <button
            onClick={processCaptions}
            className="px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
          >
            Generate Captions
          </button>
          <p className="mt-2 text-sm text-gray-500">
            Select your preferred language and click to start
          </p>
        </div>
      )}
    </div>
  );
}