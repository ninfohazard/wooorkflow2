import React, { useState, useEffect } from 'react';
import { StorageManager } from '../lib/storage/storageManager';
import { StorageStats, StorageAlert } from '../lib/storage/types';
import { HardDrive, AlertTriangle, Trash2, RefreshCw } from 'lucide-react';

export function StorageUsage() {
  const [stats, setStats] = useState<StorageStats | null>(null);
  const [alerts, setAlerts] = useState<StorageAlert[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const storageManager = new StorageManager();

  useEffect(() => {
    loadStorageData();
  }, []);

  const loadStorageData = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error('Not authenticated');

      const storageStats = await storageManager.getStorageStats(session.user.id);
      setStats(storageStats);

      const { data: storageAlerts } = await supabase
        .from('storage_alerts')
        .select('*')
        .eq('user_id', session.user.id)
        .eq('read', false)
        .order('created_at', { ascending: false });

      setAlerts(storageAlerts || []);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to load storage data');
    } finally {
      setIsLoading(false);
    }
  };

  const formatSize = (bytes: number): string => {
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;

    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }

    return `${size.toFixed(1)} ${units[unitIndex]}`;
  };

  const calculateUsagePercentage = (used: number, total: number): number => {
    return (used / total) * 100;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="w-6 h-6 text-primary-500 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
        <div className="flex items-center space-x-2 text-red-600">
          <AlertTriangle className="w-5 h-5" />
          <span>{error}</span>
        </div>
      </div>
    );
  }

  if (!stats) return null;

  const totalQuota = 10 * 1024 * 1024 * 1024; // 10GB
  const usagePercentage = calculateUsagePercentage(stats.totalSize, totalQuota);

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold mb-4">Storage Usage</h3>

        {/* Usage Overview */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <HardDrive className="w-6 h-6 text-primary-500" />
            <div>
              <p className="font-medium">{formatSize(stats.totalSize)} used</p>
              <p className="text-sm text-gray-500">of {formatSize(totalQuota)} total</p>
            </div>
          </div>
          <button
            onClick={loadStorageData}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100 transition-colors"
            aria-label="Refresh Storage Stats"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="relative h-4 bg-gray-200 rounded-full overflow-hidden">
          <div
            className={`absolute top-0 left-0 h-full transition-all duration-500 rounded-full ${
              usagePercentage > 90
                ? 'bg-red-500'
                : usagePercentage > 70
                ? 'bg-yellow-500'
                : 'bg-primary-500'
            }`}
            style={{ width: `${usagePercentage}%` }}
          />
        </div>

        {/* Storage Breakdown */}
        <div className="mt-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Permanent Storage</span>
            <span className="font-medium">
              {formatSize(stats.totalSize - stats.tempSize)}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Temporary Files</span>
            <span className="font-medium">{formatSize(stats.tempSize)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Total Files</span>
            <span className="font-medium">{stats.fileCount}</span>
          </div>
        </div>

        {/* Cleanup Action */}
        <div className="mt-6 flex justify-end">
          <button
            onClick={() => {/* Handle cleanup */}}
            className="flex items-center space-x-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear Temporary Files</span>
          </button>
        </div>
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-4">Storage Alerts</h3>
          <div className="space-y-4">
            {alerts.map(alert => (
              <div
                key={alert.id}
                className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg"
              >
                <AlertTriangle className="w-5 h-5 text-yellow-500 mt-0.5" />
                <div>
                  <p className="font-medium text-yellow-800">{alert.message}</p>
                  <p className="text-sm text-yellow-600 mt-1">
                    {new Date(alert.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}