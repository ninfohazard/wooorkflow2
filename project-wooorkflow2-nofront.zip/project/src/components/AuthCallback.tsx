import React, { useEffect, useState } from 'react';
import { OAuthManager } from '../lib/auth/oauthManager';
import { Loader2, CheckCircle, XCircle } from 'lucide-react';

export function AuthCallback() {
  const [status, setStatus] = useState<'processing' | 'success' | 'error'>('processing');
  const [error, setError] = useState<string>();

  useEffect(() => {
    handleCallback();
  }, []);

  const handleCallback = async () => {
    try {
      const params = new URLSearchParams(window.location.search);
      const code = params.get('code');
      const state = params.get('state');

      if (!code || !state) {
        throw new Error('Invalid callback parameters');
      }

      await OAuthManager.handleCallback(code, state);
      setStatus('success');

      // Redirect back after a short delay
      setTimeout(() => {
        window.location.href = '/';
      }, 2000);
    } catch (error) {
      setStatus('error');
      setError(error instanceof Error ? error.message : 'Authentication failed');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full space-y-4">
        <div className="text-center">
          {status === 'processing' && (
            <>
              <Loader2 className="w-12 h-12 text-primary-500 animate-spin mx-auto" />
              <h2 className="mt-4 text-xl font-semibold">Completing Authentication</h2>
              <p className="mt-2 text-gray-500">Please wait while we finish setting up your account...</p>
            </>
          )}

          {status === 'success' && (
            <>
              <CheckCircle className="w-12 h-12 text-green-500 mx-auto" />
              <h2 className="mt-4 text-xl font-semibold text-green-700">Authentication Successful</h2>
              <p className="mt-2 text-gray-500">Redirecting you back to the app...</p>
            </>
          )}

          {status === 'error' && (
            <>
              <XCircle className="w-12 h-12 text-red-500 mx-auto" />
              <h2 className="mt-4 text-xl font-semibold text-red-700">Authentication Failed</h2>
              <p className="mt-2 text-gray-500">{error}</p>
              <button
                onClick={() => window.location.href = '/'}
                className="mt-4 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
              >
                Return to App
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}