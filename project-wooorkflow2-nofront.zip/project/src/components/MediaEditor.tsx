import React, { useState, useRef, useEffect } from 'react';
import { useMediaStore } from '../lib/store';
import { 
  Scissors, 
  Undo, 
  Redo, 
  Save, 
  Play, 
  Pause, 
  ChevronLeft, 
  ChevronRight,
  Merge,
  Clock,
  Edit2,
  Trash2,
  Keyboard
} from 'lucide-react';

interface EditableSegment {
  id: string;
  start: number;
  end: number;
  text: string;
}

interface KeyboardShortcut {
  key: string;
  description: string;
  ctrlKey?: boolean;
  shiftKey?: boolean;
  altKey?: boolean;
}

export function MediaEditor() {
  // ... existing state declarations ...

  const [showShortcuts, setShowShortcuts] = useState(false);

  const shortcuts: KeyboardShortcut[] = [
    { key: 'Space', description: 'Play/Pause' },
    { key: 'ArrowLeft', description: 'Seek -5s' },
    { key: 'ArrowRight', description: 'Seek +5s' },
    { key: 'z', description: 'Undo', ctrlKey: true },
    { key: 'y', description: 'Redo', ctrlKey: true },
    { key: 's', description: 'Split at current time' },
    { key: 'm', description: 'Merge with next segment' },
    { key: 'ArrowLeft', description: 'Previous segment', altKey: true },
    { key: 'ArrowRight', description: 'Next segment', altKey: true },
    { key: 'Delete', description: 'Delete selected segment' },
    { key: 'k', description: 'Show keyboard shortcuts' }
  ];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't handle shortcuts when typing in a text field
      if (e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLInputElement) {
        return;
      }

      // Show keyboard shortcuts
      if (e.key === 'k') {
        setShowShortcuts(prev => !prev);
        return;
      }

      // Play/Pause
      if (e.code === 'Space') {
        e.preventDefault();
        handlePlayPause();
        return;
      }

      // Seeking
      if (e.key === 'ArrowLeft' && !e.altKey) {
        e.preventDefault();
        if (videoRef.current) {
          videoRef.current.currentTime = Math.max(0, currentTime - 5);
        }
        return;
      }

      if (e.key === 'ArrowRight' && !e.altKey) {
        e.preventDefault();
        if (videoRef.current) {
          videoRef.current.currentTime = Math.min(duration, currentTime + 5);
        }
        return;
      }

      // Undo/Redo
      if (e.ctrlKey && e.key === 'z') {
        e.preventDefault();
        handleUndo();
        return;
      }

      if (e.ctrlKey && e.key === 'y') {
        e.preventDefault();
        handleRedo();
        return;
      }

      // Split/Merge
      if (e.key === 's' && selectedSegment) {
        e.preventDefault();
        handleSplit();
        return;
      }

      if (e.key === 'm' && selectedSegment) {
        e.preventDefault();
        handleMerge();
        return;
      }

      // Segment navigation
      if (e.altKey && e.key === 'ArrowLeft') {
        e.preventDefault();
        const currentIndex = segments.findIndex(s => s.id === selectedSegment);
        if (currentIndex > 0) {
          setSelectedSegment(segments[currentIndex - 1].id);
        }
        return;
      }

      if (e.altKey && e.key === 'ArrowRight') {
        e.preventDefault();
        const currentIndex = segments.findIndex(s => s.id === selectedSegment);
        if (currentIndex < segments.length - 1) {
          setSelectedSegment(segments[currentIndex + 1].id);
        }
        return;
      }

      // Delete segment
      if (e.key === 'Delete' && selectedSegment) {
        e.preventDefault();
        handleDelete(selectedSegment);
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentTime, duration, selectedSegment, segments]);

  // ... existing code ...

  return (
    <div className="space-y-6">
      {/* ... existing JSX ... */}

      {/* Help Button with Keyboard Icon */}
      <button
        onClick={() => setShowShortcuts(true)}
        className="fixed bottom-4 right-4 p-3 bg-gray-800 text-white rounded-full shadow-lg hover:bg-gray-700 transition-colors"
        title="Show Keyboard Shortcuts"
      >
        <Keyboard className="w-6 h-6" />
      </button>

      {/* Keyboard Shortcuts Modal */}
      {showShortcuts && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-lg font-medium">Keyboard Shortcuts</h3>
              <button
                onClick={() => setShowShortcuts(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>
            <div className="p-4">
              <div className="space-y-2">
                {shortcuts.map((shortcut, index) => (
                  <div
                    key={index}
                    className="flex justify-between items-center py-2"
                  >
                    <span className="text-gray-600">{shortcut.description}</span>
                    <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-sm font-mono">
                      {[
                        shortcut.ctrlKey && 'Ctrl',
                        shortcut.altKey && 'Alt',
                        shortcut.shiftKey && 'Shift',
                        shortcut.key
                      ]
                        .filter(Boolean)
                        .join(' + ')}
                    </kbd>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}