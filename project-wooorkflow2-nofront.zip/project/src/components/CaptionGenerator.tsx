import React, { useState } from 'react';
import { useMediaStore } from '../lib/store';
import { AICaptionService, TranscriptionResult } from '../lib/ai/aiCaptionService';
import { TranscriptionOptions, TranscriptionOptionsSchema } from '../lib/ai/config';
import { AI_CONFIG } from '../lib/ai/config';
import {
  Loader2,
  CheckCircle,
  AlertCircle,
  Settings,
  Languages,
  Users,
  SmilePlus
} from 'lucide-react';

export function CaptionGenerator() {
  const currentMedia = useMediaStore((state) => state.currentMedia);
  const setCurrentMedia = useMediaStore((state) => state.setCurrentMedia);

  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [captions, setCaptions] = useState<TranscriptionResult | null>(null);
  const [showSettings, setShowSettings] = useState(false);

  const [options, setOptions] = useState<TranscriptionOptions>({
    language: AI_CONFIG.openai.defaultLanguage,
    diarization: false,
    sentiment: false,
    format: 'json',
    timestamps: true
  });

  const aiCaptionService = new AICaptionService();

  const generateCaptions = async () => {
    if (!currentMedia) return;

    try {
      setIsGenerating(true);
      setError(null);
      setProgress(0);

      // Fetch media file
      const response = await fetch(currentMedia.url);
      const mediaBlob = await response.blob();

      // Extract audio if it's a video
      let audioBlob = mediaBlob;
      if (currentMedia.type === 'video') {
        // Audio extraction would be handled here
        // For now, we'll assume we have the audio
      }

      // Generate captions
      const result = await aiCaptionService.generateCaptions(
        audioBlob,
        options,
        setProgress
      );

      setCaptions(result);
      setCurrentMedia({
        ...currentMedia,
        captions: result.fullText
      });
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to generate captions');
    } finally {
      setIsGenerating(false);
    }
  };

  if (!currentMedia) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">AI Caption Generation</h2>
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>

      {showSettings && (
        <div className="bg-gray-50 p-4 rounded-lg space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Languages className="w-5 h-5 text-gray-500" />
              <label className="text-sm font-medium">Language</label>
            </div>
            <select
              value={options.language}
              onChange={(e) => setOptions({ ...options, language: e.target.value })}
              className="rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
            >
              {AI_CONFIG.openai.supportedLanguages.map(lang => (
                <option key={lang} value={lang}>
                  {new Intl.DisplayNames([lang], { type: 'language' }).of(lang)}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-gray-500" />
              <label className="text-sm font-medium">Speaker Detection</label>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={options.diarization}
                onChange={(e) => setOptions({ ...options, diarization: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <SmilePlus className="w-5 h-5 text-gray-500" />
              <label className="text-sm font-medium">Sentiment Analysis</label>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={options.sentiment}
                onChange={(e) => setOptions({ ...options, sentiment: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
            </label>
          </div>
        </div>
      )}

      {isGenerating ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-2">
              <Loader2 className="w-4 h-4 text-primary-500 animate-spin" />
              <span>Generating captions...</span>
            </div>
            <span>{progress}%</span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full">
            <div
              className="h-full bg-primary-500 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      ) : error ? (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-center space-x-2 text-red-600">
            <AlertCircle className="w-5 h-5" />
            <span>{error}</span>
          </div>
          <button
            onClick={generateCaptions}
            className="mt-4 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
          >
            Try Again
          </button>
        </div>
      ) : captions ? (
        <div className="space-y-4">
          <div className="flex items-center space-x-2 text-green-600">
            <CheckCircle className="w-5 h-5" />
            <span>Captions generated successfully!</span>
          </div>

          <div className="bg-white p-4 rounded-lg border space-y-4">
            {captions.segments.map((segment, index) => (
              <div
                key={index}
                className="p-3 bg-gray-50 rounded-lg space-y-2"
              >
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>{segment.start.toFixed(2)}s - {segment.end.toFixed(2)}s</span>
                  {segment.speaker && (
                    <span className="px-2 py-1 bg-primary-100 text-primary-700 rounded-full">
                      Speaker {segment.speaker}
                    </span>
                  )}
                </div>
                <p className="text-gray-800">{segment.text}</p>
                {segment.sentiment && (
                  <div className={`text-sm ${
                    segment.sentiment === 'positive'
                      ? 'text-green-600'
                      : segment.sentiment === 'negative'
                        ? 'text-red-600'
                        : 'text-gray-600'
                  }`}>
                    Sentiment: {segment.sentiment}
                  </div>
                )}
              </div>
            ))}
          </div>

          {captions.metadata && (
            <div className="text-sm text-gray-500 space-y-1">
              <p>Duration: {captions.metadata.duration.toFixed(1)}s</p>
              <p>Words: {captions.metadata.wordCount}</p>
              <p>Confidence: {(captions.metadata.confidence * 100).toFixed(1)}%</p>
            </div>
          )}
        </div>
      ) : (
        <button
          onClick={generateCaptions}
          className="w-full py-4 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
        >
          Generate AI Captions
        </button>
      )}
    </div>
  );
}