import React, { useState } from 'react';
import { ExternalServiceConfig as ServiceConfig } from '../lib/workflow/types';

interface Props {
  onConfigChange: (step: string, config: ServiceConfig | null) => void;
}

export function WorkflowConfig({ onConfigChange }: Props) {
  const [configs, setConfigs] = useState<Record<string, ServiceConfig | null>>({
    mediaProcessing: null,
    captionGeneration: null,
    mediaEditing: null,
    socialPosting: null
  });

  const [activeSteps, setActiveSteps] = useState<Record<string, boolean>>({
    mediaProcessing: false,
    captionGeneration: false,
    mediaEditing: false,
    socialPosting: false
  });

  const stepLabels = {
    mediaProcessing: 'Media Processing',
    captionGeneration: 'Caption Generation',
    mediaEditing: 'Media Editing',
    socialPosting: 'Social Media Posting'
  };

  const handleToggle = (step: string) => {
    const newActiveSteps = { ...activeSteps, [step]: !activeSteps[step] };
    setActiveSteps(newActiveSteps);
    
    if (!newActiveSteps[step]) {
      // If turning off external service, clear config
      const newConfigs = { ...configs, [step]: null };
      setConfigs(newConfigs);
      onConfigChange(step, null);
    }
  };

  const handleConfigChange = (step: string, field: keyof ServiceConfig, value: string) => {
    const newConfig = { ...(configs[step] || {}), [field]: value } as ServiceConfig;
    const newConfigs = { ...configs, [step]: newConfig };
    setConfigs(newConfigs);
    onConfigChange(step, newConfig);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Workflow Configuration</h2>
      
      {Object.entries(stepLabels).map(([step, label]) => (
        <div key={step} className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">{label}</h3>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={activeSteps[step]}
                onChange={() => handleToggle(step)}
                className="rounded text-blue-500 focus:ring-blue-500"
              />
              <span>Use External Service</span>
            </label>
          </div>

          {activeSteps[step] && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Service Name
                </label>
                <input
                  type="text"
                  value={configs[step]?.name || ''}
                  onChange={(e) => handleConfigChange(step, 'name', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  API URL
                </label>
                <input
                  type="url"
                  value={configs[step]?.url || ''}
                  onChange={(e) => handleConfigChange(step, 'url', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  API Key
                </label>
                <input
                  type="password"
                  value={configs[step]?.apiKey || ''}
                  onChange={(e) => handleConfigChange(step, 'apiKey', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}