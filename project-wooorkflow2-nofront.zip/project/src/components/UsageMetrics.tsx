import React, { useState, useEffect } from 'react';
import { FeedbackManager } from '../lib/analytics/feedbackManager';
import { UsageMetrics } from '../lib/analytics/feedbackManager';
import {
  BarChart3,
  Clock,
  Users,
  CheckCircle,
  RefreshCw,
  AlertCircle
} from 'lucide-react';

export function UsageMetricsDisplay() {
  const [metrics, setMetrics] = useState<UsageMetrics | null>(null);
  const [timeframe, setTimeframe] = useState<'day' | 'week' | 'month'>('week');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadMetrics();
  }, [timeframe]);

  const loadMetrics = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await FeedbackManager.getUsageMetrics(timeframe);
      setMetrics(data);
    } catch (error) {
      setError('Failed to load usage metrics');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="w-6 h-6 text-primary-500 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
        <div className="flex items-center space-x-2 text-red-600">
          <AlertCircle className="w-5 h-5" />
          <span>{error}</span>
        </div>
      </div>
    );
  }

  if (!metrics) return null;

  return (
    <div className="space-y-6">
      {/* Timeframe Selection */}
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold">Usage Metrics</h2>
        <div className="flex space-x-2">
          {(['day', 'week', 'month'] as const).map(option => (
            <button
              key={option}
              onClick={() => setTimeframe(option)}
              className={`px-3 py-1 rounded-lg text-sm capitalize transition-colors ${
                timeframe === option
                  ? 'bg-primary-100 text-primary-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Active Users */}
        <div className="bg-white p-4 rounded-lg shadow-sm border">
          <div className="flex items-center space-x-2 text-primary-600 mb-2">
            <Users className="w-5 h-5" />
            <h3 className="font-medium">Active Users</h3>
          </div>
          <p className="text-2xl font-bold">{metrics.activeUsers}</p>
        </div>

        {/* Processing Time */}
        <div className="bg-white p-4 rounded-lg shadow-sm border">
          <div className="flex items-center space-x-2 text-primary-600 mb-2">
            <Clock className="w-5 h-5" />
            <h3 className="font-medium">Avg. Processing Time</h3>
          </div>
          <p className="text-2xl font-bold">
            {metrics.averageProcessingTime.toFixed(2)}s
          </p>
        </div>

        {/* Success Rate */}
        <div className="bg-white p-4 rounded-lg shadow-sm border">
          <div className="flex items-center space-x-2 text-primary-600 mb-2">
            <CheckCircle className="w-5 h-5" />
            <h3 className="font-medium">Success Rate</h3>
          </div>
          <p className="text-2xl font-bold">{metrics.successRate.toFixed(1)}%</p>
        </div>

        {/* Popular Features */}
        <div className="bg-white p-4 rounded-lg shadow-sm border">
          <div className="flex items-center space-x-2 text-primary-600 mb-2">
            <BarChart3 className="w-5 h-5" />
            <h3 className="font-medium">Popular Features</h3>
          </div>
          <div className="space-y-2">
            {Object.entries(metrics.popularFeatures)
              .sort(([, a], [, b]) => b - a)
              .slice(0, 3)
              .map(([feature, count]) => (
                <div
                  key={feature}
                  className="flex items-center justify-between text-sm"
                >
                  <span className="text-gray-600 capitalize">
                    {feature.replace(/_/g, ' ')}
                  </span>
                  <span className="font-medium">{count}</span>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}