import React from 'react';
import { useMediaStore } from '../lib/store';

export function MediaPlayer() {
  const currentMedia = useMediaStore((state) => state.currentMedia);

  if (!currentMedia) return null;

  return (
    <div className="w-full max-w-2xl mx-auto">
      {currentMedia.type === 'video' ? (
        <video
          src={currentMedia.url}
          controls
          className="w-full rounded-lg shadow-lg aspect-video bg-black"
          playsInline
        >
          Your browser does not support the video tag.
        </video>
      ) : (
        <audio
          src={currentMedia.url}
          controls
          className="w-full"
        >
          Your browser does not support the audio tag.
        </audio>
      )}
      {currentMedia.captions && (
        <div className="mt-4 p-4 bg-gray-100 rounded-lg">
          <h3 className="font-semibold mb-2">Captions:</h3>
          <p className="text-gray-700 whitespace-pre-wrap">{currentMedia.captions}</p>
        </div>
      )}
    </div>
  );
}