import React, { useState, useEffect } from 'react';
import { SocialMediaManager } from '../lib/socialMedia/socialMediaManager';
import { PostMetadata, PostProgress, PostResult, SocialPlatform } from '../lib/socialMedia/types';
import { PLATFORM_CONFIG } from '../lib/socialMedia/config';
import {
  Twitter,
  Instagram,
  Video,
  Settings,
  Calendar,
  Hash,
  Check,
  AlertCircle,
  Loader2,
  ChevronLeft,
  ChevronRight,
  Eye,
  Link
} from 'lucide-react';

interface Props {
  mediaUrl: string;
  mediaId: string;
}

const platformIcons: Record<SocialPlatform, React.ReactNode> = {
  twitter: <Twitter className="w-6 h-6" />,
  instagram: <Instagram className="w-6 h-6" />,
  tiktok: <Video className="w-6 h-6" />
};

export function SocialMediaPost({ mediaUrl, mediaId }: Props) {
  const [caption, setCaption] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [selectedPlatforms, setSelectedPlatforms] = useState<SocialPlatform[]>([]);
  const [progress, setProgress] = useState<PostProgress[]>([]);
  const [results, setResults] = useState<PostResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [currentPlatformIndex, setCurrentPlatformIndex] = useState(0);
  const [autoPost, setAutoPost] = useState(true);
  const [showPreview, setShowPreview] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const socialMediaManager = new SocialMediaManager();
  const platforms = Object.entries(PLATFORM_CONFIG)
    .filter(([_, config]) => config.enabled)
    .map(([platform]) => platform as SocialPlatform);

  useEffect(() => {
    checkPlatformAuth();
  }, []);

  const checkPlatformAuth = async () => {
    const authStatus = await Promise.all(
      platforms.map(platform => socialMediaManager.authenticate(platform))
    );
    
    // Auto-select authenticated platforms
    setSelectedPlatforms(
      platforms.filter((_, index) => authStatus[index])
    );
  };

  const handlePlatformToggle = (platform: SocialPlatform) => {
    setSelectedPlatforms(prev =>
      prev.includes(platform)
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  const handleTagInput = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter' && event.currentTarget.value) {
      const newTag = event.currentTarget.value.trim();
      if (newTag && !tags.includes(newTag)) {
        setTags(prev => [...prev, newTag]);
      }
      event.currentTarget.value = '';
    }
  };

  const handlePost = async () => {
    if (selectedPlatforms.length === 0) {
      setError('Please select at least one platform');
      return;
    }

    setError(null);
    setProgress([]);
    setResults([]);

    const metadata: PostMetadata = {
      caption,
      tags,
      platforms: selectedPlatforms
    };

    try {
      // Post to selected platforms
      const postResults = await socialMediaManager.post(
        mediaUrl,
        metadata,
        (progress) => {
          setProgress(prev => {
            const existing = prev.filter(p => p.platform !== progress.platform);
            return [...existing, progress];
          });
        }
      );

      setResults(postResults);

      // Log results
      for (const result of postResults) {
        await socialMediaManager.logPostAttempt(
          mediaId,
          result.platform,
          result.success,
          result.error
        );
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to post');
    }
  };

  const navigatePlatforms = (direction: 'prev' | 'next') => {
    setCurrentPlatformIndex(prev => {
      if (direction === 'prev') {
        return prev === 0 ? platforms.length - 1 : prev - 1;
      } else {
        return prev === platforms.length - 1 ? 0 : prev + 1;
      }
    });
  };

  return (
    <div className="space-y-6 bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold">Share to Social Media</h2>

      {/* Platform Carousel */}
      <div className="relative">
        <div className="flex items-center justify-center space-x-4">
          <button
            onClick={() => navigatePlatforms('prev')}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            aria-label="Previous Platform"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <div className="flex space-x-4 overflow-hidden">
            {platforms.map((platform, index) => {
              const isAuthenticated = selectedPlatforms.includes(platform);
              const isActive = index === currentPlatformIndex;

              return (
                <div
                  key={platform}
                  className={`transform transition-all duration-300 ${
                    isActive ? 'scale-100 opacity-100' : 'scale-90 opacity-50'
                  }`}
                  style={{
                    transform: `translateX(${(index - currentPlatformIndex) * 120}%)`
                  }}
                >
                  <button
                    onClick={() => handlePlatformToggle(platform)}
                    className={`w-32 h-32 rounded-xl flex flex-col items-center justify-center space-y-2 transition-colors ${
                      isAuthenticated
                        ? 'bg-primary-50 border-2 border-primary-500'
                        : 'bg-gray-50 border-2 border-gray-200 hover:border-primary-300'
                    }`}
                  >
                    <div className={`${isAuthenticated ? 'text-primary-600' : 'text-gray-400'}`}>
                      {platformIcons[platform]}
                    </div>
                    <span className={`capitalize ${isAuthenticated ? 'text-primary-600' : 'text-gray-500'}`}>
                      {platform}
                    </span>
                    {!isAuthenticated && (
                      <span className="text-xs text-gray-400">Not Connected</span>
                    )}
                  </button>
                </div>
              );
            })}
          </div>

          <button
            onClick={() => navigatePlatforms('next')}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            aria-label="Next Platform"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* Settings Button */}
        <button
          onClick={() => setIsSettingsOpen(true)}
          className="absolute top-0 right-0 p-2 text-gray-400 hover:text-gray-600 transition-colors"
          aria-label="Platform Settings"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>

      {/* Caption Input */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Caption</h3>
          <button
            onClick={() => setShowPreview(true)}
            className="flex items-center space-x-1 text-primary-600 hover:text-primary-700"
          >
            <Eye className="w-4 h-4" />
            <span>Preview</span>
          </button>
        </div>
        <textarea
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          className="w-full p-4 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          rows={4}
          placeholder="Write your caption..."
        />
      </div>

      {/* Tags Input */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <Hash className="w-4 h-4 text-gray-400" />
          <h3 className="text-lg font-semibold">Tags</h3>
        </div>
        <div className="flex flex-wrap gap-2 mb-2">
          {tags.map((tag, index) => (
            <span
              key={index}
              className="px-3 py-1 bg-primary-50 text-primary-600 rounded-full text-sm flex items-center"
            >
              #{tag}
              <button
                onClick={() => setTags(prev => prev.filter((_, i) => i !== index))}
                className="ml-2 text-primary-400 hover:text-primary-600"
              >
                ×
              </button>
            </span>
          ))}
        </div>
        <input
          type="text"
          onKeyDown={handleTagInput}
          className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          placeholder="Type a tag and press Enter..."
        />
      </div>

      {/* Auto-post Toggle */}
      <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center space-x-2">
          <Calendar className="w-5 h-5 text-gray-400" />
          <span className="font-medium">Auto-post to all platforms</span>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={autoPost}
            onChange={(e) => setAutoPost(e.target.checked)}
            className="sr-only peer"
          />
          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
        </label>
      </div>

      {/* Post Button */}
      <button
        onClick={handlePost}
        disabled={selectedPlatforms.length === 0 || progress.length > 0}
        className="w-full py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Post to Selected Platforms
      </button>

      {/* Progress */}
      {progress.length > 0 && (
        <div className="space-y-4">
          {progress.map((p) => (
            <div key={p.platform} className="space-y-2">
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  {platformIcons[p.platform]}
                  <span className="capitalize">{p.platform}</span>
                </div>
                <span className="text-sm text-gray-500">{p.message}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-primary-500 rounded-full h-2 transition-all duration-300"
                  style={{ width: `${p.progress}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Results */}
      {results.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Results</h3>
          {results.map((result) => (
            <div
              key={result.platform}
              className={`p-4 rounded-lg flex items-center justify-between ${
                result.success ? 'bg-green-50' : 'bg-red-50'
              }`}
            >
              <div className="flex items-center space-x-3">
                {result.success ? (
                  <Check className="w-5 h-5 text-green-500" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-500" />
                )}
                <div>
                  <span className="capitalize font-medium">
                    {result.platform}
                  </span>
                  {!result.success && (
                    <p className="text-sm text-red-600 mt-1">{result.error}</p>
                  )}
                </div>
              </div>
              {result.success && result.postUrl && (
                <a
                  href={result.postUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-1 text-primary-600 hover:text-primary-700"
                >
                  <Link className="w-4 h-4" />
                  <span>View Post</span>
                </a>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Error Display */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-600 animate-fade-in">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-5 h-5" />
            <span>{error}</span>
          </div>
        </div>
      )}

      {/* Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-lg font-medium">Post Preview</h3>
              <button
                onClick={() => setShowPreview(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>
            <div className="p-6 space-y-4">
              {selectedPlatforms.map(platform => (
                <div key={platform} className="border rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-4">
                    {platformIcons[platform]}
                    <span className="capitalize font-medium">{platform}</span>
                  </div>
                  <img src={mediaUrl} alt="Media preview" className="rounded-lg mb-4" />
                  <p className="text-gray-700">{caption}</p>
                  {tags.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {tags.map((tag, index) => (
                        <span key={index} className="text-primary-600">#{tag}</span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}