export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      analytics_events: {
        Row: {
          id: string
          event_type: string
          user_id: string
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          event_type: string
          user_id: string
          metadata: Json
          created_at?: string
        }
        Update: {
          id?: string
          event_type?: string
          user_id?: string
          metadata?: Json
          created_at?: string
        }
      }
      media_files: {
        Row: {
          id: string
          user_id: string
          size: number
          type: string
          is_temporary: boolean
          encrypted: boolean
          created_at: string
          expires_at: string | null
        }
        Insert: {
          id?: string
          user_id: string
          size: number
          type: string
          is_temporary?: boolean
          encrypted?: boolean
          created_at?: string
          expires_at?: string | null
        }
        Update: {
          id?: string
          user_id?: string
          size?: number
          type?: string
          is_temporary?: boolean
          encrypted?: boolean
          created_at?: string
          expires_at?: string | null
        }
      }
      storage_alerts: {
        Row: {
          id: string
          user_id: string
          type: string
          message: string
          created_at: string
          read: boolean
        }
        Insert: {
          id?: string
          user_id: string
          type: string
          message: string
          created_at?: string
          read?: boolean
        }
        Update: {
          id?: string
          user_id?: string
          type?: string
          message?: string
          created_at?: string
          read?: boolean
        }
      }
      user_feedback: {
        Row: {
          id: string
          type: string
          description: string
          metadata: Json | null
          user_id: string | null
          created_at: string
        }
        Insert: {
          id?: string
          type: string
          description: string
          metadata?: Json | null
          user_id?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          type?: string
          description?: string
          metadata?: Json | null
          user_id?: string | null
          created_at?: string
        }
      }
    }
  }
}