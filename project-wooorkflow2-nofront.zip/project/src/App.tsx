import React, { useState } from 'react';
import { MediaWorkflowUI } from './components/MediaWorkflowUI';
import { ServiceHealthIndicator } from './components/ServiceHealthIndicator';
import { Settings } from './components/Settings';
import { FeedbackDialog } from './components/FeedbackDialog';
import { StorageUsage } from './components/StorageUsage';
import { SocialMediaConnect } from './components/SocialMediaConnect';
import { UsageMetricsDisplay } from './components/UsageMetrics';
import {
  MessageSquare,
  Settings as SettingsIcon,
  Menu,
  X,
  BarChart3,
  HardDrive,
  Share2,
  Home
} from 'lucide-react';

function App() {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentTab, setCurrentTab] = useState<'home' | 'storage' | 'connections' | 'metrics'>('home');

  const tabs = [
    { id: 'home', label: 'Home', icon: <Home className="w-5 h-5" /> },
    { id: 'storage', label: 'Storage', icon: <HardDrive className="w-5 h-5" /> },
    { id: 'connections', label: 'Connections', icon: <Share2 className="w-5 h-5" /> },
    { id: 'metrics', label: 'Metrics', icon: <BarChart3 className="w-5 h-5" /> }
  ] as const;

  const renderContent = () => {
    switch (currentTab) {
      case 'storage':
        return <StorageUsage />;
      case 'connections':
        return <SocialMediaConnect />;
      case 'metrics':
        return <UsageMetricsDisplay />;
      default:
        return (
          <>
            {/* Service Health Status */}
            <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200 mb-6">
              <ServiceHealthIndicator 
                services={{
                  mediaProcessing: {
                    name: 'Media Processing',
                    url: 'https://api.media-processor.com'
                  },
                  captionGeneration: {
                    name: 'Caption Generation',
                    url: 'https://api.caption-gen.com'
                  }
                }}
              />
            </div>

            {/* Main Workflow Interface */}
            <MediaWorkflowUI />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <h1 className="text-xl font-bold text-gray-900">Media Workflow</h1>
              
              {/* Desktop Navigation */}
              <div className="hidden md:flex space-x-1">
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setCurrentTab(tab.id)}
                    className={`px-4 py-2 rounded-lg text-sm transition-colors flex items-center space-x-2 ${
                      currentTab === tab.id
                        ? 'bg-primary-50 text-primary-700'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {tab.icon}
                    <span>{tab.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <button
                onClick={() => setIsFeedbackOpen(true)}
                className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                aria-label="Provide Feedback"
              >
                <MessageSquare className="w-5 h-5" />
              </button>
              
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                aria-label="Open Settings"
              >
                <SettingsIcon className="w-5 h-5" />
              </button>

              {/* Mobile Menu Button */}
              <button
                className="md:hidden p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                aria-label="Toggle Menu"
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMobileMenuOpen && (
            <div className="md:hidden pt-4 pb-3 border-t border-gray-200">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => {
                    setCurrentTab(tab.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`flex items-center space-x-2 w-full text-left px-4 py-2 rounded-lg text-sm transition-colors ${
                    currentTab === tab.id
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {renderContent()}
      </main>

      {/* Settings Modal */}
      {isSettingsOpen && (
        <Settings onClose={() => setIsSettingsOpen(false)} />
      )}

      {/* Feedback Dialog */}
      <FeedbackDialog
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
      />

      <footer className="bg-white mt-12 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <p className="text-center text-gray-500 text-sm">
            Media Workflow Manager © {new Date().getFullYear()}
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;