/*
  # Media and Captions Schema

  1. New Tables
    - `media` - Store media file metadata and references
    - `captions` - Store caption data for media files

  2. Security
    - Enable RLS on all tables
    - Add policies for user access control
    - Secure media access

  3. Features
    - Media file tracking
    - Caption storage and retrieval
    - User-based access control
*/

-- Create media table first
CREATE TABLE IF NOT EXISTS media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  filename text NOT NULL,
  file_type text NOT NULL,
  duration integer,
  size integer NOT NULL,
  url text,
  metadata jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create captions table
CREATE TABLE IF NOT EXISTS captions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  media_id uuid REFERENCES media(id) NOT NULL,
  segments jsonb NOT NULL,
  full_text text NOT NULL,
  language text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE media ENABLE ROW LEVEL SECURITY;
ALTER TABLE captions ENABLE ROW LEVEL SECURITY;

-- Create policies for media
CREATE POLICY "Users can read their own media"
  ON media
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own media"
  ON media
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own media"
  ON media
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for captions
CREATE POLICY "Users can read their own captions"
  ON captions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM media
      WHERE media.id = captions.media_id
      AND media.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert their own captions"
  ON captions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM media
      WHERE media.id = captions.media_id
      AND media.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update their own captions"
  ON captions
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM media
      WHERE media.id = captions.media_id
      AND media.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM media
      WHERE media.id = captions.media_id
      AND media.user_id = auth.uid()
    )
  );

-- Create indexes
CREATE INDEX media_user_id_idx ON media(user_id);
CREATE INDEX media_file_type_idx ON media(file_type);
CREATE INDEX captions_media_id_idx ON captions(media_id);
CREATE INDEX captions_language_idx ON captions(language);

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_media_updated_at
  BEFORE UPDATE ON media
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_captions_updated_at
  BEFORE UPDATE ON captions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();