/*
  # Auto-Poster System Tables

  1. New Tables
    - `post_schedules`
      - Stores scheduled posts and their metadata
      - Tracks execution status and retry attempts
    - `post_queue`
      - Manages the posting queue with priority and scheduling
    - `posting_services`
      - Configures third-party posting service integrations
    - `platform_rate_limits`
      - Tracks API rate limits and quotas per platform

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Ensure users can only access their own data

  3. Changes
    - Add scheduling and queue management capabilities
    - Support for third-party service integration
    - Rate limit tracking and management
*/

-- Post schedules table
CREATE TABLE post_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  media_id uuid REFERENCES media_files(id) NOT NULL,
  caption text,
  platforms jsonb NOT NULL,
  scheduled_for timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  attempts integer DEFAULT 0,
  last_attempt timestamptz,
  error_message text,
  metadata jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Post queue table
CREATE TABLE post_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  schedule_id uuid REFERENCES post_schedules(id) NOT NULL,
  priority integer DEFAULT 0,
  locked_at timestamptz,
  locked_by text,
  created_at timestamptz DEFAULT now()
);

-- Posting services configuration
CREATE TABLE posting_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  service_name text NOT NULL,
  credentials jsonb NOT NULL,
  enabled boolean DEFAULT true,
  last_used_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (user_id, service_name)
);

-- Platform rate limits
CREATE TABLE platform_rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  platform text NOT NULL,
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  requests_remaining integer NOT NULL,
  reset_at timestamptz NOT NULL,
  updated_at timestamptz DEFAULT now(),
  UNIQUE (platform, user_id)
);

-- Enable RLS
ALTER TABLE post_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE posting_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_rate_limits ENABLE ROW LEVEL SECURITY;

-- Policies for post_schedules
CREATE POLICY "Users can manage their own schedules"
  ON post_schedules
  USING (auth.uid() = user_id);

-- Policies for post_queue
CREATE POLICY "Users can view their own queue items"
  ON post_queue
  FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM post_schedules
    WHERE post_schedules.id = post_queue.schedule_id
    AND post_schedules.user_id = auth.uid()
  ));

-- Policies for posting_services
CREATE POLICY "Users can manage their posting services"
  ON posting_services
  USING (auth.uid() = user_id);

-- Policies for platform_rate_limits
CREATE POLICY "Users can manage their rate limits"
  ON platform_rate_limits
  USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX post_schedules_user_id_idx ON post_schedules(user_id);
CREATE INDEX post_schedules_status_idx ON post_schedules(status);
CREATE INDEX post_schedules_scheduled_for_idx ON post_schedules(scheduled_for);
CREATE INDEX post_queue_schedule_id_idx ON post_queue(schedule_id);
CREATE INDEX post_queue_priority_idx ON post_queue(priority);
CREATE INDEX platform_rate_limits_platform_user_idx ON platform_rate_limits(platform, user_id);

-- Updated timestamp triggers
CREATE TRIGGER update_post_schedules_updated_at
  BEFORE UPDATE ON post_schedules
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_posting_services_updated_at
  BEFORE UPDATE ON posting_services
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();