/*
  # Social Media Integration Schema

  1. New Tables
    - `social_tokens`: Store OAuth tokens securely
    - `post_logs`: Track posting history and results
    - `social_accounts`: Link user accounts to social platforms

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Encrypt sensitive data
*/

-- Social media OAuth tokens
CREATE TABLE social_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  platform text NOT NULL,
  access_token text NOT NULL,
  refresh_token text,
  expires_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (user_id, platform)
);

-- Post attempt logs
CREATE TABLE post_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  media_id uuid REFERENCES media_files(id) NOT NULL,
  platform text NOT NULL,
  success boolean NOT NULL,
  error_message text,
  post_url text,
  timestamp timestamptz DEFAULT now()
);

-- Connected social accounts
CREATE TABLE social_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  platform text NOT NULL,
  platform_user_id text NOT NULL,
  username text NOT NULL,
  connected_at timestamptz DEFAULT now(),
  last_used_at timestamptz DEFAULT now(),
  UNIQUE (user_id, platform)
);

-- Enable RLS
ALTER TABLE social_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE social_accounts ENABLE ROW LEVEL SECURITY;

-- Policies for social_tokens
CREATE POLICY "Users can manage their own tokens"
  ON social_tokens
  USING (auth.uid() = user_id);

-- Policies for post_logs
CREATE POLICY "Users can view their own post logs"
  ON post_logs
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own post logs"
  ON post_logs
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Policies for social_accounts
CREATE POLICY "Users can manage their social accounts"
  ON social_accounts
  USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX social_tokens_user_platform_idx ON social_tokens(user_id, platform);
CREATE INDEX post_logs_user_id_idx ON post_logs(user_id);
CREATE INDEX post_logs_media_id_idx ON post_logs(media_id);
CREATE INDEX social_accounts_user_platform_idx ON social_accounts(user_id, platform);

-- Updated timestamp triggers
CREATE TRIGGER update_social_tokens_updated_at
  BEFORE UPDATE ON social_tokens
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_social_accounts_last_used
  BEFORE UPDATE ON social_accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();