/*
  # Payment System Schema

  1. New Tables
    - `payment_plans` - Predefined credit packages
    - `user_wallets` - User credit balances and transaction history
    - `payment_transactions` - Payment processing records
    - `credit_usage` - Track credit consumption
    - `lightning_invoices` - Bitcoin Lightning Network payment tracking

  2. Security
    - Enable RLS on all tables
    - Add policies for user access control
    - Encrypt sensitive payment data

  3. Features
    - Credit balance tracking
    - Multiple payment methods
    - Usage monitoring
    - Transaction history
*/

-- Payment Plans
CREATE TABLE payment_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  credits integer NOT NULL,
  price_usd numeric(10,2) NOT NULL,
  price_sats bigint NOT NULL,
  active boolean DEFAULT true,
  features jsonb,
  created_at timestamptz DEFAULT now()
);

-- User Wallets
CREATE TABLE user_wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  credits integer DEFAULT 0,
  lifetime_credits integer DEFAULT 0,
  last_topped_up timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT positive_balance CHECK (credits >= 0)
);

-- Payment Transactions
CREATE TABLE payment_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  wallet_id uuid REFERENCES user_wallets(id) NOT NULL,
  plan_id uuid REFERENCES payment_plans(id),
  amount_usd numeric(10,2),
  amount_sats bigint,
  credits integer NOT NULL,
  payment_method text NOT NULL,
  status text NOT NULL,
  stripe_payment_id text,
  lightning_invoice_id uuid,
  metadata jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Credit Usage
CREATE TABLE credit_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  wallet_id uuid REFERENCES user_wallets(id) NOT NULL,
  media_id uuid REFERENCES media_files(id) NOT NULL,
  credits_used integer NOT NULL,
  usage_type text NOT NULL,
  metadata jsonb,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT positive_usage CHECK (credits_used > 0)
);

-- Lightning Network Invoices
CREATE TABLE lightning_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  payment_hash text NOT NULL UNIQUE,
  payment_request text NOT NULL,
  amount_sats bigint NOT NULL,
  status text NOT NULL,
  expires_at timestamptz NOT NULL,
  settled_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE payment_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE credit_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE lightning_invoices ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Public can view active payment plans"
  ON payment_plans
  FOR SELECT
  USING (active = true);

CREATE POLICY "Users can view their own wallet"
  ON user_wallets
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view their own transactions"
  ON payment_transactions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view their own credit usage"
  ON credit_usage
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view their own lightning invoices"
  ON lightning_invoices
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX user_wallets_user_id_idx ON user_wallets(user_id);
CREATE INDEX payment_transactions_user_id_idx ON payment_transactions(user_id);
CREATE INDEX payment_transactions_status_idx ON payment_transactions(status);
CREATE INDEX credit_usage_user_id_idx ON credit_usage(user_id);
CREATE INDEX credit_usage_media_id_idx ON credit_usage(media_id);
CREATE INDEX lightning_invoices_payment_hash_idx ON lightning_invoices(payment_hash);
CREATE INDEX lightning_invoices_status_idx ON lightning_invoices(status);

-- Functions
CREATE OR REPLACE FUNCTION check_credit_balance()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.credits < 0 THEN
    RAISE EXCEPTION 'Insufficient credits';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION update_wallet_credits()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
    UPDATE user_wallets
    SET 
      credits = credits + NEW.credits,
      lifetime_credits = lifetime_credits + NEW.credits,
      last_topped_up = now(),
      updated_at = now()
    WHERE id = NEW.wallet_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers
CREATE TRIGGER check_wallet_balance
  BEFORE UPDATE ON user_wallets
  FOR EACH ROW
  EXECUTE FUNCTION check_credit_balance();

CREATE TRIGGER update_credits_after_payment
  AFTER UPDATE ON payment_transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_wallet_credits();

-- Insert default payment plans
INSERT INTO payment_plans (name, credits, price_usd, price_sats, features) VALUES
  ('Starter', 100, 9.99, 33000, '{"processing_time": 100, "storage": "1GB"}'),
  ('Pro', 500, 39.99, 133000, '{"processing_time": 500, "storage": "5GB", "priority_support": true}'),
  ('Enterprise', 2000, 149.99, 500000, '{"processing_time": 2000, "storage": "20GB", "priority_support": true, "api_access": true}');