/*
  # Workflow Management Schema

  1. New Tables
    - `workflow_configs` - Stores external service configurations
    - `workflow_logs` - Audit trail for workflow steps
    - `workflow_states` - Stores workflow state for resume capability
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Encrypt sensitive data
*/

-- External service configurations
CREATE TABLE workflow_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  service_name text NOT NULL,
  service_type text NOT NULL,
  config jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (user_id, service_name, service_type)
);

-- Workflow audit trail
CREATE TABLE workflow_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id uuid NOT NULL,
  step text NOT NULL,
  status text NOT NULL,
  details jsonb,
  created_at timestamptz DEFAULT now()
);

-- Workflow state for resume capability
CREATE TABLE workflow_states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  media_id uuid,
  current_step text NOT NULL,
  state jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE workflow_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_states ENABLE ROW LEVEL SECURITY;

-- Policies for workflow_configs
CREATE POLICY "Users can manage their own configs"
  ON workflow_configs
  USING (auth.uid() = user_id);

-- Policies for workflow_logs
CREATE POLICY "Users can view their workflow logs"
  ON workflow_logs
  FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM workflow_states
    WHERE workflow_states.id = workflow_logs.workflow_id
    AND workflow_states.user_id = auth.uid()
  ));

-- Policies for workflow_states
CREATE POLICY "Users can manage their workflow states"
  ON workflow_states
  USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX workflow_logs_workflow_id_idx ON workflow_logs(workflow_id);
CREATE INDEX workflow_states_user_id_idx ON workflow_states(user_id);
CREATE INDEX workflow_states_media_id_idx ON workflow_states(media_id);

-- Updated timestamp triggers
CREATE TRIGGER update_workflow_configs_updated_at
  BEFORE UPDATE ON workflow_configs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_workflow_states_updated_at
  BEFORE UPDATE ON workflow_states
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();