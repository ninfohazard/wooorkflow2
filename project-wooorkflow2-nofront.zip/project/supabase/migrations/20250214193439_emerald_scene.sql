/*
  # Initial Schema Setup
  
  1. New Tables
    - `media_files` - Stores media file metadata
    - `captions` - Stores caption data for media files
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    
  3. Indexes and Triggers
    - Add indexes for performance
    - Add updated_at trigger
*/

-- Create media_files table first
CREATE TABLE IF NOT EXISTS media_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  size integer NOT NULL,
  type text NOT NULL,
  is_temporary boolean DEFAULT false,
  encrypted boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz
);

-- Enable RLS on media_files
ALTER TABLE media_files ENABLE ROW LEVEL SECURITY;

-- Create policies for media_files
CREATE POLICY "Users can read their own media"
  ON media_files
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own media"
  ON media_files
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own media"
  ON media_files
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create captions table
CREATE TABLE IF NOT EXISTS captions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  media_id uuid REFERENCES media_files(id) NOT NULL,
  segments jsonb NOT NULL,
  full_text text NOT NULL,
  language text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on captions
ALTER TABLE captions ENABLE ROW LEVEL SECURITY;

-- Create policies for captions
CREATE POLICY "Users can read their own captions"
  ON captions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM media_files
      WHERE media_files.id = captions.media_id
      AND media_files.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert their own captions"
  ON captions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM media_files
      WHERE media_files.id = captions.media_id
      AND media_files.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update their own captions"
  ON captions
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM media_files
      WHERE media_files.id = captions.media_id
      AND media_files.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM media_files
      WHERE media_files.id = captions.media_id
      AND media_files.user_id = auth.uid()
    )
  );

-- Create indexes
CREATE INDEX media_files_user_id_idx ON media_files(user_id);
CREATE INDEX media_files_type_idx ON media_files(type);
CREATE INDEX captions_media_id_idx ON captions(media_id);
CREATE INDEX captions_language_idx ON captions(language);

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_captions_updated_at
  BEFORE UPDATE ON captions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();