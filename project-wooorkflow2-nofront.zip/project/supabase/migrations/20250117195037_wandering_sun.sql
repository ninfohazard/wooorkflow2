/*
  # Create captions table

  1. New Tables
    - `captions`
      - `id` (uuid, primary key)
      - `media_id` (uuid, references media)
      - `segments` (jsonb, array of caption segments)
      - `full_text` (text, complete transcription)
      - `language` (text, ISO language code)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `captions` table
    - Add policies for authenticated users to manage their own captions
*/

CREATE TABLE IF NOT EXISTS captions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  media_id uuid NOT NULL,
  segments jsonb NOT NULL,
  full_text text NOT NULL,
  language text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE captions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read their own captions"
  ON captions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM media
      WHERE media.id = captions.media_id
      AND media.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert their own captions"
  ON captions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM media
      WHERE media.id = captions.media_id
      AND media.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update their own captions"
  ON captions
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM media
      WHERE media.id = captions.media_id
      AND media.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM media
      WHERE media.id = captions.media_id
      AND media.user_id = auth.uid()
    )
  );

-- Create indexes
CREATE INDEX captions_media_id_idx ON captions(media_id);
CREATE INDEX captions_language_idx ON captions(language);

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_captions_updated_at
  BEFORE UPDATE ON captions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();